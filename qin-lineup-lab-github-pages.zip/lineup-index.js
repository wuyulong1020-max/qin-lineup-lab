const mask=(ids,dict)=>{
 let lower=0,upper=0;
 for(const id of ids){const i=dict.get(id);if(i===undefined)continue;if(i<32)lower|=1<<i;else upper|=1<<(i-32);}
 return [lower,upper];
};
export function lookup(index,{required=[],excluded=[],owned=index.dict,costLimit=9,limit=12}={}){
 const dict=new Map(index.dict.map((id,i)=>[id,i]));
 const [r0,r1]=mask(required,dict),[e0,e1]=mask(excluded,dict),[o0,o1]=mask(owned,dict);
 const hits=[],seen=new Set();
 for(const [root,variant,a0,a1,u0,u1,price,score] of index.items){
  if(seen.has(root)||(a0&r0)!==r0||(a1&r1)!==r1||(u0&e0)||(u1&e1)||(u0&o0)!==u0||(u1&o1)!==u1||price>costLimit)continue;
  seen.add(root);
  if(hits.length<limit)hits.push({id:index.roots[root],variant,score});
 }
 return {count:seen.size,hits};
}
export function expandLineups(pack){
 if(!pack.compactLineups)return pack;
 const {compactLineups, ...value}=pack;
 const {columns,metrics,rows}=compactLineups;
 value.lineups=rows.map(x=>{
  const row=Object.fromEntries(columns.map((k,i)=>[k,x[i]])),{active,mechs,star,awakening,result}=row;
  row.ids=active;row.team={active:active.map(id=>({id,star})),mechs:mechs.map(id=>({id,star})),awakening};
  delete row.active;delete row.star;delete row.awakening;
  const [score,rounds,openingShare,range,stability,counts]=result;
  row.result={score,rounds,openingShare,metrics:Object.fromEntries(metrics.map((k,i)=>[k,counts[i]])),adaptation:{range,stability}};
  row.__detail=true;
  return row;
 });
 return value;
}

