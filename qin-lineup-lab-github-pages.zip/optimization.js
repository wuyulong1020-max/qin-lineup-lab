import {libraryProxy,selectProxyCandidates,PROXY_REVISION} from './roster-proxy.js?v=v3.4.0-20261109212320';
import {DB,H,validateTeam} from './engine.js?v=v3.4.0-20261109212320';
import {combatEffectKey,mechanistKey,exactMechanistStates} from './search-equivalence.js?v=v3.4.0-20261109212320';
import {teamKey as arenaTeamKey} from './fixed-arena.js?v=v3.4.0-20261109212320';
import {mechOptions} from './fast-mechanists.js?v=v3.4.0-20261109212320';
import {effectSpace} from './activation-space.js?v=v3.4.0-20261109212320';
import {constrainedMechSearch} from './constrained-activation.js?v=v3.4.0-20261109212320';
import {screenMechanists} from './screen-mechanists.js?v=v3.4.0-20261109212320';
import {reviewCloseFinalists} from './final-review.js?v=v3.4.0-20261109212320';

// Changes to sampling, constraints or candidate generation invalidate checkpoints.
export const OPTIMIZATION_REVISION='optimization-20261110-v340-proxy4';
const SAMPLING_REVISION='optimization-20261109-v3';
export const COSTLY_NAMES=Object.freeze(['焱妃','东皇太一','王翦','月神','伏念','星魂','盖聂','卫庄','晓梦']);
export const DEFAULT_SEARCH_BUDGET=Object.freeze({screenBattles:24,screenRoutes:3,screenKeep:48,screenRouteKeep:12,screenExplore:16,largePoolThreshold:1000,rescreenBattles:72,rescreenKeep:128,largeRefineKeep:24,refineBattles:120,refineKeep:12,mechChoices:8,mechExplore:6,formationStarts:3,variantBattles:120,variantKeep:16,localParents:3,localPasses:1,localBattles:360,confirmBattles:720,finalists:6,verifyBattles:2400,batchSize:3});
const clone=x=>JSON.parse(JSON.stringify(x));
const ordered=x=>x.slice().sort();
// Keep ordinary library keys compatible, while distinguishing a per-unit
// non-awakened override inside an otherwise awakened team.
export function exactTeamKey(team){const overrides=team.active.filter(x=>x.awakening!==undefined&&x.awakening!==8&&team.awakening===8).map(x=>[x.id,x.awakening]).sort();return arenaTeamKey(team)+(overrides.length?'|unit:'+JSON.stringify(overrides):'')}
const teamKey=exactTeamKey;
const rosterKey=t=>ordered(t.active.map(x=>x.id)).join('.');
export const isCostly=id=>COSTLY_NAMES.includes(H[id]?.name);
export const costCount=team=>new Set([...team.active,...team.mechs].filter(x=>isCostly(x.id)).map(x=>x.id)).size;
const rank=rows=>rows.sort((a,b)=>b.result.score-a.result.score||teamKey(a.team).localeCompare(teamKey(b.team)));
function best(rows,limit){return rank([...new Map(rows.map(x=>[teamKey(x.team),x])).values()]).slice(0,limit)}
function bestPerRoster(rows,limit,perRoster=3){const counts=new Map(),out=[];for(const row of best(rows,rows.length)){const key=rosterKey(row.team),n=counts.get(key)||0;if(n>=perRoster)continue;counts.set(key,n+1);out.push(row);if(out.length>=limit)break}return out}
function withProxyLeaders(rows,limit,leaders=[]){return bestMembers([...bestMembers(rows,limit),...rows.filter(r=>leaders.includes(rosterKey(r.team)))],limit+leaders.length)}
function protectedCandidates(rows,limit,controls=[],leaders=[]){
 const keep=new Set(withProxyLeaders(rows,limit,leaders).map(r=>rosterKey(r.team))),out=[];for(const key of keep){const group=best(rows.filter(r=>rosterKey(r.team)===key),rows.length),protectedRows=group.filter(r=>controls.includes(combatEffectKey(r.team))),protectedEffects=new Set(protectedRows.map(r=>combatEffectKey(r.team)));out.push(...protectedRows,...group.filter(r=>!protectedEffects.has(combatEffectKey(r.team))).slice(0,2))}return best(out,out.length);
}
function bestMembers(rows,limit){const unique=new Map();for(const row of best(rows,rows.length)){const key=rosterKey(row.team);if(!unique.has(key))unique.set(key,row)}return [...unique.values()].slice(0,limit)}
function stable(value){return JSON.stringify(value,(k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b))):v)}
function fingerprint(value){const text=stable(value);let a=2166136261,b=5381;for(let i=0;i<text.length;i++){a=Math.imul(a^text.charCodeAt(i),16777619);b=Math.imul(b,33)^text.charCodeAt(i)}return (a>>>0).toString(16)+(b>>>0).toString(16)}

export function prepareOptimization(input,env){
 const action=input.action==='residual'?'residual':'optimize',excluded=ordered([...new Set(input.excluded||[])]),ban=new Set(excluded);
 for(const id of excluded)if(!H[id])throw Error('不用谁包含未知弟子');
 const source=input.team?clone(input.team):null;if(source)validateTeam(source,env.mechCount);
 const locks=action==='optimize'?source?.active.map(x=>x.id):input.locks;
 if(!locks||locks.length<6||locks.length>9||new Set(locks).size!==locks.length)throw Error('请固定6—9名不同的橙色弟子');
 if(locks.some(id=>!H[id]||H[id].rarity!=='legendary'))throw Error('固定上阵成员必须是橙色弟子');
 if(locks.some(id=>ban.has(id)))throw Error('固定上阵弟子与不用谁冲突，请先修改条件');
 if(source&&action==='optimize'&&source.mechs.some(x=>ban.has(x.id)))throw Error('原方案机师与不用谁冲突，请先修改条件');
 const costLimit=input.costLimit===undefined?9:Number(input.costLimit);if(!Number.isInteger(costLimit)||costLimit<0||costLimit>9)throw Error('三费卡上限须为0—9');
 if(locks.filter(isCostly).length>costLimit)throw Error('固定上阵弟子已超过三费卡上限');
 if(source&&action==='optimize'&&costCount(source)>costLimit)throw Error('原方案上阵与机师的三费弟子总数超过上限');
 const poolMap=new Map((input.pool||DB.heroes.map(h=>({id:h.id,star:env.star}))).map(x=>[x.id,{...x}]));
 if(source)for(const unit of [...source.active,...source.mechs])poolMap.set(unit.id,{...unit});
 for(const [id,unit] of poolMap){if(!H[id]||!Number.isInteger(unit.star)||unit.star<0||unit.star>20)throw Error('弟子池中有无效弟子或星级');if(ban.has(id))poolMap.delete(id)}
 if(locks.some(id=>!poolMap.has(id)))throw Error('固定上阵弟子不在可用弟子池中');
 const pool=[...poolMap.values()].sort((a,b)=>a.id.localeCompare(b.id)),originalCostly=new Set((source?.mechs||input.mechs||[]).map(x=>typeof x==='string'?x:x.id).filter(isCostly));
 const mechPool=action==='optimize'?pool:pool.filter(x=>!isCostly(x.id)||originalCostly.has(x.id));
 const unlocked=pool.filter(x=>H[x.id].rarity==='legendary'&&!locks.includes(x.id)).map(x=>x.id),need=9-locks.length;
 if(unlocked.length<need)throw Error('可用橙色弟子不足以补齐九人');
 const opts={action,env:{...env},excluded,pool,poolMap,mechPool,locks:locks.slice(),unlocked,need,costLimit,source,proxyRows:input.proxyRows||[],proxyModel:input.proxyModel,proxyPolicy:input.proxyPolicy||{},libraryTeams:input.libraryTeams||[],awakening:source?.awakening??env.awakening??0};
 opts.initialMechCache=new Map();opts.transferRows=(opts.proxyRows||[]).filter(r=>r?.team).slice().sort((a,b)=>b.result.score-a.result.score);opts.transferIndex=new Map();for(const r of opts.transferRows)for(const u of r.team.active){if(!opts.transferIndex.has(u.id))opts.transferIndex.set(u.id,[]);opts.transferIndex.get(u.id).push(r)}
 opts.libraryByRoster=new Map();for(const t of opts.libraryTeams){const key=rosterKey(t);if(!opts.libraryByRoster.has(key))opts.libraryByRoster.set(key,[]);opts.libraryByRoster.get(key).push(t)}
 if(rosters(opts).next().done)throw Error('当前三费上限和不用谁条件下，没有可补齐上阵与机师的方案');
 return opts;
}

// Enumerate member combinations, never proxy-sort or pre-truncate them. Objects
// for teams and combat are only created when their roster reaches the scorer.
export function* rosters(opts){
 const {locks,unlocked,need,costLimit,mechPool,env}=opts,ids=locks.slice();
 function* walk(at,left,cost){
  if(!left){if(mechPool.filter(x=>!ids.includes(x.id)&&!isCostly(x.id)).length+Math.min(costLimit-cost,mechPool.filter(x=>!ids.includes(x.id)&&isCostly(x.id)).length)>=env.mechCount)yield ids.slice();return}
  for(let i=at;i<=unlocked.length-left;i++){const id=unlocked[i],next=cost+(isCostly(id)?1:0);if(next>costLimit)continue;ids.push(id);yield* walk(i+1,left-1,next);ids.pop()}
 }
 yield* walk(0,need,locks.filter(isCostly).length);
}
function countRosters(opts){let count=0;for(const ids of rosters(opts))count++;return count}
export function estimateOptimization(input,env){const opts=prepareOptimization(input,env),candidateCount=countRosters(opts),b=DEFAULT_SEARCH_BUDGET;return {candidateCount,screenBattles:candidateCount*b.screenBattles*b.screenRoutes,revision:OPTIMIZATION_REVISION}}

function positioned(ids){return ids.slice().sort((a,b)=>({defense:0,support:1,attack:2}[H[a].role]-{defense:0,support:1,attack:2}[H[b].role])||H[b].stats.def-H[a].stats.def||a.localeCompare(b))}
function makeTeam(ids,mechs,opts){return {name:opts.source?.name||'自选阵容',awakening:opts.awakening,active:opts.action==='optimize'?clone(opts.source.active):ids.map(id=>({...opts.poolMap.get(id)})),mechs:mechs.map(id=>({...opts.poolMap.get(id)}))}}
function legal(team,opts){const ids=[...team.active,...team.mechs].map(x=>x.id);return opts.locks.every(id=>team.active.some(x=>x.id===id))&&costCount(team)<=opts.costLimit&&ids.every(id=>!opts.excluded.includes(id))&&team.mechs.every(x=>opts.mechPool.some(p=>p.id===x.id))}

// The first pass needs one inexpensive, legal representative per roster. The
// combinatorial activation-space selector is reserved for screened survivors.
function initialMechs(ids,opts,route=0){
 const cacheKey=route+'|'+(route===2?ids:ordered(ids)).join('.');if(opts.initialMechCache.has(cacheKey))return opts.initialMechCache.get(cacheKey);const remember=xs=>{opts.initialMechCache.set(cacheKey,xs);return xs};
 if(route===2){const contextPool=[...opts.mechPool,...ids.filter(id=>!opts.mechPool.some(x=>x.id===id)).map(id=>opts.poolMap.get(id))];return remember(screenMechanists(DB,ids,contextPool,opts.env.mechCount,{costIds:opts.mechPool.filter(x=>isCostly(x.id)).map(x=>x.id),costLimit:opts.costLimit-ids.filter(isCostly).length}))}
 const chosen=[],present=new Set(ids),counts=Object.fromEntries(DB.factions.map(f=>[f.id,ids.filter(id=>H[id].faction===f.id).length])),cost=ids.filter(isCostly).length;
 const eligible=opts.mechPool.filter(x=>!present.has(x.id));let used=cost;
 while(chosen.length<opts.env.mechCount){let winner=null,value=-Infinity;
  for(const x of eligible){if(present.has(x.id)||(isCostly(x.id)&&used>=opts.costLimit))continue;let gain=x.star*.00001;
   for(const combo of DB.combos){if(!combo.memberIds.includes(x.id)||!combo.memberIds.some(id=>ids.includes(id)))continue;const missing=combo.memberIds.filter(id=>!present.has(id));gain+=(missing.length===1?4:1/missing.length)*(route?.3:1)}
   for(const tier of DB.factions.find(f=>f.id===H[x.id].faction).tiers)gain+=(counts[H[x.id].faction]+1===tier.count?2:.1/Math.max(1,tier.count-counts[H[x.id].faction]))*(route?3:1);
   if(gain>value){value=gain;winner=x.id}
  }
  if(!winner)throw Error('可用机师不足，请调整不用谁或三费上限');chosen.push(winner);present.add(winner);counts[H[winner].faction]++;if(isCostly(winner))used++;
 }
 return remember(chosen);
}
function starts(team,limit,opts){if(opts.action==='optimize')return [team];const a=team.active,b=positioned(a.map(x=>x.id)),byId=new Map(a.map(x=>[x.id,x])),orders=[a.map(x=>x.id),b,b.slice(0,4).reverse().concat(b.slice(4).reverse())];return [...new Map(orders.slice(0,Math.max(1,limit)).map(ids=>{const t={...team,active:ids.map(id=>({...byId.get(id)}))};return [teamKey(t),t]})).values()]}
function libraryTeams(ids,opts){if(opts.action==='optimize')return [];const key=ordered(ids).join('.');return (opts.libraryByRoster.get(key)||[]).map(t=>({...t,awakening:opts.awakening,active:t.active.map(u=>({...opts.poolMap.get(u.id)})),mechs:t.mechs.map(u=>({...opts.poolMap.get(u.id)}))})).filter(t=>t.active.every(u=>u.id)&&t.mechs.every(u=>u.id)&&legal(t,opts))}
function transferredTeams(ids,opts,limit=1){
 if(!opts.transferIndex?.size)return [];const target=new Set(ids),counts=new Map();for(const id of ids)for(const row of opts.transferIndex.get(id)||[])counts.set(row,(counts.get(row)||0)+1);const nearby=[...counts].filter(([,n])=>n>=7).sort((a,b)=>b[1]-a[1]||b[0].result.score-a[0].result.score).slice(0,limit),fallback=initialMechs(ids,opts,2),out=[];
 for(const [row] of nearby){const incoming=positioned(ids.filter(id=>!row.team.active.some(u=>u.id===id)));let at=0;const order=row.team.active.map(u=>target.has(u.id)?u.id:incoming[at++]),activeCost=ids.filter(isCostly).length,allowed=new Set(opts.mechPool.map(u=>u.id)),mechs=[];let cost=activeCost;for(const id of [...row.team.mechs.map(u=>u.id),...fallback,...opts.mechPool.map(u=>u.id)]){if(target.has(id)||mechs.includes(id)||!allowed.has(id)||isCostly(id)&&cost>=opts.costLimit)continue;mechs.push(id);if(isCostly(id))cost++;if(mechs.length===opts.env.mechCount)break}if(mechs.length===opts.env.mechCount){const team=makeTeam(order,mechs,opts);if(legal(team,opts))out.push(team)}}return out;
}
function variants(rows,opts,budget){const out=[];
 if(opts.fastResidualVariants){for(const row of rows){const ids=row.team.active.map(u=>u.id),choices=[row.team.mechs.map(u=>u.id),initialMechs(ids,opts,0),initialMechs(ids,opts,1),initialMechs(ids,opts,2)];for(const mechs of choices){const t=makeTeam(ids,mechs,opts);if(legal(t,opts))out.push(...starts(t,budget.formationStarts,opts))}out.push(...libraryTeams(ids,opts),...transferredTeams(ids,opts,2));
 const proxy=opts.proxyRuntime??=libraryProxy(opts.proxyRows,opts.env,opts.proxyModel),base=initialMechs(ids,opts,2),swaps=[];for(let slot=0;slot<base.length;slot++)for(const unit of opts.mechPool){if(ids.includes(unit.id)||base.includes(unit.id))continue;const mechs=base.slice();mechs[slot]=unit.id;const t=makeTeam(ids,mechs,opts);if(legal(t,opts))swaps.push({team:t,value:proxy.predict(t)})}const unique=[...new Map(swaps.map(r=>[combatEffectKey(r.team),r])).values()].sort((a,b)=>b.value-a.value);out.push(...unique.slice(0,4).map(r=>r.team));
 }return [...new Map(out.map(t=>[combatEffectKey(t),t])).values()]}

 for(const row of rows){const ids=row.team.active.map(x=>x.id),remaining=opts.costLimit-ids.filter(isCostly).length;
  // Zero remaining budget is enforced before activation-space enumeration.
  const pool=opts.mechPool.filter(x=>remaining>0||!isCostly(x.id));
  const contextPool=[...pool,...row.team.active.filter(x=>!pool.some(unit=>unit.id===x.id))];
  const costIds=pool.filter(x=>!ids.includes(x.id)&&isCostly(x.id)).map(x=>x.id),constrained=costIds.length>remaining?constrainedMechSearch(DB,ids,contextPool,opts.env.mechCount,{costIds,costLimit:remaining,limit:budget.mechChoices*2}):null;
  const choices=[...(opts.action==='optimize'?exactMechanistStates(ids,contextPool,opts.env.mechCount,{costly:isCostly,costLimit:remaining}).map(x=>x.mechs):[]),row.team.mechs.map(x=>x.id),...(constrained?.options||mechOptions(ids,contextPool,opts.env.mechCount,[],budget.mechChoices*2)).slice(0,budget.mechChoices)];
  if(opts.source&&rosterKey(opts.source)===rosterKey(row.team))choices.unshift(opts.source.mechs.map(x=>x.id));
  if(budget.mechExplore){
   const states=(constrained?.states||effectSpace(DB,ids,opts.env.mechCount,{pool:pool.map(x=>x.id)})).slice(),features=s=>new Set([...s.combos,...s.factions]),selected=[];
   // Search distinct activation routes as well as the learned utility leaders.
   for(let i=0;i<budget.mechExplore&&states.length;i++){
    const covered=selected.map(features),sortValue=s=>i===0?s.combos.length:i===1?s.factions.length:Math.min(...covered.map(set=>[...new Set([...features(s),...set])].filter(x=>features(s).has(x)!==set.has(x)).length));
    states.sort((a,b)=>sortValue(b)-sortValue(a)||a.key.localeCompare(b.key));const state=states.shift();selected.push(state);choices.push(state.mechs);
   }
  }
  choices.push(initialMechs(ids,opts,1));
  const unique=[...new Map(choices.map(xs=>[ordered(xs).join('.'),xs])).values()].filter(xs=>xs.length===opts.env.mechCount&&xs.every(id=>!ids.includes(id)&&opts.poolMap.has(id))).map(xs=>makeTeam(ids,xs,opts)).filter(t=>legal(t,opts));
  for(const t of unique)out.push(...starts(t,budget.formationStarts,opts));out.push(...libraryTeams(ids,opts));
 }
 return [...new Map(out.map(t=>[combatEffectKey(t),t])).values()];
}
function neighbors(rows,opts,budget,source=null){const out=[],parents=bestMembers(rows,budget.localParents);if(source&&!parents.some(x=>teamKey(x.team)===teamKey(source)))parents.push({team:source});for(const {team} of parents){
 // Every pair of positions is visited, including within the front/back rows.
 for(let a=0;a<8;a++)for(let b=a+1;b<9;b++){const active=team.active.slice();[active[a],active[b]]=[active[b],active[a]];out.push({...team,active})}
 // Alternate positioning with activation-aware mechanist selection.
 out.push(...variants([{team}],opts,{...budget,formationStarts:1}));
 }return [...new Map(out.map(t=>[teamKey(t),t])).values()]}

export function previewProxyCandidates(input,env,budget=DEFAULT_SEARCH_BUDGET){const opts=prepareOptimization(input,env);return buildProxySelection(opts,env,budget)}
async function buildProxySelection(opts,env,budget,{resume=null,cooperate=()=>{}}={}){
 const started=Date.now(),proxy=libraryProxy(opts.proxyRows,env,opts.proxyModel),candidates=resume?.candidates||[],libraries=resume?.libraries||[];let enumerated=resume?.enumerated||0,index=0;
 for(const ids of rosters(opts)){if(index++<enumerated)continue;const known=libraryTeams(ids,opts);libraries.push(...known);for(let route=0;route<budget.screenRoutes;route++){const active=route===1?ids.slice().sort((a,b)=>(H[b].stats.def+H[b].stats.hp*.1)-(H[a].stats.def+H[a].stats.hp*.1)||a.localeCompare(b)):positioned(ids),team=(route===2&&known[0])||makeTeam(route===2?active.slice(0,4).reverse().concat(active.slice(4).reverse()):active,initialMechs(active,opts,route===2?0:route),opts);candidates.push({team,route})}enumerated++;if(enumerated%128===0){await new Promise(resolve=>setTimeout(resolve,0));cooperate({enumerated,candidates,libraries})}}
 const selected=selectProxyCandidates(candidates,proxy,{keep:opts.proxyPolicy.keep??240,routeKeep:opts.proxyPolicy.routeKeep??36,explore:opts.proxyPolicy.explore??32,libraryTeams:libraries,inspectRosters:opts.proxyPolicy.inspectRosters||[]});const selectedByRoster=new Map();for(const team of selected.teams){const key=rosterKey(team);if(!selectedByRoster.has(key))selectedByRoster.set(key,team)}for(const team of selectedByRoster.values()){const ids=team.active.map(u=>u.id);selected.teams.push(makeTeam(ids,initialMechs(ids,opts,2),opts),...transferredTeams(ids,opts))}selected.teams=[...new Map(selected.teams.map(t=>[combatEffectKey(t),t])).values()];selected.selectedConfigurations=selected.teams.length;return {teams:selected.teams,stats:{revision:proxy.revision,trainingRows:proxy.trainingRows,trainingMAE:proxy.trainingMAE,featureCount:proxy.featureCount,...selected,teams:undefined,enumeratedRosters:enumerated,elapsedMs:Date.now()-started,officialScore:false}};

}
export async function runOptimization(input,env,{score,progress=()=>{},revision='',budget:override={},checkpointRequested=()=>false}={}){
 if(typeof score!=='function')throw Error('缺少阵容评分器');
 const opts=prepareOptimization(input,env),budget={...DEFAULT_SEARCH_BUDGET,...override},candidateCount=countRosters(opts);
 const proxyMode=opts.action==='residual'&&candidateCount>(opts.proxyPolicy.threshold??400)&&opts.proxyRows.length>=20;
 opts.fastResidualVariants=proxyMode;
 const largePool=!proxyMode&&candidateCount>=budget.largePoolThreshold;if(largePool&&override.refineKeep===undefined)budget.refineKeep=budget.largeRefineKeep;
 const signature=fingerprint({revision:OPTIMIZATION_REVISION,dataRevision:revision,action:opts.action,env,source:opts.source,pool:opts.pool,mechPool:opts.mechPool,locks:opts.locks,excluded:opts.excluded,costLimit:opts.costLimit,library:fingerprint(opts.libraryTeams.map(teamKey).sort()),proxy:proxyMode?{revision:PROXY_REVISION,policy:opts.proxyPolicy}:null,budget});
 let state=input.resume?clone(input.resume):{version:1,revision:OPTIMIZATION_REVISION,signature,environment:env.key,phase:'screen',cursor:0,rows:[],pass:0,completedBattles:0,candidateCount};
 if(state.version!==1||state.revision!==OPTIMIZATION_REVISION||state.signature!==signature||state.environment!==env.key)throw Error('保存的搜索进度与当前环境、弟子或条件不一致，请重新开始');
 const seed=phase=>SAMPLING_REVISION+'/'+env.key+'/'+phase;
 let lastCheckpointAt=0;
 const emit=(message,done,total)=>{const now=Date.now(),checkpoint=checkpointRequested()||now-lastCheckpointAt>=1500||done===0||done===total?clone(state):undefined;if(checkpoint)lastCheckpointAt=now;progress({message,done,total,phase:state.phase,candidateCount,completedBattles:state.completedBattles,bestRows:best((state.output?.length?state.output:(state.rows||[])).filter(x=>x.result.metrics),3),...(checkpoint?{checkpoint}:{})})};
 const source=opts.source&&legal(opts.source,opts)?opts.source:null;
 async function evaluate(team,n,stage,phase=null){const result=await score(team,n,seed(stage),{fresh:true,...(phase?{phase}:{})});state.completedBattles+=result.n;return {team,result}}
 async function phaseTeams(teams,n,stage,message,keep,byMembers=false,perRoster=0){
  const select=perRoster?(rows,limit)=>bestPerRoster(rows,limit,perRoster):byMembers?bestMembers:best;
  if(!state.output)state.output=[];
  while(state.cursor<teams.length){const batch=teams.slice(state.cursor,state.cursor+budget.batchSize),rows=await Promise.all(batch.map(t=>evaluate(t,n,stage)));state.output=select(state.output.concat(rows),keep);state.cursor+=batch.length;emit(message,state.cursor,teams.length)}
  state.rows=select(state.output,keep);delete state.output;state.cursor=0;
 }
 function next(phase){state.phase=phase;state.cursor=0;emit('已保存搜索进度',0,1)}
 if(state.phase==='screen'&&proxyMode){
  if(!state.teams){
   const selected=await buildProxySelection(opts,env,budget,{resume:state.proxyPreparation,cooperate:partial=>{if(checkpointRequested()){state.proxyPreparation=partial;emit('正在保存合法名单筛选进度',partial.enumerated,candidateCount)}}});delete state.proxyPreparation;state.teams=selected.teams;state.proxyStats=selected.stats;state.proxyLeaderRosters=selected.stats.leaderRosters||[];
   emit('已筛选库外候选与激活路线，准备正式对战',0,state.teams.length);
  }
  await phaseTeams(state.teams,budget.screenBattles,'screen','正在实测分层候选',state.teams.length,true);const cutoff=state.rows[Math.min(state.rows.length-1,budget.screenKeep-1)]?.result.score??0;state.rows=state.rows.filter(r=>r.result.score>=cutoff-1e-8||state.proxyLeaderRosters.includes(rosterKey(r.team)));state.proxyStats.boundarySurvivors=state.rows.length;delete state.teams;next('proxy-rescreen');
 }
 if(state.phase==='screen'){
  let index=0,batch=[];
  const keepScreen=rows=>{
   state.rows=best(state.rows.concat(rows),budget.screenKeep);
   if(largePool){const cutoff=state.rows.at(-1).result.score;state.screenTies=[...new Map((state.screenTies||[]).concat(rows.map(x=>({team:x.team,result:{score:x.result.score,n:x.result.n,halfWidth:x.result.halfWidth}}))).filter(x=>x.result.score>=cutoff-1e-8).map(x=>[teamKey(x.team),x])).values()]}
   state.routeRows||=Array.from({length:budget.screenRoutes},()=>[]);for(let route=0;route<budget.screenRoutes;route++)state.routeRows[route]=best(state.routeRows[route].concat(rows.filter(x=>x.route===route)),budget.screenRouteKeep);
   const representatives=new Map();for(const row of rows){const key=rosterKey(row.team);if(!representatives.has(key)||representatives.get(key).result.score<row.result.score)representatives.set(key,row)}
   state.exploration=[...new Map((state.exploration||[]).concat([...representatives.values()]).map(x=>[rosterKey(x.team),x])).values()].sort((a,b)=>fingerprint(rosterKey(a.team)).localeCompare(fingerprint(rosterKey(b.team)))).slice(0,budget.screenExplore);
  };
  const screenBatch=async()=>{const rows=await Promise.all(batch.flatMap((ids)=>Array.from({length:budget.screenRoutes},async(_,route)=>{
   const active=opts.action==='optimize'?opts.source.active.map(x=>x.id):route===1?ids.slice().sort((a,b)=>(H[b].stats.def+H[b].stats.hp*.1)-(H[a].stats.def+H[a].stats.hp*.1)||a.localeCompare(b)):positioned(ids);
   const team=opts.action==='optimize'&&route===0?clone(opts.source):(route===2&&libraryTeams(ids,opts)[0])||makeTeam(active,initialMechs(active,opts,route),opts);return {...await evaluate(team,budget.screenBattles,'screen'),route};
  })));keepScreen(rows);state.cursor+=batch.length;batch=[];emit('正在搜索可行阵容',state.cursor,candidateCount)};
  for(const ids of rosters(opts)){
   if(index++<state.cursor)continue;batch.push(ids);
   if(batch.length>=budget.batchSize)await screenBatch();
  }
  if(batch.length)await screenBatch();
  state.rows=best(state.rows.concat(state.routeRows.flat(),state.exploration),budget.screenKeep+budget.screenRoutes*budget.screenRouteKeep+budget.screenExplore);
  if(largePool){const legacyKeys=[...new Set(state.rows.map(x=>rosterKey(x.team)))],ties=state.screenTies||[];state.screenStats={boundaryScore:ties.length?Math.min(...ties.map(x=>x.result.score)):null,tiedConfigurations:ties.length,tiedMemberLists:new Set(ties.map(x=>rosterKey(x.team))).size,legacyMemberKeys:legacyKeys,rescreenConfigurations:0};state.rows=best(ties.concat(state.rows),ties.length+state.rows.length);state.screenStats.rescreenConfigurations=state.rows.length;delete state.screenTies}
  delete state.routeRows;delete state.exploration;
  next(largePool?'rescreen':'refine');
 }
 if(state.phase==='proxy-rescreen'){await phaseTeams(state.rows.map(r=>r.team),budget.rescreenBattles,'proxy-boundary-rescreen','正在加场比较接近的分层候选',state.rows.length,true);state.rows=withProxyLeaders(state.rows,budget.screenKeep,state.proxyLeaderRosters);next('refine')}
 if(state.phase==='rescreen'){
  await phaseTeams(state.rows.map(x=>x.team),budget.rescreenBattles,'boundary-rescreen','正在加场比较接近的阵容',budget.rescreenKeep,true);next('refine');
 }
 if(state.phase==='refine'){
  await phaseTeams(state.rows.map(x=>x.team),budget.refineBattles,'refine','正在比较入选阵容',proxyMode?state.rows.length:budget.refineKeep,true);if(proxyMode)state.rows=withProxyLeaders(state.rows,budget.refineKeep,state.proxyLeaderRosters);next('variants');
 }
 if(state.phase==='variants'){
  // Freeze worklists in the checkpoint: resuming cannot change the search path.
  if(!state.teams){if(proxyMode)state.protectedKeys=[...new Set(state.rows.flatMap(r=>{const ids=r.team.active.map(u=>u.id);return [makeTeam(ids,initialMechs(ids,opts,2),opts),...libraryTeams(ids,opts)].map(combatEffectKey)}))];state.teams=variants(state.rows,opts,budget);state.variantsConfigurationCount=state.teams.length}
  await phaseTeams(state.teams,opts.action==='optimize'||proxyMode?budget.screenBattles:budget.variantBattles,'variants','正在比较机师组合与羁绊',proxyMode?state.teams.length:budget.variantKeep,opts.action==='residual'&&!proxyMode);if(proxyMode)state.rows=protectedCandidates(state.rows,budget.variantKeep,state.protectedKeys,state.proxyLeaderRosters);delete state.teams;next(opts.action==='residual'?'local':'confirm');
 }
 while(state.phase==='local'&&state.pass<budget.localPasses){
  if(!state.teams)state.teams=[...new Map([...state.rows.map(x=>x.team),...neighbors(state.rows,opts,budget,source)].map(t=>[teamKey(t),t])).values()];
  if(proxyMode){
   if(!state.localScreenDone){await phaseTeams(state.teams,72,'local-screen-'+state.pass,'正在筛选有效残阵布置',state.teams.length);state.rows=protectedCandidates(state.rows,budget.variantKeep,state.protectedKeys,state.proxyLeaderRosters);state.localScreenDone=true;state.teams=state.rows.map(r=>r.team);emit('已保留不同九人的领先布置，准备正式复核',0,state.teams.length)}
   await phaseTeams(state.teams,budget.localBattles,'local-'+state.pass,'正在复核残阵布置与机师',state.teams.length);state.rows=protectedCandidates(state.rows,budget.variantKeep,state.protectedKeys,state.proxyLeaderRosters);delete state.localScreenDone;
  }else await phaseTeams(state.teams,budget.localBattles,'local-'+state.pass,'正在复核残阵布置与机师',budget.variantKeep,opts.action==='residual');delete state.teams;state.pass++;emit('已保存优化进度',state.pass,budget.localPasses);
 }
 if(state.phase==='local')next('confirm');
 if(state.phase==='confirm'){
  const teams=[...new Map([...state.rows.map(x=>x.team),...(source?[source]:[])].map(t=>[teamKey(t),t])).values()];await phaseTeams(teams,budget.confirmBattles,'confirmation','正在加场比较领先方案',proxyMode?teams.length:budget.variantKeep,opts.action==='residual'&&!proxyMode);if(proxyMode)state.rows=bestMembers(state.rows,budget.variantKeep);next('verify');
 }
 if(state.phase==='verify'){
  if(!state.teams)state.teams=[...new Map([...(opts.action==='residual'?bestMembers(state.rows,budget.finalists):state.rows.slice(0,budget.finalists)).map(x=>x.team),...(source?[source]:[])].map(t=>[teamKey(t),t])).values()];
  // A new shared seed and full frozen pool independently review every finalist
  // and the exact input. No library result is allowed to substitute this pass.
  await phaseTeams(state.teams,budget.verifyBattles,'independent-review','正在复核领先方案与原方案',budget.finalists+1);delete state.teams;next('verify-more');
 }
 if(state.phase==='verify-more'){
  const extra=await reviewCloseFinalists(state.rows,{key:teamKey,sourceKey:source?teamKey(source):null,score:async(team,n,stage)=>(await evaluate(team,n,stage,'verify-more')).result,resume:state.closeReview||null,progress:update=>{state.closeReview=update.state;const old=state.rows;state.rows=update.rows;emit('正在加场复核接近的方案',update.done,update.total);state.rows=old}});
  state.rows=extra.rows;state.extraReview={cohortSize:extra.cohortSize,passes:extra.passes,sampledBattles:extra.sampledBattles,stable:extra.stable};delete state.closeReview;state.baseline=source?state.rows.find(x=>teamKey(x.team)===teamKey(source)):null;next('done');
 }
 const uniqueKey=opts.action==='residual'?rosterKey:combatEffectKey,unique=new Map();for(const row of best(state.rows,state.rows.length)){const key=uniqueKey(row.team);if(!unique.has(key))unique.set(key,row)}const rows=[...unique.values()].slice(0,opts.action==='residual'&&opts.locks.length===9?1:3),baseline=state.baseline||null;
 return {rows,baseline,improvement:baseline&&rows.length?rows[0].result.score-baseline.result.score:null,mode:opts.action,candidateCount,coverage:{screenedConfigurations:opts.action==='optimize'?state.variantsConfigurationCount:state.proxyStats?.selectedConfigurations,feasibleRosters:candidateCount,screenedRosters:state.proxyStats?.selectedRosters??candidateCount,memberEnumerationComplete:true,...(state.proxyStats?{proxy:{...state.proxyStats,protectedConfigurations:state.protectedKeys?.length||0,protectedThroughBattles:budget.confirmBattles},combatEnumerationComplete:false}:{combatEnumerationComplete:true}),formationSearch:opts.action==='optimize'?'fixed':'bounded-layout-local',mechanistSearch:opts.action==='optimize'?'all-feasible-effect-signatures':'activation-routes',distinctResults:opts.action==='residual'?'nine-members':'mechanist-members',automaticPositionChanges:opts.action==='residual',independentReview:true,...(state.screenStats?{screenBoundaryScore:state.screenStats.boundaryScore,boundaryTiedConfigurations:state.screenStats.tiedConfigurations,boundaryTiedMemberLists:state.screenStats.tiedMemberLists,rescreenConfigurations:state.screenStats.rescreenConfigurations}:{})},completedBattles:state.completedBattles,extraReview:state.extraReview,revision:OPTIMIZATION_REVISION,checkpoint:clone(state)};
}
