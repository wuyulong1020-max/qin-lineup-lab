import {DB,H,C,rng,validateTeam,teamTraits} from './engine.js?v=2.1-rc.1-R4-20261015';
import {evaluateArena,lineupKey} from './arena.js?v=2.1-rc.1-R4-20261015';
import {chooseMechs,arrange} from './search.js?v=2.1-rc.1-R4-20261015';
import {METRICS,emptyMetrics,combineResults,sampleSeed} from './statistics.js?v=2.1-rc.1-R4-20261015';
const clone=x=>structuredClone(x),legends=()=>DB.heroes.filter(h=>h.rarity==='legendary');
export const MECHANISMS=[['area','群攻压血'],['crit','暴击爆发'],['penetration','穿透破防'],['trueDamage','真伤破防'],['execute','斩杀收割'],['dot','持续消耗'],['control','控制压制'],['counter','反击制胜'],['healing','治疗续航'],['shield','护盾保护'],['buffs','增减益协同']].map(([id,name])=>({id,name}));
const short=r=>{const {opponents,byHero,...s}=r;return s;};
const metricSum=(result,ids)=>Object.fromEntries(METRICS.map(k=>[k,ids.reduce((v,id)=>v+(result.byHero[id]?.[k]||0),0)]));
function sample(random,list,n){const xs=list.slice(),out=[];while(xs.length&&out.length<n)out.push(xs.splice(Math.floor(random()*xs.length),1)[0]);return out;}
function randomBackground(required,requiredMechs,env,seed,excluded=[],turn=0){
 const random=rng(seed),ban=new Set([...required,...requiredMechs,...excluded]);
 const available=legends().map(h=>h.id).filter(id=>!ban.has(id));
 // Quotas are based on the remaining team, never a hand-picked best partner.
 const rest=[],need=9-required.length;
 for(const role of ['defense','support','attack','attack']){if(rest.length>=need)break;const xs=available.filter(id=>!rest.includes(id)&&H[id].role===role);if(xs.length)rest.push(sample(random,xs,1)[0]);}
 rest.push(...sample(random,available.filter(id=>!rest.includes(id)),need-rest.length));
 if(rest.length!==need)return null;
 const order=arrange(rest),active=Array(9).fill(null),slotOrder=[0,4,1,5,2,6,3,7,8];
 required.forEach((id,j)=>active[slotOrder[(turn+j)%9]]=id);for(let i=0;i<9;i++)if(!active[i])active[i]=order.shift();
 const mechPool=DB.heroes.map(h=>h.id).filter(id=>!active.includes(id)&&!excluded.includes(id)&&!requiredMechs.includes(id));
 const mechs=[...requiredMechs,...sample(random,mechPool,env.mechCount-requiredMechs.length)];
 const stars=env.activeStars.slice(),remaining=stars.filter((_,i)=>!required.some((id,j)=>i===(turn+j)%9));
 const requiredStars=new Map(required.map((id,j)=>[id,stars[(turn+j)%9]]));
 const t={name:'多背景对照',active:active.map(id=>({id,star:requiredStars.get(id)??remaining.shift()})),mechs:mechs.map(id=>({id,star:env.mechStar})),core:[]};
 validateTeam(t,env.mechCount);return t;
}
function factionMembers(faction,count,mechCount,random){
 const l=legends().filter(h=>h.faction===faction.id).map(h=>h.id),epic=DB.heroes.filter(h=>h.faction===faction.id&&h.rarity==='epic').map(h=>h.id);
 if(l.length+Math.min(mechCount,epic.length)<count||count>9+mechCount)return null;
 const active=sample(random,l,Math.min(count,l.length,9)),mechs=sample(random,epic,count-active.length);
 if(mechs.length>mechCount)return null;return {active,mechs};
}
function baselineTeams(team,subject,slots,random,n){
 const targetIds=new Set([...subject.required,...subject.requiredMechs]),slotIds=new Set(slots.map(s=>team[s.kind][s.index].id));
 const fixed=new Set([...team.active,...team.mechs].filter(x=>!slotIds.has(x.id)).map(x=>x.id));
 const activeChoices=legends().map(h=>h.id).filter(id=>!fixed.has(id)&&!targetIds.has(id));
 const allChoices=DB.heroes.map(h=>h.id).filter(id=>!fixed.has(id)&&!targetIds.has(id));
 const rows=[],seen=new Set(),single=slots.length===1&&slots[0].kind==='active';
 const amount=single?activeChoices.length:n;
 for(let attempt=0;rows.length<amount&&attempt<amount*40;attempt++){
  const t=clone(team),used=new Set(fixed);let valid=true;
  for(let j=0;j<slots.length;j++){const slot=slots[j],choices=(slot.kind==='active'?activeChoices:allChoices).filter(id=>!used.has(id));const id=single?activeChoices[attempt]:sample(random,choices,1)[0];if(!id){valid=false;break;}used.add(id);t[slot.kind][slot.index].id=id;}
  if(!valid)continue;const key=lineupKey(t);if(seen.has(key))continue;seen.add(key);validateTeam(t);rows.push(t);
 }
 return rows;
}
export function publicGain(subject,arena,{backgrounds=9,alternatives=16,battles=120,seed='public-gain',progress=()=>{}}={}){
 const cases=[],random=rng(sampleSeed(seed,subject.id,0));let battleCount=0;
 for(let i=0;i<backgrounds;i++){
  let required=subject.memberIds?.filter(id=>H[id].rarity==='legendary')||[subject.id],requiredMechs=subject.memberIds?.filter(id=>H[id].rarity==='epic')||[],excluded=[];
  if(subject.kind==='faction'){const pick=factionMembers(subject.faction,subject.count,arena.environment.mechCount,random);if(!pick)return {id:subject.id,unavailable:'当前机师数不足以形成此人数羁绊'};required=pick.active;requiredMechs=pick.mechs;excluded=DB.heroes.filter(h=>h.faction===subject.faction.id&&!required.includes(h.id)&&!requiredMechs.includes(h.id)).map(h=>h.id);}
  if(requiredMechs.length>arena.environment.mechCount)return {id:subject.id,unavailable:'机师数不足'};
  const team=randomBackground(required,requiredMechs,arena.environment,sampleSeed(seed,subject.id,i),excluded,i);if(!team)continue;
  const slots=[...required.map(id=>({kind:'active',index:team.active.findIndex(x=>x.id===id)})),...requiredMechs.map(id=>({kind:'mechs',index:team.mechs.findIndex(x=>x.id===id)}))];
  const normalized={required:[...required,...excluded],requiredMechs};
  const replacements=baselineTeams(team,normalized,slots,random,alternatives);if(!replacements.length)continue;
  const namespace=`${seed}/${subject.id}/background-${i}`;
  const on=evaluateArena(team,arena,{battles,seed:namespace,requireSameEnvironment:false});battleCount+=on.n;
  const offRows=replacements.map((t,j)=>{progress({stage:'合法替代者对照',current:j+1,total:replacements.length,background:i+1,backgrounds});const r=evaluateArena(t,arena,{battles,seed:namespace,requireSameEnvironment:false});battleCount+=r.n;return r;});
  const off=combineResults(offRows),functional=metricSum(on,required);
  cases.push({on,off,delta:on.score-off.score,functional,activeCount:required.length,mechCount:requiredMechs.length,alternatives:replacements.length,positions:slots});
 }
 if(!cases.length)return {id:subject.id,unavailable:'无合法背景'};
 const on=combineResults(cases.map(x=>x.on)),off=combineResults(cases.map(x=>x.off)),delta=on.score-off.score;
 // Paired differences are bounded [-1,1]; alternatives share the same random
 // namespaces. Treat them as fully correlated rather than inflate precision.
 const scale=cases.reduce((v,x)=>v+x.on.boundScale,0)/(cases.length**2),radius=100*Math.sqrt(2*Math.log(40)*scale);
 const functional=Object.fromEntries(METRICS.map(k=>[k,cases.reduce((v,c)=>v+c.functional[k],0)/cases.length]));
 return {id:subject.id,factionId:subject.faction?.id,count:subject.count,delta,deltaInterval:[delta-radius,delta+radius],on:short(on),off:short(off),functional,backgroundRange:[Math.min(...cases.map(x=>x.delta)),Math.max(...cases.map(x=>x.delta))],backgroundCount:cases.length,alternativeCount:cases.reduce((v,x)=>v+x.alternatives,0),activeCount:cases[0].activeCount,mechCount:cases[0].mechCount,battleCount,
  definition:subject.kind==='hero'?'跨合理随机队友背景，减去同位所有合法英雄平均评分':'整组人物及联动，相同人数/站位/星级预算的合法模块替代抽样',intervalNote:'差值区间仅估计固定背景和对手条件下的对战抽样误差；未包含背景分布与模型误差'};
}
export function analyzeCore(team,arena,{pool=null,battles=120,seed='core',count=2,progress=()=>{}}={}){
 const base=evaluateArena(team,arena,{battles,seed,requireSameEnvironment:false}),used=new Set([...team.active,...team.mechs].map(x=>x.id));
 const allowed=legends().filter(h=>!used.has(h.id)),rows=[];let battleCount=base.n;
 for(let slot=0;slot<9;slot++){
  const results=allowed.map((h,j)=>{const t=clone(team);t.active[slot].id=h.id;progress({stage:'计算核心替换贡献',current:slot*allowed.length+j+1,total:9*allowed.length});const r=evaluateArena(t,arena,{battles,seed,requireSameEnvironment:false});battleCount+=r.n;return r;});
  const off=combineResults(results),id=team.active[slot].id,delta=base.score-off.score;rows.push({id,slot,delta,baseline:off.score,role:H[id].role,description:(H[id].tags||[]).slice(0,2).join(' · '),basis:'在本队中，同星级同位置合法替代者的平均评分差'});
 }
 rows.sort((a,b)=>b.delta-a.delta);return {rows,core:rows.slice(0,count),keyPeople:rows.slice(0,4),base:short(base),battleCount};
}
export function analyzeTactics(team,arena,{battles=240,seed='tactics',progress=()=>{}}={}){
 const base=evaluateArena(team,arena,{battles,seed,requireSameEnvironment:false}),rows=[];let battleCount=base.n;
 for(let i=0;i<MECHANISMS.length;i++){
  const feature=MECHANISMS[i];progress({stage:'比较阵容制胜机制',current:i+1,total:MECHANISMS.length});
  const off=evaluateArena(team,arena,{battles,seed,options:{disableMechanisms:[[feature.id],[]]},requireSameEnvironment:false});battleCount+=off.n;
  rows.push({...feature,delta:base.score-off.score,baseScore:base.score,withoutScore:off.score});
 }
 rows.sort((a,b)=>b.delta-a.delta);
 return {top:rows.filter(x=>x.delta>0).slice(0,2),rows,battleCount,note:'在模型内关闭机制的成对对照，含连带影响；贡献重叠，不能加总'};
}
export function labelTeam(team,coreAnalysis,tactics){const core=coreAnalysis.core.slice(0,2).map(x=>x.id),names=core.map(id=>H[id].name),plays=tactics?.top?.map(x=>x.name)||[];return {...team,core,keyPeople:coreAnalysis.keyPeople.map(x=>x.id),name:[names.join('·'),plays.length?plays.join('·'):'打法待校准'].join(' · '),coreContributions:coreAnalysis.rows,tactics:tactics?.rows||[]};}
