import {DB,H,C,rng,teamTraits,evaluate,validateTeam,MODEL} from './engine.js?v=v3.1.2-20261106195732';
export const templates=[
 {name:'纵横三极',ids:['h06','h04','h14','h12','h07','h02','h05','h08','h09'],core:['h02','h06','h07']},
 {name:'纵横楚汉',ids:['h06','h22','h27','h12','h07','h02','h32','h23','h38'],core:['h02','h06','h07']},
 {name:'纵横天崩',ids:['h06','h33','h26','h22','h07','h02','h38','h32','h36'],core:['h02','h06','h07']},
 {name:'阴阳诅咒',ids:['h01','h26','h20','h10','h02','h03','h08','h09','h19'],core:['h01','h02','h03']},
 {name:'农家群攻',ids:['h33','h37','h22','h34','h38','h32','h35','h36','h23'],core:['h33','h38','h37']},
 {name:'反击续航',ids:['h26','h06','h15','h22','h07','h12','h20','h29','h10'],core:['h26','h06','h22']},
 {name:'疾速控制',ids:['h27','h14','h23','h12','h11','h25','h30','h18','h17'],core:['h11','h25','h30']},
 {name:'帝国禁锢',ids:['h27','h28','h06','h22','h13','h23','h24','h07','h02'],core:['h13','h27','h24']},
 {name:'儒道协同',ids:['h15','h16','h06','h12','h07','h17','h18','h30','h29'],core:['h15','h07','h17']},
 {name:'楚国速攻',ids:['h21','h29','h26','h12','h11','h25','h30','h31','h17'],core:['h11','h25','h31']},
 {name:'墨家冰控',ids:['h04','h14','h06','h22','h05','h07','h02','h12','h18'],core:['h05','h14','h02']},
 {name:'后排点杀',ids:['h06','h20','h22','h26','h13','h19','h18','h25','h38'],core:['h13','h19','h18']}
];
export function allPool(star=2){return DB.heroes.map(h=>({id:h.id,star:h.rarity==='epic'?0:star}));}
const byId=pool=>Object.fromEntries(pool.map(x=>[x.id,x]));
const tank=id=>H[id].stats.hp+H[id].stats.def*5+(H[id].role==='defense'?450:0)+(['h22','h20','h34'].includes(id)?200:0);
export function arrange(ids){const front=ids.slice().sort((a,b)=>tank(b)-tank(a)).slice(0,4);return [...front,...ids.filter(x=>!front.includes(x)).sort((a,b)=>H[b].stats.speed-H[a].stats.speed)];}
export function mechUtility(active,mechs){const ids=new Set([...active,...mechs]);let value=0;for(const c of DB.combos){const n=c.memberIds.filter(id=>ids.has(id)).length;if(!c.memberIds.some(id=>active.includes(id)))continue;value+=n===c.memberIds.length?3+c.chance*5:n/(c.memberIds.length)*.6;}for(const f of DB.factions){const n=[...ids].filter(id=>H[id].faction===f.id).length;for(const t of f.tiers)value+=n>=t.count?(t.count>=5?2.5:1.2):.15*n/t.count;}return value;}
export function chooseMechs(active,pool,count){let mechs=[];const cand=pool.map(x=>x.id).filter(id=>!active.includes(id));for(let i=0;i<count;i++){let best=cand.filter(x=>!mechs.includes(x)).sort((a,b)=>mechUtility(active,[...mechs,b])-mechUtility(active,[...mechs,a])||a.localeCompare(b))[0];if(best)mechs.push(best);}return mechs;}
export function makeTeam(ids,pool,count=2,name='自选阵容',preserve=false){const map=byId(pool),active=preserve?ids:arrange(ids);return {name,active:active.map(id=>({...map[id]})),mechs:chooseMechs(active,pool,count).map(id=>({...map[id]}))};}
export function opponents(star,count,mode='uniform'){let pool=allPool(star);return templates.map(t=>{const p=pool.map(x=>({...x,star:H[x.id].rarity==='epic'?0:mode==='10+2'?(t.core.includes(x.id)?10:2):mode==='20+2'?(t.core.includes(x.id)?20:2):mode==='20+10'?(t.core.includes(x.id)?20:10):star}));return makeTeam(t.ids,p,count,t.name,true);});}
export function key(team){return team.active.map(x=>x.id).join(',')+'|'+team.mechs.map(x=>x.id).sort().join(',');}
export function candidates(pool,count,locked=[],amount=60,seed=777){const available=pool.filter(x=>H[x.id]?.rarity==='legendary').map(x=>x.id),owned=new Set(pool.map(x=>x.id));if(available.length<9||pool.length<9+count)throw Error(`需至少 9 名传说及合计 ${9+count} 名不同弟子`);if(locked.length>9||locked.some(id=>!available.includes(id)))throw Error('最多锁定 9 名已拥有的传说弟子');const random=rng(seed),out=[],seen=new Set();
 const add=(base,name)=>{let ids=[...new Set([...locked,...base.filter(id=>available.includes(id))])].slice(0,9);while(ids.length<9){const rest=available.filter(x=>!ids.includes(x));ids.push(rest[Math.floor(random()*rest.length)]);}const team=makeTeam(ids,pool,count,name),k=key(team);if(!seen.has(k)){seen.add(k);out.push(team);}};
 for(const t of templates)add(t.ids,t.name);
 for(const f of DB.factions)add(available.filter(id=>H[id].faction===f.id),f.shortName+'协同');
 let tries=0;while(out.length<amount&&tries++<amount*8){const combo=DB.combos[Math.floor(random()*DB.combos.length)];const order=available.map(id=>({id,r:random()})).sort((a,b)=>a.r-b.r).map(x=>x.id);add([...combo.memberIds.filter(x=>owned.has(x)&&H[x].rarity==='legendary'),...order],'探索阵容');}
 return out;
}
export function classifyPool(pool){const stars=pool.filter(x=>H[x.id].rarity==='legendary').map(x=>x.star).sort((a,b)=>b-a);const top=stars[0]||0,bottom=stars.slice(3,9).reduce((a,b)=>a+b,0)/6;if(top>=17&&bottom<6)return {star:2,mode:'20+2'};if(top>=17&&bottom<15)return {star:10,mode:'20+10'};if(top>=8&&bottom<6)return {star:2,mode:'10+2'};return {star:bottom>=15?20:bottom>=6?10:2,mode:'uniform'};}
export function recommend(pool,count,locked=[],progress=()=>{},customOpponents=null){const env=classifyPool(pool),opp=customOpponents||opponents(env.star,count,env.mode);let cs=candidates(pool,count,locked,60);let scored=[];cs.forEach((team,i)=>{scored.push({team,result:evaluate(team,opp.filter((_,j)=>j%2===0),4,12345)});if(i%6===0)progress({stage:'搜索候选',current:i,total:cs.length});});scored.sort((a,b)=>b.result.rate-a.result.rate);
 // Optimize both seat placement and mechanists of promising candidates.
 const random=rng(7863);const mutations=[];for(const entry of scored.slice(0,8))for(let k=0;k<4;k++){let t=structuredClone(entry.team);if(k<2){let a=Math.floor(random()*9),b=Math.floor(random()*9);[t.active[a],t.active[b]]=[t.active[b],t.active[a]];}else{let rest=pool.filter(x=>![...t.active,...t.mechs].some(y=>y.id===x.id));if(rest.length)t.mechs[Math.floor(random()*count)]={...rest[Math.floor(random()*rest.length)]};}mutations.push({team:t,result:evaluate(t,opp.filter((_,j)=>j%2===0),4,12345)});}scored.push(...mutations);scored.sort((a,b)=>b.result.rate-a.result.rate);
 const finalists=[],seen=new Set();for(const s of scored){const k=key(s.team);if(!seen.has(k)){seen.add(k);finalists.push(s.team);}if(finalists.length>=12)break;}
 const result=finalists.map((team,i)=>{progress({stage:'独立种子复核',current:i,total:finalists.length});return {team,result:evaluate(team,opp,24,932771)};}).sort((a,b)=>b.result.rate-a.result.rate);
 const top=[];for(const r of result){if(top.every(x=>x.team.active.filter(y=>r.team.active.some(z=>z.id===y.id)).length<=7)||!top.length)top.push(r);if(top.length===3)break;}for(const r of result)if(top.length<3&&!top.includes(r))top.push(r);
 top.forEach(x=>validateTeam(x.team,count));return {top,candidates:cs.length+mutations.length,environment:env,opponents:opp.length,model:MODEL};
}
export function upgradeAdvice(team,pool,count,progress=()=>{},costs={},budget=null,locked=[]){validateTeam(team,count);const env=classifyPool(pool),opp=opponents(env.star,count,env.mode),seed=510357;const base=evaluate(team,opp,24,seed);const rows=[];const candidates=pool.filter(x=>H[x.id].rarity==='legendary'&&x.star<20);
 for(let i=0;i<candidates.length;i++){const h=candidates[i],targets=[...new Set([h.star+1,...[2,10,20].filter(x=>x>h.star).slice(0,1)])];for(const star of targets){const nextPool=pool.map(x=>x.id===h.id?{...x,star}:x),teamFixed=structuredClone(team);[...teamFixed.active,...teamFixed.mechs].forEach(x=>{if(x.id===h.id)x.star=star;});
   let result=evaluate(teamFixed,opp,24,seed),bestTeam=teamFixed;
   if(!team.active.some(x=>x.id===h.id)){let possibilities=team.active.map((_,idx)=>{if(locked.includes(team.active[idx].id))return null;let t=structuredClone(team);t.active[idx]={id:h.id,star};t.mechs=t.mechs.filter(x=>x.id!==h.id);while(t.mechs.length<count){const ids=[...t.active,...t.mechs].map(x=>x.id);const available=nextPool.filter(x=>!ids.includes(x.id));if(!available.length)break;const best=available.sort((a,b)=>mechUtility(t.active.map(x=>x.id),[...t.mechs.map(x=>x.id),b.id])-mechUtility(t.active.map(x=>x.id),[...t.mechs.map(x=>x.id),a.id]))[0];t.mechs.push(best);}return t;}).filter(Boolean);let scored=possibilities.map(t=>({team:t,result:evaluate(t,opp,4,seed)})).sort((a,b)=>b.result.rate-a.result.rate);if(scored.length){const checked=evaluate(scored[0].team,opp,24,seed);if(checked.rate>result.rate){result=checked;bestTeam=scored[0].team;}}}
   const name=h.id+':'+h.star+'-'+star,cost=Object.hasOwn(costs,name)?Number(costs[name]):null;rows.push({id:h.id,from:h.star,to:star,steps:star-h.star,result,delta:result.rate-base.rate,team:bestTeam,cost,affordable:cost===null||budget===null?null:cost<=budget,newEvolution:[2,10,20].filter(x=>x>h.star&&x<=star)});
  }progress({stage:'比较升星收益',current:i+1,total:candidates.length});}
 rows.sort((a,b)=>b.delta-a.delta);return {base,rows,environment:env};
}
export function developmentPaths(team,pool,count,progress=()=>{},locked=[]){
 const env=classifyPool(pool),opp=opponents(env.star,count,env.mode),base=evaluate(team,opp,16,65321),paths=[];
 const strategies=[{name:'小步提升',step:true},{name:'核心先行',core:true},{name:'换阵发展',milestone:true}];
 for(const strategy of strategies){let t=structuredClone(team),p=structuredClone(pool),steps=[];const core=locked.length?locked:team.active.slice().sort((a,b)=>b.star-a.star||H[b.id].stats.atk-H[a.id].stats.atk).slice(0,3).map(x=>x.id);let last=base;
  for(let round=0;round<3;round++){
   const choices=(strategy.milestone?p:t.active).filter(x=>H[x.id].rarity==='legendary'&&x.star<20&&(!strategy.core||core.includes(x.id)));
   const scored=[];
   for(let ci=0;ci<choices.length;ci++){
    const x=choices[ci],to=strategy.step?x.star+1:[2,10,20].find(s=>s>x.star),nextPool=p.map(y=>y.id===x.id?{...y,star:to}:y);let proposed=[];
    if(t.active.some(y=>y.id===x.id)){const next=structuredClone(t);next.active.find(y=>y.id===x.id).star=to;proposed.push(next);}
    else for(let slot=0;slot<9;slot++){if(locked.includes(t.active[slot].id))continue;const ids=t.active.map(y=>y.id);ids[slot]=x.id;proposed.push(makeTeam(ids,nextPool,count,t.name,true));}
    const shortlist=proposed.map(next=>({id:x.id,from:x.star,to,team:next,result:evaluate(next,opp.filter((_,i)=>i%2===0),4,65321)})).sort((a,b)=>b.result.rate-a.result.rate);
    if(shortlist.length)scored.push(shortlist[0]);
    if(ci%5===0)progress({stage:strategy.name+' · 第 '+(round+1)+' 步',current:ci,total:choices.length});
   }
   scored.sort((a,b)=>(b.result.rate-last.rate)/(strategy.step?1:b.to-b.from)-(a.result.rate-last.rate)/(strategy.step?1:a.to-a.from));if(!scored.length)break;
   const verified=scored.slice(0,5).map(x=>({...x,result:evaluate(x.team,opp,16,65321)})).sort((a,b)=>(b.result.rate-last.rate)/(strategy.step?1:b.to-b.from)-(a.result.rate-last.rate)/(strategy.step?1:a.to-a.from));const best=verified[0];best.delta=best.result.rate-last.rate;best.swapIn=t.active.some(x=>x.id===best.id)?null:best.id;best.swapOut=best.swapIn?t.active.find(x=>!best.team.active.some(y=>y.id===x.id))?.id:null;steps.push(best);t=best.team;p=nextPoolAfter(p,best.id,best.to);last=best.result;progress({stage:'规划发展路线',current:paths.length*3+round+1,total:9});
  }
  paths.push({name:strategy.name,steps,result:last,totalSteps:steps.reduce((v,s)=>v+s.to-s.from,0),delta:last.rate-base.rate});
 }return {base,paths};
}
function nextPoolAfter(pool,id,star){return pool.map(x=>x.id===id?{...x,star}:x);}
