import {setupFeatures} from './activation-context.js?v=v3.4.0-20261109212320';
import {COEFFICIENTS} from './activation-weights.js?v=v3.4.0-20261109212320';
let current=null,features=null;

// One inexpensive learned representative for every roster. This does not
// enumerate the activation state space or pre-select member combinations.
export function screenMechanists(db,active,pool,count,{costIds=[],costLimit=count}={}){
 if(current!==db){current=db;features=setupFeatures(db)}
 const H=Object.fromEntries(db.heroes.map(x=>[x.id,x])),stars=new Map(pool.map(x=>[x.id,x.star])),as=new Set(active),eligible=pool.filter(x=>!as.has(x.id)).map(x=>x.id),allowed=new Set(eligible),costly=new Set(costIds),team={active:active.map(id=>({id,star:stars.get(id)})),mechs:Array.from({length:count},()=>({star:20}))},weights=features.effectWeights(team,COEFFICIENTS),combos=db.combos.filter(c=>c.memberIds.some(id=>as.has(id))&&c.memberIds.every(id=>as.has(id)||allowed.has(id))),chosen=[],present=new Set(active),factions=Object.fromEntries(db.factions.map(f=>[f.id,active.filter(id=>H[id].faction===f.id).length]));let cost=0;
 if(team.active.some(x=>!Number.isInteger(x.star)))throw Error('机师评估缺少上阵弟子星级');
 while(chosen.length<count){let winner=null,best=-Infinity;
  for(const id of eligible){if(present.has(id)||costly.has(id)&&cost>=costLimit)continue;let gain=stars.get(id)*1e-8;
   for(const combo of combos){if(!combo.memberIds.includes(id))continue;const missing=combo.memberIds.filter(id=>!present.has(id)).length,w=weights[combo.id];gain+=w>=0?w/missing:missing===1?w:0}
   for(const tier of db.factions.find(f=>f.id===H[id].faction).tiers){const missing=tier.count-factions[H[id].faction],w=weights[H[id].faction+'@'+tier.count];if(missing>0)gain+=w>=0?w/missing:missing===1?w:0}
   if(gain>best){best=gain;winner=id}
  }
  if(!winner)throw Error('可用机师不足');chosen.push(winner);present.add(winner);factions[H[winner].faction]++;if(costly.has(winner))cost++;
 }
 const factionIndex=new Map(db.factions.map((f,i)=>[f.id,i])),base=db.factions.map(f=>active.filter(id=>H[id].faction===f.id).length),requirements=combos.map(c=>({ids:c.memberIds.filter(id=>!as.has(id)),weight:weights[c.id]}));
 const utility=ids=>{const set=new Set(ids),counts=base.slice();for(const id of ids)counts[factionIndex.get(H[id].faction)]++;let result=0;for(const c of requirements)if(c.ids.every(id=>set.has(id)))result+=c.weight;for(let i=0;i<db.factions.length;i++)for(const tier of db.factions[i].tiers)if(counts[i]>=tier.count)result+=weights[db.factions[i].id+'@'+tier.count];return result};
 let value=utility(chosen);
 for(let pass=0;pass<2;pass++){let improved=false;for(let slot=0;slot<count;slot++)for(const id of eligible){if(chosen.includes(id))continue;const next=chosen.slice();next[slot]=id;if(next.filter(id=>costly.has(id)).length>costLimit)continue;const score=utility(next);if(score>value+1e-9){chosen[slot]=id;value=score;improved=true}}if(!improved)break}
 return chosen;
}
