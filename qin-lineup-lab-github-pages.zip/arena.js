import {PROGRESS_STARS,PROGRESS_STAGES,concentrationVariants} from './stages.js?v=2.1-final-guide-R4-20261015';
import {DB,H,validateTeam,rng,evaluate,teamTraits} from './engine.js?v=2.1-final-guide-R4-20261015';
import {templates,chooseMechs,arrange} from './search.js?v=2.1-final-guide-R4-20261015';
import {combineResults,styleSummary,sampleSeed} from './statistics.js?v=2.1-final-guide-R4-20261015';
export const ARENA_VERSION = 'ARENA-2.1';
export const GROUP_WEIGHTS = {system:.2,representative:.3,exploration:.5};
const validStars = stars => Array.isArray(stars)&&stars.length===9&&stars.every(s=>Number.isInteger(s)&&s>=0&&s<=20);
export function arenaEnvironment({stage='20',mechCount=4,coreCount=2,actualTeam=null,pool=null}={}) {
  if(![2,3,4].includes(mechCount)||![1,2,3].includes(coreCount))throw Error('机师或核心数无效');
  let activeStars;
  if(stage==='actual'){
    if(actualTeam){validateTeam(actualTeam,mechCount);activeStars=actualTeam.active.map(x=>x.star);}
    else {const available=(pool||[]).filter(x=>H[x.id]?.rarity==='legendary').sort((a,b)=>b.star-a.star);if(available.length<9)throw Error('实际环境需要至少9名传说或一套当前阵容');activeStars=available.slice(0,9).map(x=>x.star);}
  }else{
    if(!['2','10','20','10+2','20+2','20+10',...PROGRESS_STAGES].includes(stage))throw Error('需要单一同星或混合环境');
    const [high,low=high]=stage.split('+').map(Number);activeStars=PROGRESS_STARS[stage]?.slice()||Array.from({length:9},(_,i)=>i<coreCount?high:low);
  }
  if(!validStars(activeStars))throw Error('星级分布无效');
  activeStars.sort((a,b)=>b-a);
  const starVariants=PROGRESS_STAGES.includes(stage)||stage==='actual'?concentrationVariants(activeStars,stage==='early'?10:stage==='mid'?17:stage==='actual'?Math.min(20,activeStars[0]+2):20):[activeStars];
  return {stage,mechCount,coreCount,activeStars,starVariants,mechStar:activeStars.at(-1),
    key:`${stage}/${activeStars.join('.')}/${mechCount}/${coreCount}`,
    inference:stage==='actual'?(actualTeam?'当前阵容九人星级分布':'英雄池最高九名传说的星级分布，仅作未选队时的参考'):'固定培养环境'};
}
function coreIds(ids,supplied,count){
  const provided=[...new Set(supplied||[])].filter(id=>ids.includes(id));
  const rest=ids.filter(id=>!provided.includes(id)).sort((a,b)=>H[b].stats.atk-H[a].stats.atk||a.localeCompare(b));
  return [...provided,...rest].slice(0,count);
}
export function projectTeam(template,environment){
  const ids=template.ids??template.active?.map(x=>x.id);
  if(!ids||ids.length!==9||new Set(ids).size!==9||ids.some(id=>H[id]?.rarity!=='legendary'))throw Error('无效的候选阵容');
  const core=coreIds(ids,template.core,environment.coreCount),order=[...core,...ids.filter(id=>!core.includes(id))];
  const stars=new Map(order.map((id,i)=>[id,environment.activeStars[i]]));
  const pool=DB.heroes.map(h=>({id:h.id,star:environment.mechStar}));
  const explicit=template.mechs?.map(x=>typeof x==='string'?x:x.id);
  const mechIds=explicit?.length===environment.mechCount?explicit:chooseMechs(ids,pool,environment.mechCount);
  const team={name:template.name||'探索阵容',active:ids.map(id=>({id,star:stars.get(id)})),mechs:mechIds.map(id=>({id,star:environment.mechStar})),core};
  validateTeam(team,environment.mechCount);return team;
}
export function assertSameEnvironment(team,environment){
  validateTeam(team,environment.mechCount);
  if(!(environment.starVariants||[environment.activeStars]).some(stars=>team.active.map(x=>x.star).sort((a,b)=>b-a).join(',')===stars.join(',')))throw Error('上阵星级分布不一致，不能混入当前环境');
}
export function lineupKey(team,{ignorePositions=false}={}){
  let ids=team.active.map(x=>`${x.id}:${x.star}`);if(ignorePositions)ids.sort();
  return ids.join(',')+'|'+team.mechs.map(x=>`${x.id}:${x.star}`).sort().join(',');
}
export function inferStyle(team){
  const ids=new Set(team.active.map(x=>x.id));
  const count=list=>list.filter(id=>ids.has(id)).length;
  if(count(['h01','h03','h08','h09'])>=3)return '诅咒消耗';
  if(count(['h06','h16','h20','h26','h27','h28','h29'])>=4)return '反击续航';
  if(count(['h14','h17','h18','h23','h27','h30'])>=4)return '控制压制';
  if(count(['h10','h12','h22','h34','h36'])>=3)return '恢复持久';
  return '爆发进攻';
}
export function createOpponentPool(environment,{systems=[],size=60,seed=20261012,rankedCandidates=[]}={}){
  if(!Number.isInteger(size)||size<24||size>240)throw Error('对手池规模需为24—240');
  const entries=[],seen=new Set(),random=rng(seed);
  const add=(template,group,origin)=>{
    const variants=environment.starVariants||[environment.activeStars],projected={...environment,activeStars:variants[entries.length%variants.length]};const team=projectTeam(template,projected),key=lineupKey(team,{ignorePositions:true});
    if(seen.has(key)||entries.length>=size)return false;
    seen.add(key);entries.push({id:`op-${entries.length+1}`,team,group,origin,style:inferStyle(team)});return true;
  };
  for(const t of systems)add({name:t.label,ids:[...t.front,...t.back],core:t.core},'system','游戏推荐（玩家转录），机师由模型补全');
  for(const t of templates)add(t,'representative','机制代表阵容，非真实玩家使用率');
  // Prefer independently screened candidates when available. No rating claims for raw seeds.
  for(const row of rankedCandidates)add(row.team||row,'exploration','候选搜索');
  const legendary=DB.heroes.filter(h=>h.rarity==='legendary');
  for(let attempt=0;entries.length<size&&attempt<size*40;attempt++){
    const base=templates[Math.floor(random()*templates.length)],ids=base.ids.slice();
    const replacements=attempt%3===0?2:1;
    for(let k=0;k<replacements;k++){
      const slot=Math.floor(random()*9),old=H[ids[slot]],available=legendary.filter(h=>!ids.includes(h.id)&&(h.role===old.role||h.faction===old.faction));
      if(available.length)ids[slot]=available[Math.floor(random()*available.length)].id;
    }
    const roles=ids.map(id=>H[id].role);
    if(!roles.includes('support')||!roles.includes('defense')||roles.filter(x=>x==='attack').length<2)continue;
    const team=projectTeam({ids,core:base.core},environment);
    if(!teamTraits(team).combos.length)continue;
    add({name:base.name+'·变阵',ids:arrange(ids),core:base.core},'exploration','同定位/同门派模块变阵，待独立筛选');
  }
  if(entries.length<size)throw Error('合法且互异的对手不足目标数量');
  const groups=[...new Set(entries.map(x=>x.group))],sum=groups.reduce((v,g)=>v+GROUP_WEIGHTS[g],0);
  for(const row of entries){row.weight=GROUP_WEIGHTS[row.group]/sum/entries.filter(x=>x.group===row.group).length;assertSameEnvironment(row.team,environment);}
  return {version:ARENA_VERSION,environment,seed,entries,weights:GROUP_WEIGHTS,
    note:'构造的代表性对手池，非真实竞技场分布；探索候选须在基准生成阶段筛选并冻结，发布保留池版本与权重。'};
}
export function evaluateArena(team,arena,{battles=4000,seed='validation',options={},requireSameEnvironment=true}={}){
  if(requireSameEnvironment)assertSameEnvironment(team,arena.environment);else validateTeam(team,arena.environment.mechCount);
  if(!Number.isInteger(battles)||battles<arena.entries.length*2||battles%2)throw Error('场数须为偶数，且每名对手至少交换先后手一次');
  const sum=arena.entries.reduce((v,x)=>v+x.weight,0);
  const budget=battles/2,remaining=budget-arena.entries.length;
  const allocations=arena.entries.map((row,i)=>{const raw=remaining*row.weight/sum;return {i,pairs:1+Math.floor(raw),fraction:raw%1};});
  let spare=budget-allocations.reduce((v,a)=>v+a.pairs,0);
  for(const a of [...allocations].sort((a,b)=>b.fraction-a.fraction||a.i-b.i)){if(!spare--)break;a.pairs++;}
  const rows=arena.entries.map((row,i)=>{
    assertSameEnvironment(row.team,arena.environment);
    const result=evaluate(team,[row.team],allocations[i].pairs*2,sampleSeed(seed,row.id,0),options);
    if(result.caps)throw Error('出现事件上限截断，结果不能入榜');
    return {id:row.id,style:row.style,group:row.group,weight:row.weight,result};
  });
  const result=combineResults(rows.map(x=>x.result),rows.map(x=>x.weight));
  return {...result,arenaVersion:arena.version,environmentKey:arena.environment.key,seed,opponentCount:rows.length,adaptation:styleSummary(rows),opponents:rows};
}
