// Equipment percentages are added by the engine at the same layer. Late role values
// retain stripped public bonuses, full ordinary fate and role talent, not refinement.
export const LATE_CALIBRATION=Object.freeze({
 level:300,ordinaryPrimary:[1,1,1],numericalScale:12,sharedShield:20899/12,
 awakeningShield:56000/12,addedDamage:28799/12,trueResist:.01,
 roles:{
  attack:{crit:.42,antiCrit:.05,critDamage:.26,critReduce:.08,skillReduce:.12,pierce:.19,inner:.44,resist:0},
  defense:{crit:.21,antiCrit:.22,critDamage:.02,critReduce:.05,skillReduce:.41,pierce:.08,inner:.47,resist:0},
  support:{crit:.26,antiCrit:.05,critDamage:.04,critReduce:.06,skillReduce:.35,pierce:.06,inner:.38,resist:.08}
 }
});
export const defaultPill={attack:'atk',defense:'def',support:'hp'};
export const orangePill={atk:180,def:128,hp:1075};
export const orangeGear={atk:29500,def:22700,hp:181000,inner:1200};
const ordinaryCache=new Map();
export function ordinaryEquipment(role,pos,star){
 const front=pos<4, early=star<20, key=role+front+early;
 if(ordinaryCache.has(key))return ordinaryCache.get(key);
 // Orange equipment is shared across stages; only core continuous progression is halved.
 const s=1/12;
 const out={innerFlat:orangeGear.inner*s, speed:role==='attack'?48:0,block:role==='attack'?0:.20,ignoreAttack:early?0:.01,ignoreDef:early?0:.0075,ignoreInner:early?0:.0625};
 for(const k of ['atk','def','hp']){
  out[k+'Flat']=(orangeGear[k]+orangePill[k]*(1+Number(defaultPill[role]===k)))*s;
 }
 if(!early){
  // Profession star chart plus common TianShu, tree and relic. Faction training
  // was transcribed for attack only and is omitted symmetrically for all roles.
  const chart={attack:[11233,6740,67396],defense:[8491,8302,75475],support:[8257,7339,80731]}[role];
  for(const [i,k] of ['atk','def','hp'].entries()){
   out[k+'Flat']+=(chart[i]+[5321+570+2950,802+285+1475,8262+2280+13275][i])/12;
  }
  const favored={attack:'atk',defense:'def',support:'hp'}[role];
  out[favored]={attack:.07,defense:.14,support:.105}[role];
 }
 // Inherent equipment affixes survive color progression. Reviewed medians from
 // three equipped heroes per role exclude book speed and unlocked book/pill nodes.
 const affixes={attack:{crit:.10,antiCrit:.05,critReduce:.07},defense:{crit:.08,antiCrit:.05,critReduce:.07},support:{pierce:.08}}[role];
 Object.assign(out,affixes);
 out.skillCoefficient={attack:0,defense:.07,support:.14}[role];
 out.skillDodge=(early?0:.01)+(role==='support'?.05:0);
 out.damage=early?0:.0085;
 // Low-rank white tiger's disciple-transfer column, distinct from beast attack.
 for(const [i,k] of ['atk','def','hp'].entries())out[k+'Flat']+=[10650,6390,53251][i]/12;
 const fate={attack:[.25,.16,.12,.30],defense:[.10,.24,.30,.20],support:[.20,.16,.18,.30]}[role];
 for(const [i,k] of ['atk','def','hp'].entries()){
  out[k]=(out[k]||0)+fate[i];
  out[k+'EquipmentFlat']=(orangeGear[k]+orangePill[k]*(1+Number(defaultPill[role]===k)))/12;
 }
 out.inner=fate[3];
 const result=Object.freeze(out);ordinaryCache.set(key,result);return result;
}
const outsideResidual={atk:167276,def:56635,hp:809038};
export function equipmentPrimary(raw,initial,level,late,bonuses,key){
 const skillTraining=initial*85.23*Math.floor(level/5)/45;
 const gear=bonuses[key+'EquipmentFlat']||0;
 const other=(bonuses[key+'Flat']||0)-gear;
 const rate=bonuses[key]||0;
 return ((raw+skillTraining)/12+other)*(1+rate)+gear*(1+.08*rate)
   +outsideResidual[key]*(late?1:.5)/12;
}
export function equipmentInner(role,initialDef,late,bonuses){
 const anchors=(late?{attack:[44050,.2354,65],defense:[44122,.16099,81],support:[35000,.193,78]}:
  {attack:[23073,.16605,65],defense:[23326,.1468,81],support:[23240,.0684,78]})[role];
 // A small retained defense effect distinguishes same-role heroes in conditional
 // inner checks without applying the primary panel conversion a second time.
 const roleBase=anchors[0]*(.9+.1*initialDef/anchors[2])/12;
 return (roleBase+(bonuses.innerFlat||0))*(1+anchors[1]+(role==='attack'?0:.15)+(bonuses.inner||0));
}
