export const LATE_CALIBRATION=Object.freeze({
 level:300,
 ordinaryPrimary:[1.16,1.25,1.16],
 numericalScale:12,
 sharedShield:20899/12,
 awakeningShield:56000/12,
 addedDamage:28799/12,
 trueResist:.01,
 roles:{
  attack:{crit:.50,antiCrit:.10,critDamage:.32,critReduce:.08,skillReduce:.22,pierce:.29,inner:.65,resist:0},
  defense:{crit:.26,antiCrit:.32,critDamage:.02,critReduce:.05,skillReduce:.51,pierce:.13,inner:.47,resist:0},
  support:{crit:.31,antiCrit:.10,critDamage:.04,critReduce:.06,skillReduce:.45,pierce:.11,inner:.38,resist:.08},
 },
});
