export const LATE_CALIBRATION=Object.freeze({
 level:276,
 ordinaryPrimary:[1.16,1.25,1.16],
 numericalScale:12,
 sharedShield:20899/12,
 awakeningShield:56000/12,
 addedDamage:28799/12,
 trueResist:.01,
 roles:{
  attack:{crit:.32,antiCrit:.05,critDamage:.16,critReduce:.08,skillReduce:.12,pierce:.14,inner:.44,resist:0},
  defense:{crit:.21,antiCrit:.17,critDamage:.02,critReduce:.05,skillReduce:.26,pierce:.08,inner:.47,resist:0},
  support:{crit:.21,antiCrit:.05,critDamage:.04,critReduce:.06,skillReduce:.25,pierce:.06,inner:.38,resist:.08},
 },
});
