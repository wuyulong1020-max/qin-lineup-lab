import {DB,H,starFactor,teamTraits} from './engine.js?v=v3.4.0-20261109212320';
import {combatEffectKey,rosterKey} from './search-equivalence.js?v=v3.4.0-20261109212320';
export const PROXY_REVISION='residual-ridge-20261110-v1';
const featureCache=new WeakMap();
function features(team,env,staticCache=null){
 const out=new Map(),put=(k,v=1)=>{if(v)out.set(k,v)},unit=new Map([...team.active,...team.mechs].map(u=>[u.id,u])),ratio=u=>starFactor(u.star)/starFactor(env.star)*(((u.awakening??team.awakening??0)===8&&u.star===20)?1.35:1)/(env.awakening===8?1.35:1),traits=teamTraits(team);
 const cacheKey=staticCache?team.active.map((u,i)=>u.id+':'+u.star+':'+(u.awakening??team.awakening??0)+':'+(i<4?'f':'b')).sort().join('.'):'',cached=staticCache?.get(cacheKey);
 if(cached)for(const [key,value] of cached)put(key,value);
 if(!cached){for(let i=0;i<team.active.length;i++){const u=team.active[i],r=ratio(u);put('hero:'+u.id,r);put((i<4?'front:':'back:')+u.id,r)}
 for(let a=0;a<9;a++)for(let b=a+1;b<9;b++){const x=team.active[a],y=team.active[b],ids=[x.id,y.id].sort();put('pair:'+ids.join('.'),Math.sqrt(ratio(x)*ratio(y)))}
 if(staticCache)staticCache.set(cacheKey,new Map(out));}
 for(const c of DB.combos)if(traits.combos.includes(c.id)){const level=Math.min(...c.memberIds.map(id=>unit.get(id).star));put('combo:'+c.id,(1+.04*level)/(1+.04*env.star));put('casters:'+c.id,c.memberIds.filter(id=>team.active.some(u=>u.id===id)).length/3)}
 for(const f of DB.factions)for(const tier of f.tiers)if(traits.factions[f.id]>=tier.count)put('faction:'+f.id+'@'+tier.count);
 for(const role of ['attack','defense','support'])put('role:'+role,team.active.filter(u=>H[u.id].role===role).length/9);
 for(const stat of ['atk','def','hp','speed']){const div={atk:250,def:100,hp:1000,speed:550}[stat];put('stat:'+stat,team.active.reduce((s,u)=>s+H[u.id].stats[stat]*ratio(u),0)/9/div)}
 put('frontDefense',team.active.slice(0,4).filter(u=>H[u.id].role==='defense').length/4);put('backAttack',team.active.slice(4).filter(u=>H[u.id].role==='attack').length/5);return out;
}
export function trainRosterProxy(rows,env){
 const usable=rows.filter(r=>r?.team?.active?.length===9&&Number.isFinite(r.result?.score));if(usable.length<20)return {revision:PROXY_REVISION,trainingRows:usable.length,predict:()=>0,trainingMAE:null};
 const columns=new Map(),labels=usable.map(r=>r.result.score/100);for(let i=0;i<usable.length;i++)for(const [key,value] of features(usable[i].team,env)){if(!columns.has(key))columns.set(key,[]);columns.get(key).push([i,value])}
 let intercept=labels.reduce((a,b)=>a+b,0)/labels.length,residual=labels.map(y=>y-intercept);const weights=new Map(),vectors=[...columns].map(([key,xs])=>({key,xs,square:xs.reduce((s,[,v])=>s+v*v,0),lambda:key.startsWith('pair:')?6:2}));
 for(let epoch=0;epoch<60;epoch++){for(const col of vectors){const old=weights.get(col.key)||0,numerator=col.xs.reduce((s,[i,v])=>s+v*residual[i],0)+old*col.square,next=numerator/(col.square+col.lambda),delta=next-old;weights.set(col.key,next);for(const [i,v] of col.xs)residual[i]-=delta*v}const delta=residual.reduce((a,b)=>a+b,0)/residual.length;intercept+=delta;residual=residual.map(v=>v-delta)}
 const predictionCache=new Map(),model={revision:PROXY_REVISION,environment:env.key,trainingRows:usable.length,featureCount:columns.size,trainingMAE:100*residual.reduce((s,v)=>s+Math.abs(v),0)/residual.length,intercept,weights:Object.fromEntries(weights)};return {...model,model,predict:team=>100*(intercept+[...features(team,env,predictionCache)].reduce((s,[key,value])=>s+(weights.get(key)||0)*value,0))};
}
export function proxyFromModel(model,env){if(model?.revision!==PROXY_REVISION||model.environment!==env.key)throw Error('候选筛选模型版本不匹配');const predictionCache=new Map();return {...model,predict:team=>100*(model.intercept+[...features(team,env,predictionCache)].reduce((s,[key,value])=>s+(model.weights[key]||0)*value,0))}}
export function libraryProxy(rows,env,model=null){if(model)return proxyFromModel(model,env);const key=env.key;let all=featureCache.get(rows);if(!all){all=new Map();featureCache.set(rows,all)}if(!all.has(key))all.set(key,trainRosterProxy(rows,env));return all.get(key)}
export function selectProxyCandidates(candidates,proxy,{keep=240,routeKeep=36,explore=32,libraryTeams=[],inspectRosters=[]}={}){
 const hash=text=>{let n=2166136261;for(const ch of text)n=Math.imul(n^ch.charCodeAt(0),16777619);return n>>>0};const ranked=candidates.map(x=>({...x,roster:rosterKey(x.team),order:x.team.active.map(u=>u.id).join('.')+'|'+x.team.mechs.map(u=>u.id).sort().join('.'),proxyScore:proxy.predict(x.team)})).sort((a,b)=>b.proxyScore-a.proxyScore||a.order.localeCompare(b.order)),selected=new Map(),add=row=>{const k=combatEffectKey(row.team);if(!selected.has(k))selected.set(k,row)};
 // Keep the best representatives of every nominal roster before splitting budgets.
 const rosterBest=new Map();for(const row of ranked){const k=row.roster;if(!rosterBest.has(k))rosterBest.set(k,row)}for(const row of [...rosterBest.values()].slice(0,keep))add(row);
 const routes=new Map();for(const row of ranked){if(!routes.has(row.route))routes.set(row.route,new Map());const map=routes.get(row.route),k=row.roster;if(!map.has(k)&&map.size<routeKeep)map.set(k,row)}for(const map of routes.values())for(const row of map.values())add(row);
 for(const row of [...rosterBest.values()].map(x=>({...x,hash:hash(x.roster)})).sort((a,b)=>a.hash-b.hash).slice(0,explore))add(row);
 for(const team of libraryTeams)add({team,route:'verified-library',proxyScore:proxy.predict(team)});
 return {leaderRosters:[...rosterBest.keys()].slice(0,6),inspection:inspectRosters.map(key=>({key,rank:[...rosterBest.keys()].indexOf(key)+1,score:rosterBest.get(key)?.proxyScore,selected:[...selected.values()].some(r=>rosterKey(r.team)===key)})),teams:[...selected.values()].map(r=>r.team),rankedRosters:rosterBest.size,selectedRosters:new Set([...selected.values()].map(r=>rosterKey(r.team))).size,selectedConfigurations:selected.size,libraryConfigurations:libraryTeams.length};
}
