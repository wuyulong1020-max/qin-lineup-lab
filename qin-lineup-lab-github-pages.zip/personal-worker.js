import {calibratedStyle} from './presentation.js?v=v3.4.1-20261110110654';
import {bestRosters} from './rank-helpers.js?v=v3.4.1-20261110110654';
import {configure,DB,H,rng,starFactor,validateTeam} from './engine.js?v=v3.4.1-20261110110654';
import {environment,teamFrom as originalTeamFrom,evaluateFixed,classifyStyle,tierOf} from './fixed-arena.js?v=v3.4.1-20261110110654';
import {recommendMechs} from './fast-mechanists.js?v=v3.4.1-20261110110654';import {coresFor} from './analysis.js?v=v3.4.1-20261110110654';
import {libraryRoutes} from './development.js?v=v3.4.1-20261110110654';
import {prepareWorkerData,fullWorkerRow,workerUpgrades} from './worker-data.js?v=v3.4.1-20261110110654';
import {combatEffectKey} from './search-equivalence.js?v=v3.4.1-20261110110654';
import {readScore,writeScore} from './search-score-cache.js?v=v3.4.1-20261110110654';
import {runOptimization,OPTIMIZATION_REVISION,exactTeamKey as teamKey} from './optimization.js?v=v3.4.1-20261110110654';
import {nextUnitUpgrade,UPGRADE_REVISION} from './cultivation-upgrade.js?v=v3.4.1-20261110110654';
let db=null,executed=0,cacheHits=0,cachedBattles=0,knownHits=0,activeDataRevision='',phaseStats={};const memo=new Map(),recommendationHistory=new Map();
function countPhase(phase,cached,n){if(!phase)return;const stats=phaseStats[phase]||(phaseStats[phase]={battles:0,cachedBattles:0,cacheHits:0});if(cached){stats.cachedBattles+=n;stats.cacheHits++}else stats.battles+=n}
const load=p=>fetch(p,{cache:'no-cache'}).then(r=>{if(!r.ok)throw Error('计算资料尚未就绪，请稍后再试');return r.json()});
let scorerPool=null,scorerEnvironment=null,nextScorer=0,requestId=0;const pendingScores=new Map();
async function asyncScore(team,p,n=2400,seed='personal-final',{fresh=false,phase=null}={}){
 const key=OPTIMIZATION_REVISION+'|'+p.revision+'|'+activeDataRevision+'|'+(p.index.dataRevision||p.index.version||'')+'|'+p.index.modelHash+'|'+p.index.poolVersion+'|'+p.key+'|'+combatEffectKey(team)+'|'+n+'|'+seed;if(memo.has(key)){cacheHits++;cachedBattles+=n;countPhase(phase,true,n);return memo.get(key)}const known=!fresh&&p.data.lineups.find(x=>teamKey(x.team)===teamKey(team));if(known&&n>=2400&&!seed.startsWith('paired-')){const full=await fullWorkerRow(p,known);if(full.result?.fullPool&&full.result.n>=n){knownHits++;return full.result}}if(pendingScores.has(key)){cacheHits++;cachedBattles+=n;countPhase(phase,true,n);return pendingScores.get(key)}
 const task=(async()=>{if(n>=2400){const saved=await readScore(key);if(saved){cacheHits++;cachedBattles+=n;countPhase(phase,true,n);memo.set(key,saved);return saved}}if(n===4800){const [a,b]=await Promise.all([asyncScore(team,p,2400,seed,{fresh,phase}),asyncScore(team,p,2400,seed+'/continuation',{fresh,phase})]);const r=merged(a,b);memo.set(key,r);return r}
 if(!scorerPool||scorerEnvironment!==p.key+'|'+p.revision){if(scorerPool)for(const s of await scorerPool)s.worker.terminate();scorerEnvironment=p.key+'|'+p.revision;scorerPool=Promise.all(Array.from({length:Math.max(1,Math.min(3,(navigator.hardwareConcurrency||4)-1))},()=>{const worker=new Worker(new URL('./personal-score-worker.js?v=v3.4.1-20261110110654',import.meta.url),{type:'module'}),waiting=new Map();worker.onmessage=e=>{const v=e.data,handlers=waiting.get(v.id);if(!handlers)return;waiting.delete(v.id);v.error?handlers.reject(Error(v.error)):handlers.resolve(v.result||true)};worker.onerror=e=>{for(const x of waiting.values())x.reject(Error(e.message));waiting.clear()};const ask=msg=>new Promise((resolve,reject)=>{const id=++requestId;waiting.set(id,{resolve,reject});worker.postMessage({id,...msg})});return ask({init:true,db,arena:p.arena}).then(()=>({worker,ask}))}))}
 const pool=await scorerPool,r=await pool[(nextScorer++)%pool.length].ask({team,n,seed});executed+=r.n;countPhase(phase,false,r.n);if(memo.size>=3000)memo.delete(memo.keys().next().value);memo.set(key,r);if(n>=2400)writeScore(key,r);return r})();pendingScores.set(key,task);try{return await task}finally{pendingScores.delete(key)}
}
function personalTeam(ids,env,{name='自选阵容',pool=null,mechs=null}={}){const p=pool||DB.heroes.map(h=>({id:h.id,star:env.star})),units=new Map(p.map(x=>[x.id,x])),team=originalTeamFrom(ids,env,{name,pool:p,mechs:mechs||recommendMechs(ids,p,env.mechCount)});return {...team,active:team.active.map(x=>({...units.get(x.id)})),mechs:team.mechs.map(x=>({...units.get(x.id)}))}}
// Full configurations are authoritative. Comparing or calculating PVE must not
// silently replace the user's mechanists with the automatic recommendation.
function suppliedTeam(t,env,actual=true){return {...t,awakening:t.awakening??env.awakening??0,active:t.active.map(x=>({...x,star:actual?x.star:env.star})),mechs:t.mechs.map(x=>({...x,star:actual?x.star:env.star}))}}
async function prepare(env,action){if(!db){db=await load('./catalog.json');configure(db)}const p=await prepareWorkerData(env,{lineups:['compare','recommend','routes','residual'].includes(action),arena:!['routes','pve'].includes(action)});if(action==='recommend'&&!p.blue)p.blue=await load('./bench/candidates.json');return p}
const send=(id,message,done=0,total=1)=>postMessage({id,type:'progress',message,done,total});
function merged(a,b){const avg=k=>(a[k]*a.n+b[k]*b.n)/(a.n+b.n),styles=a.adaptation.styles.map((x,i)=>({...x,score:(x.score*a.n+b.adaptation.styles[i].score*b.n)/(a.n+b.n)})),values=styles.map(x=>x.score),range=[Math.min(...values),Math.max(...values)];return {...a,n:a.n+b.n,score:avg('score'),rounds:avg('rounds'),metrics:Object.fromEntries(Object.keys(a.metrics).map(k=>[k,(a.metrics[k]*a.n+b.metrics[k]*b.n)/(a.n+b.n)])),halfWidth:Math.hypot(a.halfWidth*a.n,b.halfWidth*b.n)/(a.n+b.n),adaptation:{styles,range,stability:100-range[1]+range[0]}}}
function annotated(team,result,p,count=2){return {id:'personal-'+teamKey(team),name:team.name||'自选阵容',ids:team.active.map(x=>x.id),team,result,style:p.data.styleCalibration?calibratedStyle({team,result},p.data.styleCalibration).name:classifyStyle(team,result).name,core:coresFor(team,p.data,count),tier:tierOf(result.score,p.data.cuts.team)}}
function candidateTeams(pool,locks,p,env){if(locks.length>9||new Set(locks).size!==locks.length)throw Error('最多指定9名不同英雄');const owned=new Map(pool.map(x=>[x.id,x.star])),L=pool.filter(x=>H[x.id].rarity==='legendary');if(L.length<9)throw Error('至少选择9名传说弟子');if(pool.length<9+env.mechCount)throw Error('英雄池不足以安排机师');if(locks.some(id=>!owned.has(id)))throw Error('指定英雄不在英雄池中');const random=rng(20261019),out=[],seen=new Set();
 const power=x=>H[x.id].stats.atk*starFactor(x.star)+H[x.id].stats.hp*starFactor(x.star)*.2+(p.data.heroes.find(y=>y.id===x.id)?.delta||0)*35;
 const sorted=L.slice().sort((a,b)=>power(b)-power(a));
 const add=ids=>{ids=[...new Set(ids)].slice(0,9);for(const id of locks)if(!ids.includes(id)){const choices=ids.map((id,i)=>({id,i,value:power({id,star:owned.get(id)})})).filter(x=>!locks.includes(x.id)).sort((a,b)=>a.value-b.value);if(choices.length)ids[choices[0].i]=id;else ids.push(id)}if(ids.length<9)ids.push(...sorted.map(x=>x.id).filter(id=>!ids.includes(id)));ids=ids.slice(0,9);const key=ids.join('.');if(ids.length!==9||ids.some(id=>!owned.has(id))||seen.has(key))return;out.push({active:ids.map(id=>({id,star:owned.get(id)})),mechs:[]});seen.add(key)};
 // No-lock search contains the same high-star and combo seeds as locked search.
 const bank=p.data.lineups.concat(p.blue.map(b=>({ids:b.ids,result:{score:0}})));for(const b of bank){if(b.ids.every(id=>owned.has(id))&&locks.every(id=>b.ids.includes(id)))add(b.ids)}
 if(locks.length>=8){const arrange=ids=>ids.slice().sort((a,b)=>({defense:0,support:1,attack:2}[H[a].role]-{defense:0,support:1,attack:2}[H[b].role])||H[b].stats.def-H[a].stats.def);if(locks.length===9){add(arrange(locks));return out;}for(const x of sorted.filter(x=>!locks.includes(x.id)))add(arrange([...locks,x.id]));return out;}add(sorted.map(x=>x.id));for(const c of DB.combos){const req=c.memberIds.filter(id=>H[id].rarity==='legendary');if(req.every(id=>owned.has(id)))add([...req,...sorted.map(x=>x.id)])}
 for(let k=0;k<160;k++){const ids=sorted.slice(0,5).map(x=>x.id);while(ids.length<9){const x=L[Math.floor(random()*L.length)];if(!ids.includes(x.id))ids.push(x.id)}add(ids)}
 const proxy=t=>t.active.reduce((s,x)=>s+power(x),0)+DB.combos.filter(c=>c.memberIds.some(id=>t.active.some(x=>x.id===id))&&c.memberIds.filter(id=>!t.active.some(x=>x.id===id)).length<=env.mechCount).length*100;
 return out.sort((a,b)=>proxy(b)-proxy(a));}
async function recommend(msg,p,env){const {pool,locks=[],coreCount=2}=msg,map=new Map(pool.map(x=>[x.id,x.star])),historyKey=OPTIMIZATION_REVISION+'|'+p.revision+'|'+activeDataRevision+'|'+(p.index.dataRevision||p.index.version||'')+'|'+p.key+'|'+pool.map(x=>x.id+':'+x.star).sort().join('.'),history=recommendationHistory.get(historyKey)||new Map();
 const usable=x=>x?.team&&x.team.active.length===9&&x.team.mechs.length===env.mechCount&&[...x.team.active,...x.team.mechs].every(u=>map.get(u.id)===u.star)&&x.result?.fullPool&&x.result.n>=2400;
 for(const x of msg.knownRows||[])if(usable(x))history.set(teamKey(x.team),x);const finish=result=>{for(const x of result.rows)history.set(teamKey(x.team),x);recommendationHistory.set(historyKey,history);return {...result,rows:bestRosters([...history.values()],locks).map(x=>annotated(x.team,x.result,p,coreCount))}};
 const exact=p.data.lineups.filter(x=>x.ids.every(id=>map.has(id)&&map.get(id)===env.star)&&locks.every(id=>x.ids.includes(id))&&x.team.mechs.every(x=>map.get(x.id)===env.star));
 if(pool.every(x=>x.star===env.star)&&exact.length>=(locks.length===9?1:3)){send(msg.id,'已查询同星级阵容库',1,1);return finish({rows:await Promise.all(bestRosters(exact,locks).map(async x=>{const full=await fullWorkerRow(p,x);return annotated(full.team,full.result,p,coreCount)})),mode:'lookup',battles:0,candidateCount:exact.length,scope:'已收录候选中的最高分前三套；固定对手池'})}
 const candidates=candidateTeams(pool,locks,p,env).slice(0,256);send(msg.id,'正在匹配你的英雄池',0,candidates.length);const power=t=>t.active.reduce((s,x)=>s+H[x.id].stats.atk*starFactor(x.star)+H[x.id].stats.hp*starFactor(x.star)*.2+(p.data.heroes.find(y=>y.id===x.id)?.delta||0)*35,0)+DB.combos.filter(c=>c.memberIds.every(id=>[...t.active,...t.mechs].some(x=>x.id===id))&&c.memberIds.some(id=>t.active.some(x=>x.id===id))).length*100;const shortlist=candidates.map(t=>personalTeam(t.active.map(x=>x.id),env,{pool})).sort((a,b)=>power(b)-power(a)).slice(0,64);let done=0;
 let rows=await Promise.all(shortlist.map(async team=>{const result=await asyncScore(team,p,48,'personal-screen');send(msg.id,'匹配可用阵容',++done,shortlist.length);return {team,result}}));rows.sort((a,b)=>b.result.score-a.result.score);done=0;
 let refined=await Promise.all(rows.slice(0,12).map(async x=>{const result=await asyncScore(x.team,p,240,'personal-refine');send(msg.id,'筛选搭配',++done,12);return {team:x.team,result}}));refined.sort((a,b)=>b.result.score-a.result.score);
 const finals=refined.slice(0,3); // Calibrated policy already selected mechanists; avoid noisy 48-game re-selection.

 done=0;await Promise.all(finals.map(async x=>{x.result=await asyncScore(x.team,p,2400);send(msg.id,'生成阵容表现',++done,3)}));finals.sort((a,b)=>b.result.score-a.result.score);
 const cutoff=p.data.cuts.team,close=finals.length>1&&finals[0].result.score-finals[1].result.score<1.5,extra=finals.filter((x,i)=>cutoff.some(c=>Math.abs(x.result.score-c)<x.result.halfWidth)&&x.result.halfWidth>1.5||close&&i<2);done=0;
 await Promise.all(extra.map(async x=>{x.result=await asyncScore(x.team,p,4800);send(msg.id,'完成评分',++done,extra.length)}));
 return finish({rows:finals.sort((a,b)=>b.result.score-a.result.score).map(x=>annotated(x.team,x.result,p,coreCount)),mode:'personal',budgetMax:27360,battles:executed,candidateCount:shortlist.length,scope:'有限候选搜索与固定对手池；不保证穷尽所有组合；T级沿用公共环境阈值'})}

async function handleMessage(e){
 const msg=e.data;currentTaskId=msg.id;yieldRequested=false;executed=0;cacheHits=0;cachedBattles=0;knownHits=0;phaseStats={};activeDataRevision=msg.dataRevision||'';const started=performance.now();
 try{
  const env=environment(msg.star,msg.mechCount),p=await prepare(env,msg.action);let result;
  if(msg.action==='optimize'||msg.action==='residual'){
   const raw=await runOptimization({...msg,...(msg.action==='residual'?{libraryTeams:p.data.lineups.map(x=>x.team),proxyRows:p.data.lineups,proxyModel:p.data.rosterProxy}:{})},env,{revision:p.index.modelHash+'|'+p.index.poolVersion+'|'+(p.index.dataRevision||p.index.version||OPTIMIZATION_REVISION)+'|'+(msg.dataRevision||''),score:(team,n,seed,options)=>asyncScore(team,p,n,seed,options),checkpointRequested:()=>yieldRequested,progress:update=>{postMessage({id:msg.id,type:'progress',...update,bestRows:update.bestRows.map(x=>annotated(x.team,x.result,p,msg.coreCount||2))});if(yieldRequested&&update.checkpoint&&update.phase!=='done'){const error=Error('已保存进度，先完成阵容对比');error.yielded=true;error.checkpoint=update.checkpoint;throw error}}});
   result={...raw,rows:raw.rows.map(x=>annotated(x.team,x.result,p,msg.coreCount||2)),baseline:raw.baseline?annotated(raw.baseline.team,raw.baseline.result,p,msg.coreCount||2):null};
  }else if(msg.action==='recommend')result=await recommend(msg,p,env);
  else if(msg.action==='compare'){
   const rows=await Promise.all(msg.teams.map(async (t,i)=>{const team=suppliedTeam(t,env,!!msg.actual),r=await asyncScore(team,p);send(msg.id,'比较阵容',i+1,msg.teams.length);return annotated(team,r,p,msg.coreCount||2)}));result={rows};
  }else if(msg.action==='upgrade'){
   const team=suppliedTeam(msg.team,env);validateTeam(team,env.mechCount);const candidates=team.active.map(unit=>nextUnitUpgrade(team,unit.id)).filter(Boolean),byId=new Map(candidates.map(row=>[row.id,row])),known=await workerUpgrades(p,teamKey(team));
   const validKnown=known?.length&&known.every(row=>row.quality==='verified'&&row.team&&byId.has(row.id)&&teamKey(row.team)===teamKey(byId.get(row.id).team)&&row.result?.fullPool&&row.result.n>=2400&&row.before?.fullPool&&row.before.n>=2400);
   if(!candidates.length)result={rows:[],complete:true,eligibleCount:0,mode:'personal',upgradeRevision:UPGRADE_REVISION};
   else{
    if(validKnown)result={rows:known.map(row=>({...row,...byId.get(row.id)})),complete:false,eligibleCount:candidates.length,mode:'lookup',upgradeRevision:UPGRADE_REVISION};
    else{
     const base=await asyncScore(team,p,2400,'paired-upgrade'),screenBase=await asyncScore(team,p,240,'paired-upgrade-screen');let done=0;
     const rows=await Promise.all(candidates.map(async row=>{const r=await asyncScore(row.team,p,240,'paired-upgrade-screen');send(msg.id,'比较进化收益',++done,candidates.length);return {...row,result:r,delta:r.score-screenBase.score,before:base}}));rows.sort((a,b)=>b.delta-a.delta);done=0;const count=Math.min(3,rows.length);
     const finals=await Promise.all(rows.slice(0,count).map(async row=>{const r=await asyncScore(row.team,p,2400,'paired-upgrade');send(msg.id,'生成进化建议',++done,count);return {...row,result:r,delta:r.score-base.score}}));result={rows:finals.sort((a,b)=>b.delta-a.delta),complete:false,eligibleCount:candidates.length,mode:'personal',upgradeRevision:UPGRADE_REVISION};
    }
   }
  }else if(msg.action==='routes'){
   const source=suppliedTeam(msg.team,env),selected=libraryRoutes(source,p.data.lineups);let done=0;const rows=await Promise.all(selected.rows.map(async row=>{const full=await fullWorkerRow(p,row);send(msg.id,'查询标准环境发展路线',++done,selected.rows.length);return {...full,...row,result:full.result,core:full.core||coresFor(full.team,p.data,msg.coreCount||2)}}));result={rows,mode:'lookup',scope:'standard-library',actualImprovement:false,referenceMissing:!selected.baseline,baseline:selected.baseline?await fullWorkerRow(p,selected.baseline):null};
  }else if(msg.action==='pve'){
   const f=await load('./bench/pve-'+env.key+'.json'),rows=[];
   for(const [i,t] of msg.teams.entries()){
    const team=suppliedTeam(t,env,msg.actual!==false),known=f[teamKey(team)];if(known){rows.push(known);continue}let pass=0;
    for(let j=0;j<2;j++){const arena=await load('./bench/pve-arena-'+env.key+'-'+j+'.json'),r=evaluateFixed(team,arena,{battles:240,seed:'pve/'+env.key+'/'+j,options:{boost:[{},{hp:j===0?.2:.6}]},details:false});executed+=r.n;pass+=r.wins/r.n/2;send(msg.id,'比较理论推图表现',i*2+j+1,msg.teams.length*2)}
    rows.push({pass,battles:480,scope:'固定理论清敌场景，不代表实际章节'});
   }result={rows};
  }else throw Error('不支持的分析类型');
  postMessage({id:msg.id,type:'done',result:{...result,battles:executed,cache:{hits:cacheHits,battles:cachedBattles,knownHits},phaseStats,elapsedMs:performance.now()-started}});
 }catch(err){postMessage(err.yielded?{id:msg.id,type:'yielded',message:err.message,checkpoint:err.checkpoint,battles:executed,cache:{hits:cacheHits,battles:cachedBattles,knownHits},phaseStats}:{id:msg.id,type:'error',message:err.message})}finally{currentTaskId=null;yieldRequested=false}
}
// A worker can receive another message while awaiting its score workers. Keep
// environment snapshots, counters and scoring workers exclusive to one task.
let taskQueue=Promise.resolve(),currentTaskId=null,yieldRequested=false;
onmessage=e=>{if(e.data.type==='yield'){if(e.data.id===currentTaskId)yieldRequested=true;return}taskQueue=taskQueue.then(()=>handleMessage(e)).catch(err=>postMessage({id:e.data.id,type:'error',message:err.message}))};
