const canvas = document.querySelector('main');
let pending = 0;
const properties = ['--share-top', '--share-left', '--share-width', '--share-scale'];
const mobile = () => matchMedia('(max-width: 760px)').matches || (matchMedia('(pointer: coarse)').matches && innerWidth <= 1024);

export function resetShareFit() {
  cancelAnimationFrame(pending);
  pending = 0;
  if (document.body.classList.contains('share-fit')) document.body.classList.remove('share-fit');
  if (document.documentElement.classList.contains('share-fit-root')) document.documentElement.classList.remove('share-fit-root');
  for (const name of properties) canvas.style.removeProperty(name);
}

export function fitShareView() {
  cancelAnimationFrame(pending);
  pending = 0;
  if (!canvas || !document.body.classList.contains('share-mode') || !mobile()) {
    resetShareFit();
    return;
  }
  const viewport = window.visualViewport;
  const width = viewport?.width || innerWidth;
  const height = viewport?.height || innerHeight;
  const availableWidth = Math.max(1, width - 16);
  if (!document.body.classList.contains('share-fit')) document.body.classList.add('share-fit');
  if (!document.documentElement.classList.contains('share-fit-root')) document.documentElement.classList.add('share-fit-root');
  const exit = document.querySelector('.share-exit');
  const exitHeight = exit?.getBoundingClientRect().height || 32;
  const exitBottom = exit ? parseFloat(getComputedStyle(exit).bottom) || 8 : 8;
  const availableHeight = Math.max(1, height - exitHeight - exitBottom - 24);
  canvas.style.setProperty('--share-top', `${(viewport?.offsetTop || 0) + 8}px`);
  canvas.style.setProperty('--share-left', `${(viewport?.offsetLeft || 0) + width / 2}px`);
  // Try a few widths to keep the text as large as possible while fitting both axes.
  let best = {width: availableWidth, scale: 0};
  const widths = [...new Set([availableWidth, 360, 400, 440, 480, 540, 600, 720, 900].filter(w => w >= availableWidth && w <= Math.max(900, availableWidth)))];
  for (const candidate of widths) {
    canvas.style.setProperty('--share-width', `${candidate}px`);
    const contentWidth = Math.max(canvas.offsetWidth, canvas.scrollWidth);
    const contentHeight = Math.max(canvas.offsetHeight, canvas.scrollHeight);
    const scale = Math.min(1, availableWidth / contentWidth, availableHeight / Math.max(1, contentHeight));
    if (scale > best.scale) best = {width: candidate, scale};
  }
  canvas.style.setProperty('--share-width', `${best.width}px`);
  canvas.style.setProperty('--share-scale', String(best.scale));
}

function scheduleFit() {
  cancelAnimationFrame(pending);
  pending = requestAnimationFrame(fitShareView);
}
window.addEventListener('resize', scheduleFit);
window.addEventListener('orientationchange', scheduleFit);
window.visualViewport?.addEventListener('resize', scheduleFit);
window.visualViewport?.addEventListener('scroll', scheduleFit);
document.fonts?.ready.then(scheduleFit);
canvas.addEventListener('load', scheduleFit, true);
canvas.addEventListener('toggle', scheduleFit, true);
new MutationObserver(scheduleFit).observe(canvas, {childList: true, subtree: true, characterData: true});
new MutationObserver(() => {
  if (!document.body.classList.contains('share-mode')) resetShareFit();
  else scheduleFit();
}).observe(document.body, {attributes: true, attributeFilter: ['class']});
