export const APP_VERSION='v2.1';
export const PLAN_REVISION='R4';
export const RELEASE_STATE='第1次正式升级 · 省心配队 · 2026-10-15 · 已验收';
