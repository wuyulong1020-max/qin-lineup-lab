export const APP_VERSION='v2.1-rc.1';
export const PLAN_REVISION='R4';
export const RELEASE_STATE='待用户验收，尚未归档正式升级编号';
