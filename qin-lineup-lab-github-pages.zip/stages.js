export const PROGRESS_STAGES=['early','mid','late'];
export const PROGRESS_LABELS={early:'前期',mid:'中期',late:'后期'};
export const PROGRESS_STARS={early:[10,9,7,6,5,4,3,2,2],mid:[13,10,10,9,8,8,7,7,6],late:[20,18,16,14,12,10,10,8,6]};
export function inferProgress(pool=[],heroes={},team=null){
 const units=team?.active||pool.filter(x=>heroes[x.id]?.rarity==='legendary').sort((a,b)=>b.star-a.star).slice(0,9);
 const stars=units.map(x=>x.star).sort((a,b)=>b-a);if(!stars.length)return {stage:'late',source:'default',notice:'未填写资源，使用后期公共参考'};
 const max=stars[0],second=stars[1]||0,median=stars[Math.floor(stars.length/2)],evolved=stars.filter(s=>s>=10).length;
 const stage=max<=10?'early':max>=18&&second>=10?'late':'mid';
 return {stage,source:'inferred',max,second,median,evolved,stars,notice:`按主力分布推测${PROGRESS_LABELS[stage]}：最高${max}星，中位${median}星，${evolved}人达到10星`};
}
// Different concentration patterns retain the same total star budget. They are
// explicit constructed scenarios, never estimated player adoption rates.
export function concentrationVariants(stars,maxStar=20){
 const base=stars.slice().sort((a,b)=>b-a),concentrated=base.slice(),balanced=base.slice();
 for(let i=8;i>=4;i--){const receiver=concentrated[0]<maxStar?0:concentrated[1]<maxStar?1:-1;if(receiver<0)break;const move=Math.min(2,maxStar-concentrated[receiver],Math.max(0,concentrated[i]-2));concentrated[receiver]+=move;concentrated[i]-=move;}
 for(let i=0;i<2;i++){const to=balanced.length-1-i,move=Math.min(2,Math.max(0,balanced[i]-balanced[2]),20-balanced[to]);balanced[i]-=move;balanced[to]+=move;}
 return [...new Map([base,concentrated,balanced].map(x=>[x.sort((a,b)=>b-a).join('.'),x])).values()];
}
