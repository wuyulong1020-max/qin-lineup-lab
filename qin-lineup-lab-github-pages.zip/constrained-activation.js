import {setupFeatures} from './activation-context.js?v=v3.3.0-20261109094509';
import {COEFFICIENTS,OVERRIDES} from './activation-weights.js?v=v3.3.0-20261109094509';

// A constraint must participate in state merging. Filtering a representative
// after activation-space compression can discard an affordable representative
// with exactly the same activated effects.
export function constrainedEffectSpace(db,active,count,{pool=db.heroes.map(x=>x.id),required=[],forbidden=[],costIds=[],costLimit=count}={}){
 const H=Object.fromEntries(db.heroes.map(h=>[h.id,h])),F=db.factions,as=new Set(active),ban=new Set(forbidden),costly=new Set(costIds),allowed=pool.filter(id=>!as.has(id)&&!ban.has(id)),req=[...new Set(required)],requiredCost=req.filter(id=>costly.has(id)).length;
 if(req.length>count||req.some(id=>!allowed.includes(id))||allowed.length<count||requiredCost>costLimit)return [];
 const base=F.map(f=>active.filter(id=>H[id].faction===f.id).length),caps=F.map((f,i)=>Math.max(0,Math.min(count,Math.max(...f.tiers.map(t=>t.count))-base[i])));
 const combos=db.combos.filter(c=>c.memberIds.some(id=>as.has(id))&&c.memberIds.filter(id=>!as.has(id)).length<=count&&c.memberIds.every(id=>as.has(id)||allowed.includes(id))),relevant=[...new Set(combos.flatMap(c=>c.memberIds.filter(id=>!as.has(id))))],bits=new Map(relevant.map((id,i)=>[id,1n<<BigInt(i)])),masks=combos.map(c=>({id:c.id,mask:c.memberIds.reduce((n,id)=>n|(bits.get(id)||0n),0n)}));
 const groups=new Map();for(const id of allowed.filter(id=>!req.includes(id))){const fi=F.findIndex(f=>f.id===H[id].faction),mask=bits.get(id)||0n,key=fi+'|'+mask.toString();if(!groups.has(key))groups.set(key,{fi,mask,ids:[]});groups.get(key).ids.push(id)}
 for(const group of groups.values())group.ids.sort((a,b)=>Number(costly.has(a))-Number(costly.has(b))||a.localeCompare(b));
 let states=[{n:req.length,mask:req.reduce((n,id)=>n|(bits.get(id)||0n),0n),counts:F.map((f,i)=>Math.min(caps[i],req.filter(id=>H[id].faction===f.id).length)),cost:requiredCost,ids:req}];
 for(const group of groups.values()){
  const next=new Map();for(const state of states)for(let q=0;q<=Math.min(group.ids.length,count-state.n);q++){
   const picked=group.ids.slice(0,q),cost=state.cost+picked.filter(id=>costly.has(id)).length;if(cost>costLimit)continue;
   const counts=state.counts.slice();counts[group.fi]=Math.min(caps[group.fi],counts[group.fi]+q);const mask=state.mask|(q?group.mask:0n),n=state.n+q,key=n+'|'+mask.toString()+'|'+counts.join(',')+'|'+cost;
   if(!next.has(key))next.set(key,{n,mask,counts,cost,ids:state.ids.concat(picked)});
  }states=[...next.values()];
 }
 const out=new Map();for(const state of states)if(state.n===count){const combos=masks.filter(c=>(state.mask&c.mask)===c.mask).map(c=>c.id).sort(),factions=F.flatMap((f,i)=>f.tiers.filter(t=>base[i]+state.counts[i]>=t.count).map(t=>f.id+'@'+t.count)),key=combos.join('.')+'|'+factions.join('.'),old=out.get(key);if(!old||state.cost<old.cost)out.set(key,{key,combos,factions,mechs:state.ids,cost:state.cost})}return [...out.values()];
}

let current=null,features=null;
export function constrainedMechSearch(db,active,pool,count,{costIds=[],costLimit=count,limit=4}={}){
 if(current!==db){current=db;features=setupFeatures(db)}
 const stars=new Map(pool.map(x=>[x.id,x.star])),team={active:active.map(id=>({id,star:stars.get(id)})),mechs:Array.from({length:count},()=>({star:20}))},weights=features.effectWeights(team,COEFFICIENTS),states=constrainedEffectSpace(db,active,count,{pool:pool.map(x=>x.id),costIds,costLimit}),sorted=states.map(state=>({state,value:[...state.combos,...state.factions].reduce((sum,id)=>sum+weights[id],0)})).sort((a,b)=>b.value-a.value||a.state.key.localeCompare(b.state.key));
 if(team.active.some(x=>!Number.isInteger(x.star)))throw Error('机师评估缺少上阵弟子星级');
 let options=sorted.map(x=>x.state.mechs);const verified=OVERRIDES[team.active.map(x=>x.id+':'+x.star).join('.')+'|'+count],costly=new Set(costIds);
 if(verified&&team.active.every(x=>x.star===team.active[0].star)&&verified.every(id=>stars.get(id)===team.active[0].star&&!active.includes(id))&&verified.filter(id=>costly.has(id)).length<=costLimit)options=[verified,...options.filter(xs=>xs.slice().sort().join('.')!==verified.slice().sort().join('.'))];
 return {states,options:options.slice(0,limit)};
}
