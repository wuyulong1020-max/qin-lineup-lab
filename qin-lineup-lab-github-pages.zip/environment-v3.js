import {selectedAccount,currentFormation} from './profiles.js?v=2.1-final-guide-R4-20261015';
import {inferProgress,PROGRESS_STAGES,PROGRESS_LABELS,PROGRESS_STARS} from './stages.js?v=2.1-final-guide-R4-20261015';
export const STAGES=['2','10','20','total',...PROGRESS_STAGES];
export const TOTAL_WEIGHTS={2:.2,10:.4,20:.4};export const EVOLUTION_STARS=[2,10,20];
const personalPages=new Set(['home','team','growth','path','compare']);
export const environmentKey=(page,scope,accountId)=>`v3-game|${accountId??'public'}`;
export function resolveEnvironment(store,catalog,{page,scope='all'}={}){
 const account=selectedAccount(store),formation=currentFormation(store,catalog),H=Object.fromEntries(catalog.heroes.map(h=>[h.id,h]));
 if(page==='insights'&&scope==='current'&&!formation?.usable)scope='all';
 const personal=personalPages.has(page)||page==='insights'&&scope==='current',hasPool=!!account?.pool.length,key=environmentKey(page,scope,account?.id),saved=store.environments[key]||{},inferred=inferProgress(account?.pool||[],H,formation?.formation.source==='reference'?null:formation?.team);
 const progressStage=saved.manualProgress&&PROGRESS_STAGES.includes(saved.progressStage)?saved.progressStage:personal&&hasPool?inferred.stage:'late';
 const boardMode=saved.boardMode==='pure'?'pure':'progress',pureStage=['2','10','20','total'].includes(saved.pureStage)?saved.pureStage:'total';
 const stage=personal&&hasPool?'actual':boardMode==='pure'?pureStage:progressStage;
 return {key,stage,progressStage,opponentStage:saved.manualProgress?progressStage:null,manualProgress:!!saved.manualProgress,boardMode,pureStage,mechCount:personal&&hasPool?Math.min(saved.mechCount??account.mechCount,account.mechCount):(saved.mechCount??4),mode:stage==='actual'?'actual':'theory',poolSource:personal&&hasPool?'owned':'all',scope,personal,hasPool,inferred,
  needsStartingTeam:['growth','path','compare'].includes(page)&&!formation?.usable,
  notice:personal&&hasPool?`按英雄池实际星级 · ${saved.manualProgress?'挑战所选':'自动匹配'}${PROGRESS_LABELS[progressStage]}对手`:(boardMode==='pure'?'全员同星研究 · 不修改个人资源':`${PROGRESS_LABELS[progressStage]}混合培养参考`) };
}
export function rememberEnvironment(store,context,value,catalog){const e=resolveEnvironment(store,catalog,context),next=structuredClone(store),old=next.environments[e.key]||{};const v={stage:'actual',mechCount:e.mechCount,progressStage:e.progressStage,boardMode:e.boardMode,pureStage:e.pureStage,manualProgress:e.manualProgress,...old,...value};
 if(value.stage&&value.stage!=='actual'){if(PROGRESS_STAGES.includes(value.stage)){v.progressStage=value.stage;v.manualProgress=true;v.boardMode='progress';}else if(['2','10','20','total'].includes(value.stage)){v.pureStage=value.stage;v.boardMode='pure';}else throw Error('环境无效');}
 if(![2,3,4].includes(v.mechCount)||!PROGRESS_STAGES.includes(v.progressStage)||!['progress','pure'].includes(v.boardMode)||!['2','10','20','total'].includes(v.pureStage))throw Error('环境参数无效');
 v.stage=v.boardMode==='pure'?v.pureStage:v.progressStage;next.environments[e.key]=v;return next;
}
export function effectivePool(store,catalog,e,cores=[]){const account=selectedAccount(store),pool=e.poolSource==='owned'&&account?account.pool:catalog.heroes.map(h=>({id:h.id,star:2}));if(e.stage==='actual')return structuredClone(pool);if(e.stage==='total')throw Error('加权总榜不是单场环境，请选择2／10／20星进行具体对战');
 const star=PROGRESS_STARS[e.stage]?.at(-1)??Number(e.stage);return pool.map(x=>({id:x.id,star}));}
