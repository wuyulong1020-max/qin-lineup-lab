import{DB,teamTraits}from'./engine.js?v=v3.1.1-20261106122355';import{tierOf}from'./fixed-arena.js?v=v3.1.1-20261106122355';import{bestRosters}from'./rank-helpers.js?v=v3.1.1-20261106122355';
export function commonComboRows(data,{basis='overall',metric='score',style='爆发速攻'}={}){
 const candidates=data.lineups.filter(x=>['T0','T1','T2'].includes(tierOf(x.result.score,data.cuts.team))&&(basis!=='style'||x.style===style));
 return DB.combos.map(combo=>{const xs=candidates.filter(x=>teamTraits(x.team).combos.includes(combo.id));return{...combo,count:xs.length,score:xs.length?xs.reduce((s,x)=>s+x.result.score,0)/xs.length:0,stability:xs.length?xs.reduce((s,x)=>s+x.result.adaptation.stability,0)/xs.length:0,teams:bestRosters(xs,[],3)}}).filter(x=>x.count).sort((a,b)=>(basis==='overall'&&metric==='stability'?b.stability-a.stability:b.score-a.score)||b.count-a.count||a.id.localeCompare(b.id));
}
