import {DB,teamTraits} from './engine.js?v=v4.0.0-20261124034734';
import {tierOf} from './front-arena.js?v=v4.0.0-20261124034734';
import {FACTION_STYLES,factionProfile,primaryStyle} from './faction-styles.js?v=v4.0.0-20261124034734';
import {activeRosterKey} from './team-families.js?v=v4.0.0-20261124034734';
export const COMMON_COMBO_VERSION='six-factions-per-roster-v346';
function configurations(data){return data.lineups.flatMap(row=>[row,...(row.formationVariants||[])].map(form=>{const style=form.factionStyle??primaryStyle(factionProfile(form.team));return{row:{...form,style,formationVariants:[],variants:[]},key:activeRosterKey(form.team),combos:teamTraits(form.team).combos};})).filter(x=>Number(tierOf(x.row.result.score,data.cuts.team).slice(1))<=2);}
function compute(data,{basis='overall',metric='score',style=FACTION_STYLES[0]}={},forms=configurations(data)){
 const value=basis==='overall'&&metric==='stability'?r=>r.result.adaptation.stability:r=>r.result.score;
 return DB.combos.map(combo=>{const byNine=new Map();for(const x of forms){if(!x.combos.includes(combo.id)||(basis==='style'&&x.row.style!==style))continue;const old=byNine.get(x.key);if(!old||value(x.row)>value(old)||value(x.row)===value(old)&&x.row.result.score>old.result.score)byNine.set(x.key,x.row);}const xs=[...byNine.values()],mean=fn=>xs.length?xs.reduce((s,x)=>s+fn(x),0)/xs.length:0;return{...combo,count:xs.length,score:mean(x=>x.result.score),stability:mean(x=>x.result.adaptation.stability),teams:xs.slice().sort((a,b)=>value(b)-value(a)||b.result.score-a.result.score||activeRosterKey(a.team).localeCompare(activeRosterKey(b.team))).slice(0,3)};}).filter(x=>x.count);
}
export function buildCommonComboPresets(data){const forms=configurations(data);return{version:COMMON_COMBO_VERSION,basis:'Filter every measured formation by combination, fixed team tier and actual activated faction and deployment; select the highest matching score/stability configuration for each distinct nine-person roster, then average those rosters equally.',overall:{score:compute(data,{metric:'score'},forms),stability:compute(data,{metric:'stability'},forms)},styles:Object.fromEntries(FACTION_STYLES.map(style=>[style,compute(data,{basis:'style',style},forms)]))};}
export function commonComboRows(data,{basis='overall',metric='score',style=FACTION_STYLES[0],sort='score'}={}){
 const presets=data.commonComboPresets,ready=presets?.version===COMMON_COMBO_VERSION,rows=ready?(basis==='style'?presets.styles[style]:presets.overall[metric==='stability'?'stability':'score']):compute(data,{basis,metric,style});
 return rows.slice().sort((a,b)=>(sort==='count'?b.count-a.count:0)||(basis==='overall'&&metric==='stability'?b.stability-a.stability:b.score-a.score)||b.count-a.count||a.id.localeCompare(b.id));
}
