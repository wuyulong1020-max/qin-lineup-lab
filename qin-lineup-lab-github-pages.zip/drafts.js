import {updateAccount,selectedAccount,persistStore} from './profiles.js?v=v3.1.2-20261106195732';
const copy=x=>structuredClone(x);
export const DRAFT_KEY='qin-lab-drafts-1';
// Draft storage is separate from the user's saved accounts. Analysis may consume
// drafts, but only explicit save() can update the account save.
export class DraftBook{
 constructor(storage,catalog){this.storage=storage;this.catalog=catalog;this.items={};this.undoStack={};this.error=null;try{const x=JSON.parse(storage.getItem(DRAFT_KEY)||'{}');if(x&&typeof x==='object'&&!Array.isArray(x))this.items=x;}catch{this.error='临时草稿无法读取，已保存账号未受影响。';}}
 flush(){try{this.storage.setItem(DRAFT_KEY,JSON.stringify(this.items));return true;}catch{this.error='临时草稿暂存失败；请及时保存或导出。';return false;}}
 effective(store,id=store.selectedAccountId){const d=this.items[id];if(!d)return store;try{return updateAccount(store,id,d,this.catalog);}catch{return store;}}
 isDirty(store,id=store.selectedAccountId){return !!this.items[id]&&JSON.stringify(this.effective(store,id).accounts.find(a=>a.id===id))!==JSON.stringify(store.accounts.find(a=>a.id===id));}
 set(store,patch,id=store.selectedAccountId){if(!id)throw Error('请先新建账号');const a=this.effective(store,id).accounts.find(a=>a.id===id);const validated=updateAccount(store,id,{pool:a.pool,locked:a.locked,mechCount:a.mechCount,...patch},this.catalog).accounts.find(a=>a.id===id);(this.undoStack[id]??=[]).push(copy(this.items[id]??null));if(this.undoStack[id].length>20)this.undoStack[id].shift();this.items[id]={pool:validated.pool,locked:validated.locked,mechCount:validated.mechCount};this.flush();return this.effective(store,id);}
 undo(id){const s=this.undoStack[id];if(!s?.length)return false;const previous=s.pop();if(previous)this.items[id]=previous;else delete this.items[id];this.flush();return true;}
 discard(id){delete this.items[id];delete this.undoStack[id];this.flush();}
 save(store,id=store.selectedAccountId){const next=this.effective(store,id);const result=persistStore(this.storage,next,this.catalog);if(!result.ok)throw Error(result.error);this.discard(id);return next;}
}
export function quickPool(catalog,{main=[],reserves=[],restStar=2}={}){
 if(main.length!==9||main.some(x=>!x.id))throw Error('请选满9名主力');
 if(reserves.length<4||reserves.length>6)throw Error('备用位置应为4—6个，可以留空');
 const validStar=s=>Number.isInteger(s)&&s>=0&&s<=20;
 if(!validStar(restStar))throw Error('其余弟子星级需为0—20');
 const H=Object.fromEntries(catalog.heroes.map(h=>[h.id,h])),used=new Set(),minimum=Math.min(...main.map(x=>x.star??10));
 const explicit=[...main.map(x=>({...x,star:x.star??10,active:true})),...reserves.filter(x=>x.id).map(x=>({...x,star:x.star??minimum,active:false}))];
 for(const x of explicit){if(!H[x.id]||used.has(x.id))throw Error('弟子不存在或重复选择');if(x.active&&H[x.id].rarity!=='legendary')throw Error('史诗只能作备用机师');if(!validStar(x.star))throw Error('星级需为0—20');used.add(x.id);}
 const assigned=new Map(explicit.map(x=>[x.id,x.star]));return catalog.heroes.map(h=>({id:h.id,star:assigned.get(h.id)??restStar}));
}
export function quickTemplate(account,catalog){const legendary=new Set(catalog.heroes.filter(h=>h.rarity==='legendary').map(h=>h.id));const saved=account?.formations.find(f=>f.id===account.currentFormationId);const mainIds=saved?.team.active.map(x=>x.id)||account?.pool.filter(x=>legendary.has(x.id)).sort((a,b)=>b.star-a.star).slice(0,9).map(x=>x.id)||[];const own=new Map(account?.pool.map(x=>[x.id,x.star])||[]);return {main:Array.from({length:9},(_,i)=>({id:mainIds[i]||'',star:own.get(mainIds[i])??10})),reserves:Array.from({length:4},()=>({id:'',star:null})),restStar:2};}
