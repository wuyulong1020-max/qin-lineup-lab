import {DB,H,C,validateTeam,evaluate,teamTraits,rng} from './engine.js?v=2.1-final-guide-R4-20261015';
import {candidates,chooseMechs,arrange,allPool} from './search.js?v=2.1-final-guide-R4-20261015';
import {arenaEnvironment,projectTeam,createOpponentPool,evaluateArena,lineupKey,inferStyle} from './arena.js?v=2.1-final-guide-R4-20261015';
import {sampleSeed} from './statistics.js?v=2.1-final-guide-R4-20261015';
const clone=x=>structuredClone(x),ids=t=>t.active.map(x=>x.id),sort=rows=>rows.sort((a,b)=>b.result.score-a.result.score);
const summary=r=>{const {opponents,...rest}=r;return rest;};
export function coreLabels(team,result,count=2,locked=[]){
 const list=team.active.map(x=>x.id),metrics=result?.byHero||{},contributions=result?.coreContributions||team.coreContributions;if(contributions?.length){const chosen=[...new Set([...locked,...contributions.slice().sort((a,b)=>b.delta-a.delta).map(x=>x.id)])].filter(id=>list.includes(id)).slice(0,count);return chosen.map(id=>({...contributions.find(x=>x.id===id),id,role:H[id].role,description:(H[id].tags||[]).slice(0,2).join(' · ')}));}
 const maximum=key=>Math.max(1,...Object.values(metrics).map(m=>m[key]||0));
 const importance=id=>{const m=metrics[id]||{};return (m.damage||0)/maximum('damage')+(m.heal||0)/maximum('heal')*.8+(m.controlInflicted||0)/maximum('controlInflicted')*.6+(m.redistributedGain||0)/maximum('redistributedGain')*.5;};
 const chosen=[...new Set(locked)].filter(id=>list.includes(id));
 const high=team.active.filter(x=>x.star>Math.min(...team.active.map(x=>x.star))).map(x=>x.id);
 for(const id of [...high,...list.sort((a,b)=>importance(b)-importance(a)||H[b].stats.atk-H[a].stats.atk)])if(chosen.length<count&&!chosen.includes(id))chosen.push(id);
 return chosen.slice(0,count).map(id=>({id,role:H[id].role,description:(H[id].tags||[]).slice(0,2).join(' · ')||'技能协同',basis:metrics[id]?'输出、治疗、控制及均血贡献综合标注':'技能定位与培养星级标注'}));
}
export function personalArena({stage='actual',count=4,pool=[],team=null,coreCount=2,systems=[],reference=null,opponentStage=null}){
 const actualStage=stage==='actual'&&opponentStage?opponentStage:stage;const env=arenaEnvironment(actualStage==='actual'?{stage:actualStage,mechCount:count,coreCount,actualTeam:team,pool}:{stage:actualStage,mechCount:count,coreCount});
 if(reference?.environment.key===env.key)return reference;
 return createOpponentPool(env,{systems,size:60,seed:sampleSeed('personal-arena',env.key,0),rankedCandidates:reference?.entries?.map(x=>x.team)||[]});
}
function reproject(team,context){
 if(context.stage==='actual')return team;
 const env=arenaEnvironment({stage:context.stage,mechCount:context.count,coreCount:context.coreCount||2});
 return projectTeam({...team,core:context.locked?.length?context.locked:team.core},env);
}
function unique(rows){const seen=new Set();return rows.filter(x=>{const k=lineupKey(x.team);if(seen.has(k))return false;seen.add(k);return true;});}
export function diverseTop(rows,n=3){const out=[];for(const overlap of [6,7,8,9])for(const row of rows){if(out.length>=n)break;if(out.includes(row))continue;if(out.every(x=>ids(x.team).filter(id=>ids(row.team).includes(id)).length<=overlap))out.push(row);}return out;}
export function recommendV2(context,progress=()=>{}){
 const {pool,count,locked=[],coreCount=2}=context;if(locked.length>3||locked.length>coreCount)throw Error('核心数量超过所选人数');
 const arena=personalArena(context),batch=context.quick?24:96;
 const cs=candidates(pool,count,locked,batch,32291).map(t=>reproject(t,context));let evaluated=[];
 cs.forEach((team,i)=>{evaluated.push({team,result:summary(evaluateArena(team,arena,{battles:120,seed:`personal-screen/${i}`,requireSameEnvironment:context.stage!=='actual'}))});progress({stage:'筛选自有英雄池阵容',current:i+1,total:cs.length});});
 const random=rng(23231),mutations=[];
 for(const row of sort(evaluated).slice(0,8))for(let i=0;i<3;i++){
  const team=clone(row.team);if(i<2){const a=Math.floor(random()*9),b=Math.floor(random()*9);[team.active[a],team.active[b]]=[team.active[b],team.active[a]];}
  else{const rest=pool.filter(x=>![...team.active,...team.mechs].some(y=>y.id===x.id));if(rest.length)team.mechs[Math.floor(random()*count)]=clone(rest[Math.floor(random()*rest.length)]);}
  mutations.push({team,result:summary(evaluateArena(team,arena,{battles:120,seed:`personal-mutation/${mutations.length}`,requireSameEnvironment:context.stage!=='actual'}))});
 }
 const shortlist=diverseTop(sort(unique([...evaluated,...mutations])),context.quick?3:6),verified=[];
 shortlist.forEach((row,i)=>{progress({stage:'独立验证推荐阵容',current:i+1,total:shortlist.length});const result=summary(evaluateArena(row.team,arena,{battles:context.quick?240:4000,seed:`personal-validation/${lineupKey(row.team)}`,requireSameEnvironment:false}));const core=coreLabels(row.team,result,coreCount,locked);verified.push({team:{...row.team,core:core.map(x=>x.id)},result,core,style:inferStyle(row.team)});});
 return {top:diverseTop(sort(verified),3),candidates:cs.length+mutations.length,arena,environment:arena.environment,note:'实际资源下候选搜索；不是全组合穷举。核心为主要贡献者标注，非必须仅培养这些英雄。'};
}
export function optimizeMechs(team,pool,arena,progress=()=>{},quick=false){
 validateTeam(team);const count=team.mechs.length,active=ids(team),available=pool.filter(x=>!active.includes(x.id));if(available.length<count)throw Error('可用机师不足');
 const map=new Map(pool.map(x=>[x.id,x])),heuristic=chooseMechs(active,pool,count),teams=[clone(team),{...clone(team),mechs:heuristic.map(id=>clone(map.get(id)))}];
 const random=rng(338211);for(let i=0;i<20;i++){const t=clone(teams[i%2]),rest=available.filter(x=>!t.mechs.some(y=>y.id===x.id));if(rest.length)t.mechs[i%count]=clone(rest[Math.floor(random()*rest.length)]);teams.push(t);}
 let rows=unique(teams.map(t=>({team:t}))).map((row,i)=>{progress({stage:'比较机师组合',current:i+1,total:teams.length});return {...row,result:summary(evaluateArena(row.team,arena,{battles:120,seed:`mech-screen/${i}`,requireSameEnvironment:false}))};});
 rows=sort(rows).slice(0,3).map((row,i)=>({...row,result:summary(evaluateArena(row.team,arena,{battles:quick?240:4000,seed:`mech-validation/${i}`,requireSameEnvironment:false}))}));return {...sort(rows)[0],note:'已比较候选中的最佳机师，未穷举所有机师组合。'};
}
function replaceUnit(team,hero,pool,slot){const t=clone(team);const old=t.active[slot].id;t.active[slot]=clone(hero);t.core=(t.core||[]).map(id=>id===old?hero.id:id);
 if(t.mechs.some(x=>x.id===hero.id)){const map=new Map(pool.map(x=>[x.id,x]));t.mechs=chooseMechs(ids(t),pool,t.mechs.length).map(id=>clone(map.get(id)));}validateTeam(t);return t;}
export function upgradeV2(context,progress=()=>{}){
 const {team,pool,locked=[]}=context;validateTeam(team);const arena=personalArena({...context,team}),seed='upgrade-fixed-comparison';
 const base=summary(evaluateArena(team,arena,{battles:context.quick?240:4000,seed,requireSameEnvironment:false})),possibilities=[];
 const targets=pool.filter(x=>H[x.id].rarity==='legendary'&&x.star<20);
 for(let i=0;i<targets.length;i++){
  const hero=targets[i],stars=[...new Set([hero.star+1,...[2,10,20].filter(s=>s>hero.star).slice(0,1)])];
  for(const to of stars){const nextPool=pool.map(x=>x.id===hero.id?{...x,star:to}:x);let proposed=[];
   if([...team.active,...team.mechs].some(x=>x.id===hero.id)){const t=clone(team);[...t.active,...t.mechs].forEach(x=>{if(x.id===hero.id)x.star=to;});proposed=[t];}
   if(!team.active.some(x=>x.id===hero.id))proposed.push(...team.active.map((x,slot)=>locked.includes(x.id)?null:replaceUnit(team,{id:hero.id,star:to},nextPool,slot)).filter(Boolean));
   const screening=sort(proposed.map(t=>({team:t,result:summary(evaluateArena(t,arena,{battles:120,seed:'upgrade-screen',requireSameEnvironment:false}))})));
   if(screening.length)possibilities.push({...screening[0],id:hero.id,from:hero.star,to,steps:to-hero.star,swapIn:team.active.some(x=>x.id===hero.id)?null:hero.id,swapOut:team.active.find(x=>!screening[0].team.active.some(y=>y.id===x.id))?.id||null});
  }progress({stage:'筛选升星及候补换入机会',current:i+1,total:targets.length});
 }
 const rows=sort(possibilities).slice(0,context.quick?3:12).map((r,i)=>{progress({stage:'复核升星收益',current:i+1,total:Math.min(12,possibilities.length)});const result=summary(evaluateArena(r.team,arena,{battles:context.quick?240:4000,seed,requireSameEnvironment:false}));return {...r,result,delta:result.score-base.score,gainPerStar:(result.score-base.score)/r.steps,deltaInterval:[result.scoreInterval[0]-base.scoreInterval[1],result.scoreInterval[1]-base.scoreInterval[0]]};}).sort((a,b)=>b.gainPerStar-a.gainPerStar);
 return {base,rows,arena,note:'先筛选、再复核最有希望的12项；按每个星级步数的得分增益排序，未折算魂魄或人民币成本。候补换入包含换人与升星的合并效果。'};
}
export function developmentV2(context,progress=()=>{}){
 const {team,pool,locked=[],demand='investment'}=context;validateTeam(team);const arena=personalArena({...context,team});
 const groups={investment:['低投入 · 保留主力','中投入 · 模块替换','高投入 · 核心重建'],function:['爆发速攻','控制压制','反击续航'],core:['保留核心','替换部分','核心重建']},names=groups[demand]||groups.investment;
 const source=candidates(pool,context.count,[],72,552133),local=[clone(team)],paths=[],used=[];const weakest=team.active.map((x,i)=>({x,i})).filter(({x})=>!locked.includes(x.id)).sort((a,b)=>a.x.star-b.x.star);for(const hero of pool.filter(x=>H[x.id].rarity==='legendary'&&!ids(team).includes(x.id)))if(weakest.length)local.push(replaceUnit(team,hero,pool,weakest[0].i));
 const core=locked.length?locked:(team.core?.length?team.core:coreLabels(team,null,2).map(x=>x.id));
 const base=summary(evaluateArena(team,arena,{battles:context.quick?240:4000,seed:'path-baseline',requireSameEnvironment:false}));
 for(let route=0;route<3;route++){
  let routeSource=demand==='core'&&route<2?candidates(pool,context.count,route===0?core:core.slice(0,1),72,552133+route):source;
  if(route===0)routeSource=[...local,...routeSource];let options=routeSource.filter(t=>!used.some(u=>ids(u).filter(id=>ids(t).includes(id)).length>=8));
  if(demand==='core'&&route===0)options=options.filter(t=>core.every(id=>ids(t).includes(id)));
  else if(demand==='core'&&route===1)options=options.filter(t=>core.some(id=>ids(t).includes(id))&&!core.every(id=>ids(t).includes(id)));
  else if(demand==='core'&&route===2)options=options.filter(t=>core.every(id=>!ids(t).includes(id)));
  if(demand==='investment'&&route===0)options=options.filter(t=>ids(t).filter(id=>ids(team).includes(id)).length>=8).sort((a,b)=>ids(b).filter(id=>ids(team).includes(id)).length-ids(a).filter(id=>ids(team).includes(id)).length).slice(0,32);
  if(demand==='investment'&&route===1)options=options.filter(t=>{const n=ids(t).filter(id=>ids(team).includes(id)).length;return n>=5&&n<=7;});if(demand==='investment'&&route===2)options=options.filter(t=>ids(t).filter(id=>ids(team).includes(id)).length<=5);
  if(demand==='function'){const wanted=['爆发进攻','控制压制','反击续航'][route];options=options.filter(t=>inferStyle(t)===wanted);}
  if(!options.length){paths.push({name:names[route],unavailable:'当前英雄池缺少满足此路线约束的不同阵容，扩充英雄池后可重新规划。'});continue;}
  const plans=options.slice(0,32).map(t=>{
   const selected=coreLabels(t,null,context.coreCount||2,demand==='core'&&route===0?core:[]).map(x=>x.id),final=clone(t);
   for(const x of final.active){const floor=demand==='investment'?route===0?(selected.includes(x.id)?20:2):route===1?(selected.includes(x.id)?20:10):20:selected.includes(x.id)?20:10;x.star=Math.max(x.star,floor);}
   final.core=selected;const mid=clone(final);for(const x of mid.active){const own=pool.find(p=>p.id===x.id).star;x.star=Math.max(own,selected.includes(x.id)?Math.min(10,x.star):Math.min(2,x.star));}
   return {team:final,mid,steps:final.active.reduce((n,x)=>n+x.star-pool.find(p=>p.id===x.id).star,0)};
  });
  const futureEnv=arenaEnvironment({stage:'actual',actualTeam:plans[0].team,mechCount:context.count,coreCount:context.coreCount||2}),routeArena=createOpponentPool(futureEnv,{systems:context.systems||[],size:30,seed:sampleSeed('path-future-v3',route,futureEnv.key)});
  const screened=sort(plans.map((r,i)=>({...r,result:summary(evaluateArena(r.team,routeArena,{battles:120,seed:`path-screen/${route}/${i}`,requireSameEnvironment:false}))}))).slice(0,3);
  const verified=sort(screened.map((r,i)=>({...r,result:summary(evaluateArena(r.team,routeArena,{battles:context.quick?1000:4000,seed:`path-validation/${route}/${i}`,requireSameEnvironment:false}))})));const best=verified[0];
  const midArena=personalArena({...context,stage:'actual',opponentStage:null,team:best.mid,reference:null}),midResult=summary(evaluateArena(best.mid,midArena,{battles:context.quick?1000:4000,seed:`path-mid/${route}`,requireSameEnvironment:false}));
  const priority=best.team.active.filter(x=>x.star>pool.find(p=>p.id===x.id).star).sort((a,b)=>Number(best.team.core.includes(b.id))-Number(best.team.core.includes(a.id)));
  paths.push({name:names[route],mid:{team:best.mid,result:midResult,arena:midArena},final:{...best,arena:routeArena},steps:priority.map(x=>({id:x.id,from:pool.find(p=>p.id===x.id).star,to:x.star})),delta:best.result.score-base.score});used.push(best.team);progress({stage:'比较不同发展路线',current:route+1,total:3});
 }
 return {base,paths,arena,note:'三条路线使用同一当前对手池衡量发展收益；投入按升星步数与换人数区分，不虚构购买成本。英雄池无法支撑差异路线时明确显示原因。'};
}
export function compareV2(context){const arena=personalArena(context),n=context.quick?240:4000;validateTeam(context.team,context.count);validateTeam(context.changed,context.count);return {before:summary(evaluateArena(context.team,arena,{battles:n,seed:'compare-fixed',requireSameEnvironment:false})),after:summary(evaluateArena(context.changed,arena,{battles:n,seed:'compare-fixed',requireSameEnvironment:false})),duel:evaluate(context.team,[context.changed],n,'direct-duel'),arena};}
export function inspectCurrent(context,progress=()=>{}){
 const {team,analysisData}=context,arena=personalArena(context),n=context.quick?120:1000;
 const result=summary(evaluateArena(team,arena,{battles:context.quick?240:4000,seed:'current-performance',requireSameEnvironment:false}));
 const base=summary(evaluateArena(team,arena,{battles:n,seed:'current-attributes',requireSameEnvironment:false}));
 const radius=r=>2*Math.sqrt(.5*Math.log(40)*r.boundScale)*100;
 const attributes=analysisData.attributesDefinition.map((a,i)=>{progress({stage:'计算当前阵容属性价值',current:i+1,total:analysisData.attributesDefinition.length});const on=summary(evaluateArena(team,arena,{battles:n,seed:'current-attributes',options:{boost:[{[a.id]:a.value},{}]},requireSameEnvironment:false}));const delta=on.score-base.score;return {id:a.id,delta,deltaInterval:[delta-radius(on),delta+radius(on)],on,off:base};}).sort((a,b)=>b.delta-a.delta);
 const matrixTeams=analysisData.matrix.teams.map(row=>({...row,team:projectTeam(row.team,arena.environment)}));
 const matrix=matrixTeams.map((row,i)=>{progress({stage:'计算当前阵容克制关系',current:i+1,total:6});return evaluate(team,[row.team],n,`current-matrix/${i}`);});
 const cells=[];for(let a=0;a<6;a++)for(let b=a;b<6;b++)cells.push({pair:[a,b],...evaluate(matrixTeams[a].team,[matrixTeams[b].team],n,`current-context-matrix/${a}/${b}`)});
 const evolutions=team.active.filter(x=>x.star>=2).map((h,i)=>{const before=h.star>=20?10:h.star>=10?2:0;const on=summary(evaluateArena(team,arena,{battles:n,seed:`current-evolution/${i}`,requireSameEnvironment:false})),off=summary(evaluateArena(team,arena,{battles:n,seed:`current-evolution/${i}`,options:{evolutionStars:[{[h.id]:before},{}]},requireSameEnvironment:false}));const delta=on.score-off.score;return {id:h.id,delta,deltaInterval:[delta-radius(on),delta+radius(on)],on,off};}).sort((a,b)=>b.delta-a.delta);
 return {team,result,attributes,matrix,matrixData:{teams:matrixTeams,cells},evolutions,arena};
}
