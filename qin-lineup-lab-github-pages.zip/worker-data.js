import {manifest,readPackage} from './web-loader.js?v=v3.4.1-20261110110654';
const prepared=new Map();
export async function prepareWorkerData(env,{lineups=false,arena=false}={}){
 const m=await manifest(),parts=m.environments[env.key]?.parts;if(!parts?.workerMeta)throw Error('计算资料包版本不完整，请重新加载');
 const revision=m.sourceDataRevision+'|'+m.workerRevision,key=env.key+'|'+revision;
 if(!prepared.has(key))prepared.set(key,(async()=>{const [index,data]=await Promise.all([fetch('./bench/index.json?v=v3.4.1-20261110110654',{cache:'no-cache'}).then(r=>{if(!r.ok)throw Error('计算版本资料加载失败');return r.json()}),readPackage(parts.workerMeta)]);if(index.dataRevision&&m.sourceDataRevision!==index.dataRevision)throw Error('计算资料版本不一致，请重新加载');return {key:env.key,index,data:{...data,lineups:[]},parts,revision}})().catch(e=>{prepared.delete(key);throw e}));
 const p=await prepared.get(key),requests=[];
 if(lineups&&!p.lineupIndex)requests.push((p.lineupsPromise??=readPackage(parts.workerLineups).then(v=>{p.lineupIndex=v;p.data.lineups=v.lineups}).catch(error=>{delete p.lineupsPromise;throw error})));if(arena&&!p.arena)requests.push((p.arenaPromise??=readPackage(parts.workerArena).then(v=>p.arena=v).catch(error=>{delete p.arenaPromise;throw error})));await Promise.all(requests);return p;
}
export async function fullWorkerRow(p,row){if(!row?.__workerDetail)return row;const i=p.lineupIndex,index=i.rows[row.id];return (await readPackage(i.shards[index]))[row.id]}
export async function workerUpgrades(p,key){const i=await (p.upgradeIndex??=readPackage(p.parts.workerUpgradesIndex).catch(error=>{delete p.upgradeIndex;throw error})),ref=i.shards[i.rows[key]];return ref?(await readPackage(ref))[key]:null}
