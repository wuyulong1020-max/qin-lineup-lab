
import {H,battle} from './engine.js?v=v4.0.5-20261128164603';
import {environment,teamFrom} from './fixed-arena.js?v=v4.0.5-20261128164603';
import {matchingBeasts} from './combat-systems.js?v=v4.0.5-20261128164603';
import {empiricalLayout} from './formation-layout.js?v=v4.0.5-20261128164603';

const integer=(x,lo,hi)=>Number.isInteger(x)&&x>=lo&&x<=hi;
const stageOf=(a,b)=>{
 const stars=[...a.active,...b.active].map(s=>s.star).sort((x,y)=>x-y);
 const median=(stars[8]+stars[9])/2;
 return median>=20?20:median>=10?10:2;
};
function validate(input){
 if(!input?.active||input.active.length!==9)throw Error('双方各需填写九名弟子。');
 const ids=input.active.map(u=>u.id);
 if(ids.some(id=>H[id]?.rarity!=='legendary')||new Set(ids).size!==9)throw Error('每方请选择九名不同的橙色弟子。');
 for(const x of input.active){
  if(!integer(x.level,1,300)||!integer(x.star,0,30)||!integer(x.awakening??0,0,10))throw Error('等级填1–300，星级填0–30，觉醒填0–10。');
  if(x.star<20&&x.awakening)throw Error('未到20星的弟子请将觉醒填0。');
 }
 if(input.beast&&!matchingBeasts(ids).includes(input.beast))throw Error('机关兽需和本队至少一名上阵弟子的五行相同。');
 if(input.guardian&&!ids.includes(input.guardian))throw Error('守护弟子需在本队上阵。');
}
function team(input,ref){
 const t=teamFrom(input.active.map(s=>s.id),environment(ref,6));
 return {...t,beast:input.beast||undefined,guardian:input.guardian||undefined,
  active:input.active.map(x=>({...x,awakening:x.awakening??0}))};
}
function normalize(a,b,category){
 const all=[...a.active,...b.active];
 const level=Math.round(all.reduce((s,v)=>s+v.level,0)/18);
 const star=Math.round(all.reduce((s,v)=>s+v.star,0)/18);
 return [a,b].map(t=>{
  if(category==='机关兽')return {...t,beast:null,guardian:null};
  if(category==='站位'){
   const ids=empiricalLayout(t.active.map(u=>u.id));
   return {...t,active:ids.map(id=>t.active.find(u=>u.id===id))};
  }
  const active=t.active.map(x=>category==='等级'?{...x,level}:
   category==='星级'?{...x,star:x.awakening?Math.max(20,star):star}:{...x,awakening:0});
  return {...t,active};
 });
}
const rate=(left,right,reference,pairs)=>{
 const a=team(left,reference),b=team(right,reference);
 const options={calibrationStage:reference};
 let points=0;
 for(let i=0;i<pairs;i++){
  const seed=75343+i*1627;
  const l=battle(a,b,seed,options),r=battle(b,a,seed,options);
  if(l.capped||r.capped)throw Error('本次模拟触发事件上限，请调整阵容后重试。');
  points+=(l.winner===-1?.5:Number(l.winner===0))+(r.winner===-1?.5:Number(r.winner===1));
 }
 return 100*points/(pairs*2);
};
export function runCup(left,right,progress=()=>{},pairs=320){
 validate(left);validate(right);
 const reference=stageOf(left,right);
 progress(0,2,'正在模拟双方对战');
 const baseline=rate(left,right,reference,pairs);
 const probeCount=Math.min(pairs,128),probe=rate(left,right,reference,probeCount);
 const checks=[];
 for(const category of ['等级','星级','觉醒','站位','机关兽']){
  const [a,b]=normalize(left,right,category);
  if(JSON.stringify([a,b])===JSON.stringify([left,right]))continue;
  checks.push({category,shift:probe-rate(a,b,reference,probeCount)});
 }
 const dominant=checks.sort((a,b)=>Math.abs(b.shift)-Math.abs(a.shift))[0];
 const note=dominant&&Math.abs(dominant.shift)>=5?dominant.category+'差异对这场模拟的影响最大。':'单项差异接近，胜负更多取决于双方的综合搭配。';
 progress(2,2,'模拟完成');
 return {left:baseline,right:100-baseline,note};
}

