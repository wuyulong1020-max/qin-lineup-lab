export const RESOURCE_MODEL='core-template-20261106';
export const CORE_PACKAGE=Object.freeze({atk:.35,def:.20,hp:.35,inner:.50,crit:.18,critDamage:.12,pierce:.12,speed:40});
export function resourceWeights(subject){
 if(subject.kind==='hero')return [1];
 if(subject.id==='c02')return subject.activeMembers.map(id=>id==='h02'?1:.7);
 if(subject.id==='c09')return subject.activeMembers.map(id=>id==='h15'?1:.7);
 if(subject.id==='c15')return [1.7];
 // Snow Girl is a mechanist, not a cultivated active slot.
 return subject.activeMembers.map(()=>1);
}
export function resourceOptions(team,positions,weights,mode='accessory'){
 if(mode!=='core')return {};
 if(positions.length!==weights.length)throw Error('Resource slot mismatch');
 return {unitBoost:[Object.fromEntries(positions.map((pos,i)=>[team.active[pos].id,Object.fromEntries(Object.entries(CORE_PACKAGE).map(([k,v])=>[k,v*weights[i]]))])),{}]};
}
