export const RESOURCE_MODEL='core-template-20261117';
export const CORE_PACKAGE=Object.freeze({atk:.35,def:.20,hp:.35,inner:.50,crit:.18,critDamage:.12,pierce:.12,speed:40});
export const LATE_CORE_PACKAGE=Object.freeze({...CORE_PACKAGE,atk:.45,def:.25,hp:.40,inner:.75,pierce:.15});
export function resourceWeights(subject){
 if(subject.kind==='hero')return [1];
 if(subject.id==='c02')return subject.activeMembers.map(id=>id==='h02'?1:.7);
 if(subject.id==='c09')return subject.activeMembers.map(id=>id==='h15'?1:.7);
 if(subject.id==='c15')return [1.7];
 // Snow Girl is a mechanist, not a cultivated active slot.
 return subject.activeMembers.map(()=>1);
}
export function resourceOptions(team,positions,weights,mode='accessory'){
 if(mode!=='core')return {};
 if(positions.length!==weights.length)throw Error('Resource slot mismatch');
 return {unitBoost:[Object.fromEntries(positions.map((pos,i)=>{
  const unit=team.active[pos];
  const items=team.active.filter(x=>x.star>=20).length>=5?LATE_CORE_PACKAGE:CORE_PACKAGE;
  return [unit.id,Object.fromEntries(Object.entries(items).map(([k,v])=>[k,v*weights[i]]))];
 })),{}]};
}
