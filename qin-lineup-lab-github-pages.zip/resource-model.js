import {H} from './engine.js?v=v3.4.3-20261118220217';
export const RESOURCE_MODEL='core-template-20261118';
export const CORE_PACKAGE=Object.freeze({atk:.35,def:.20,hp:.35,inner:.50,crit:.18,critDamage:.12,pierce:.12,speed:40});
export const LATE_CORE_PACKAGE=Object.freeze({atk:.45,def:.20,hp:.30,inner:.50,crit:.18,critDamage:.12,pierce:.15,speed:0});
const DEFENSE={atk:.25,def:.45,hp:.60,inner:.40,antiCrit:.15,critReduce:.08,skillReduce:.10,speed:0};
const SUPPORT={atk:.40,def:.25,hp:.45,inner:.30,antiCrit:.10,skillReduce:.08,speed:0};
const exponent=Math.log(1.7)/Math.log(2);
export const budgetEffect=budget=>Math.pow(budget,exponent);
export function corePackage(id,star=20){
 const h=H[id];
 let p={...(h.role==='attack'?LATE_CORE_PACKAGE:h.role==='defense'?DEFENSE:SUPPORT)};
 if(['h07','h35'].includes(id)||id==='h02'&&star>=20){
  p={...p,atk:.30,crit:.08,inner:1.20,speed:20};
 }
 if(id==='h26')p={...p,atk:.15,def:.30,hp:.45,inner:1.20};
 if(id==='h06')p={...p,def:.35,hp:.75};
 if(['h15','h16','h28'].includes(id))p={...p,def:.55,hp:.45};
 if(['h03','h04','h11','h14','h17','h19','h23','h30'].includes(id)){
  p.atk=Math.max(0,p.atk-.10);p.speed=40;
 }
 if(id==='h31')p={...p,atk:.35,def:.40,speed:20};
 if(['h10','h12','h24'].includes(id))p={...p,atk:.35,speed:20};
 if(['h22','h34'].includes(id))p={...p,atk:.25,hp:.65};
 if(id==='h36')p={...p,atk:.25,hp:.60};
 if(star<20){for(const k of Object.keys(p))if(k!=='speed')p[k]*=.75;}
 return p;
}
export function resourceWeights(subject){
 if(subject.kind==='hero')return [1];
 if(subject.activeMembers.length===1)return [2];
 if(subject.activeMembers.length===2)return [1,1];
 const main=subject.id==='c02'?'h02':subject.id==='c09'?'h15':subject.activeMembers[0];
 return subject.activeMembers.map(id=>id===main?1:1/(subject.activeMembers.length-1));
}
export function resourceOptions(team,positions,weights,mode='accessory'){
 if(mode!=='core')return {};
 if(positions.length!==weights.length)throw Error('Resource slot mismatch');
 return {unitBoost:[Object.fromEntries(positions.map((pos,i)=>{
  const unit=team.active[pos],items=corePackage(unit.id,unit.star);
  return [unit.id,Object.fromEntries(Object.entries(items).map(([k,v])=>[k,v*budgetEffect(weights[i])]))];
 })),{}]};
}
