import {H} from './engine.js?v=v3.4.6-20261121010843';
import {defaultPill,orangeGear,orangePill} from './late-calibration.js?v=v3.4.6-20261121010843';
import {selectedBooks} from './equipment-directions.js?v=v3.4.6-20261121010843';
export const RESOURCE_MODEL='full-team-equipment-v3.4.6';
const redGear={atk:59696,def:45670,hp:358176,inner:55004};
const redPill={atk:27998,def:20073,hp:168509};
const beastTransfer={atk:12000,def:8500,hp:75000};
const specials=new Set(['h07','h08','h17','h19','h20','h26','h32','h34','h35']);
export const heroPaths=Object.freeze({
  "h01": {
    "pill": "atk",
    "fast": true,
    "second": "def",
    "book": "guan",
    "outfit": "def-hp"
  },
  "h02": {
    "pill": "atk",
    "fast": true,
    "second": "atk",
    "book": "guan",
    "outfit": "atk-hp"
  },
  "h03": {
    "pill": "atk",
    "fast": true,
    "second": "crit",
    "book": "guan",
    "outfit": "hp-atk"
  },
  "h04": {
    "pill": "atk",
    "fast": true,
    "second": "block",
    "book": "luo",
    "outfit": "atk-def"
  },
  "h05": {
    "pill": "atk",
    "fast": false,
    "second": "crit",
    "book": "guan",
    "outfit": "atk-hp",
    "first": "atk"
  },
  "h06": {
    "pill": "atk",
    "fast": true,
    "second": "crit",
    "book": "guan",
    "outfit": "atk-hp"
  },
  "h07": {
    "pill": "atk",
    "fast": true,
    "second": "atk",
    "book": "guan",
    "outfit": "atk-hp"
  },
  "h08": {
    "pill": "atk",
    "fast": true,
    "second": "atk",
    "book": "guan",
    "outfit": "atk-hp"
  },
  "h09": {
    "pill": "atk",
    "fast": true,
    "second": "atk",
    "book": "guan",
    "outfit": "atk-hp"
  },
  "h10": {
    "pill": "atk",
    "fast": true,
    "second": "block",
    "book": "guan",
    "outfit": "atk-def"
  },
  "h11": {
    "pill": "atk",
    "fast": true,
    "second": "atk",
    "book": "guan",
    "outfit": "atk-hp"
  },
  "h12": {
    "pill": "def",
    "fast": true,
    "second": "block",
    "book": "guan",
    "outfit": "atk-def"
  },
  "h13": {
    "pill": "atk",
    "fast": true,
    "second": "atk",
    "book": "guan",
    "outfit": "atk-hp"
  },
  "h14": {
    "pill": "atk",
    "fast": true,
    "second": "block",
    "book": "guan",
    "outfit": "atk-def"
  },
  "h15": {
    "pill": "def",
    "fast": true,
    "second": "def",
    "book": "guan",
    "outfit": "def-hp"
  },
  "h16": {
    "pill": "atk",
    "fast": true,
    "second": "def",
    "book": "luo",
    "outfit": "atk-hp"
  },
  "h17": {
    "pill": "hp",
    "fast": true,
    "second": "hp",
    "book": "guan",
    "outfit": "hp-atk"
  },
  "h18": {
    "pill": "atk",
    "fast": false,
    "second": "atk",
    "book": "guan",
    "outfit": "atk-def"
  },
  "h19": {
    "pill": "atk",
    "fast": true,
    "second": "atk",
    "book": "guan",
    "outfit": "atk-hp"
  },
  "h20": {
    "pill": "def",
    "fast": true,
    "second": "atk",
    "book": "guan",
    "outfit": "hp-atk"
  },
  "h21": {
    "pill": "def",
    "fast": true,
    "second": "def",
    "book": "guan",
    "outfit": "def-hp"
  },
  "h22": {
    "pill": "hp",
    "fast": false,
    "second": "block",
    "book": "guan",
    "outfit": "hp-atk"
  },
  "h23": {
    "pill": "atk",
    "fast": true,
    "second": "block",
    "book": "luo",
    "outfit": "atk-def"
  },
  "h24": {
    "pill": "atk",
    "fast": true,
    "second": "atk",
    "book": "guan",
    "outfit": "def-hp"
  },
  "h25": {
    "pill": "atk",
    "fast": true,
    "second": "atk",
    "book": "guan",
    "outfit": "atk-hp"
  },
  "h26": {
    "pill": "def",
    "fast": true,
    "second": "def",
    "book": "guan",
    "outfit": "def-hp"
  },
  "h27": {
    "pill": "atk",
    "fast": true,
    "second": "crit",
    "book": "guan",
    "outfit": "atk-def"
  },
  "h28": {
    "pill": "def",
    "fast": true,
    "second": "def",
    "book": "guan",
    "outfit": "def-hp"
  },
  "h29": {
    "pill": "def",
    "fast": true,
    "second": "block",
    "book": "guan",
    "outfit": "atk-hp"
  },
  "h30": {
    "pill": "atk",
    "fast": true,
    "second": "atk",
    "book": "guan",
    "outfit": "atk-hp"
  },
  "h31": {
    "pill": "atk",
    "fast": true,
    "second": "atk",
    "book": "guan",
    "outfit": "atk-hp"
  },
  "h32": {
    "pill": "atk",
    "fast": true,
    "second": "crit",
    "book": "guan",
    "outfit": "atk-hp"
  },
  "h33": {
    "pill": "atk",
    "fast": true,
    "second": "crit",
    "book": "luo",
    "outfit": "def-hp"
  },
  "h34": {
    "pill": "def",
    "fast": true,
    "second": "dodge",
    "book": "guan",
    "outfit": "atk-def"
  },
  "h35": {
    "pill": "atk",
    "fast": true,
    "second": "block",
    "book": "guan",
    "outfit": "atk-def"
  },
  "h36": {
    "pill": "atk",
    "fast": true,
    "second": "atk",
    "book": "guan",
    "outfit": "hp-atk"
  },
  "h37": {
    "pill": "atk",
    "fast": true,
    "second": "atk",
    "book": "luo",
    "outfit": "atk-hp"
  },
  "h38": {
    "pill": "atk",
    "fast": true,
    "second": "crit",
    "book": "guan",
    "outfit": "atk-hp"
  }
});
const primary=['atk','def','hp'];
const amounts={atk:.10,def:.10,hp:.10,pierce:.06,crit:.06,antiCrit:.06,critDamage:.10,block:.06,dodge:.06};
export const directionName=p=>[p.pill,p.fast?'speed80':'slow',p.second,p.book,p.outfit].join('/');
export function defaultDirection(role){
 const stat=defaultPill[role];
 return {pill:stat,fast:true,second:stat,book:role==='attack'?'yin':'guan',outfit:role==='attack'?'atk-hp':role==='defense'?'def-hp':'hp-atk'};
}
export const budgetEffect=budget=>Math.pow(budget,Math.log(1.7)/Math.log(2));
export function resourceWeights(subject){
 return subject.kind==='hero'?[1]:subject.activeMembers.map(()=>1);
}
// Continuous equipment progression caps at the full observed specimen. Secondary
// slots, unlocks, costumes and guardian talents are complete for every core.
export function equipmentBoost(id,p,star,pos,awake=false,budget=1){
 const role=H[id].role,early=star<20,stage=early?.5:1;
 const weight=Math.min(1,stage*budgetEffect(budget));
 const add=(out,k,x)=>{out[k]=(out[k]||0)+x;};
 const out={};
 for(const k of primary){
  const n=1+Number(p.pill===k),ordinaryN=1+Number(defaultPill[role]===k);
  const mainDelta=redGear[k]-orangeGear[k]+n*redPill[k]-ordinaryN*orangePill[k];
  out[k+'EquipmentFlat']=weight*mainDelta/12;
  out[k+'Flat']=out[k+'EquipmentFlat']+beastTransfer[k]/12;
  out[k]=weight*.72+n*.35;
 }
 out.innerFlat=(redGear.inner-orangeGear.inner)*weight/12;
 out.inner=.72*weight+.30+(1+Number(p.pill==='hp'))*.30;
 out.antiCrit=(1+Number(p.pill==='def'))*.20;
 out.pierce=(1+Number(p.pill==='atk'))*.20;
 out.speed=12+(specials.has(id)?20:0);
 // Book innate traits are included on ordinary gear; only the difference is added.
 const book=role==='attack'?'yin':p.book==='luo'?'luo':'guan';
 if(book==='luo'){out.speed+=48;out.block=-.20;}
 if(book==='luo'){out.atk+=.18;out.def+=.18;out.heal=.10;out.pierce+=.10;}
 if(book==='guan'){out.def+=.18;out.hp+=.18;}
 if(book==='yin'){out.atk+=.25;}
 out.skillReduce=.30;
 if(book!=='luo'){out.critDamage=.10;out.antiCrit+=.10;}
 const first=p.fast?'speed':(p.first||(p.second==='hp'?'def':'hp'));
 if(p.fast)out.speed+=80;else add(out,first,4*amounts[first]);
 add(out,p.second,4*amounts[p.second]);
 const outfits=p.outfit.split('-'),single=outfits.includes(defaultPill[role])?defaultPill[role]:outfits[0];
 for(const stat of early?[single]:outfits)add(out,stat,stat==='hp'?.15:.12);
 if(awake){out.pvpReduce=.05;out.ignoreDef=.05;}
 return out;
}
export function corePackage(id,star=20,pos=H[id].role==='defense'?0:4,awake=false,budget=1){
 const code=id+':'+star+':'+Number(awake)+':'+budget;
 if(!coreCache.has(code))coreCache.set(code,Object.freeze(equipmentBoost(id,buildFor(id),star,pos,awake,budget)));
 return coreCache.get(code);
}
const coreCache=new Map();
export function buildFor(id){
 const role=H[id].role,p=heroPaths[id]||defaultDirection(role);
 return {...p,book:role==='attack'?'yin':selectedBooks[id]||(p.book==='luo'?'luo':'guan')};
}
export function resourceOptions(team,positions,weights,mode='accessory'){
 if(positions.length!==weights.length)throw Error('Resource slot mismatch');
 return mode==='accessory'?{accessoryIds:[positions.map(pos=>team.active[pos].id),[]]}:{};
}
