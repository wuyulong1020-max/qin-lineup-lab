import {configure} from './engine.js?v=v3.0.5-20261024103106';import {evaluateFixed} from './fixed-arena.js?v=v3.0.5-20261024103106';
let arena=null;
onmessage=e=>{const m=e.data;try{if(m.init){configure(m.db);arena=m.arena;postMessage({id:m.id,ready:true});return}const result=evaluateFixed(m.team,arena,{battles:m.n,seed:m.seed,options:m.options||{},details:false});postMessage({id:m.id,result})}catch(err){postMessage({id:m.id,error:err.message})}};
