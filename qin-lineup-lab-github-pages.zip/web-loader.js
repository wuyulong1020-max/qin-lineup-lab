let manifestPromise;const fetched=new Map();
export async function json(url,{cache='no-cache'}={}){const response=await fetch(url,{cache});if(!response.ok)throw Error('资料加载失败，请重试（'+response.status+'）');return response.json()}
export function manifest({refresh=false,cache='no-cache'}={}){if(refresh)manifestPromise=null;return manifestPromise??=json('./web-data/manifest.json?v=v3.3.0-20261109094509',{cache}).catch(error=>{manifestPromise=null;throw error})}
export async function bootstrapMetadata(){
 const requireRevision=new URL(import.meta.url).searchParams.has('v');
 for(let attempt=0;attempt<2;attempt++){
  const cache=attempt?'reload':'no-cache',[index,packages]=await Promise.all([json('./bench/index.json?v=v3.3.0-20261109094509',{cache}),manifest({refresh:attempt>0,cache})]);
  const bothRevisions=typeof index.dataRevision==='string'&&index.dataRevision.length>0&&typeof packages.sourceDataRevision==='string'&&packages.sourceDataRevision.length>0;
  if(bothRevisions?index.dataRevision===packages.sourceDataRevision:!requireRevision)return [index,packages];
 }
 throw Error('榜单与资料包版本不一致，请重新加载');
}
export function readPackage(ref){if(!fetched.has(ref.url))fetched.set(ref.url,(async()=>{const response=await fetch(ref.url);if(!response.ok)throw Error('资料包加载失败，请重试（'+response.status+'）');const bytes=await response.arrayBuffer(),digest=await crypto.subtle.digest('SHA-256',bytes),hash=Array.from(new Uint8Array(digest)).map(x=>x.toString(16).padStart(2,'0')).join('');if(ref.hash&&!hash.startsWith(ref.hash))throw Error('资料包版本不一致，请重试');return JSON.parse(new TextDecoder().decode(bytes))})().catch(error=>{fetched.delete(ref.url);throw error}));return fetched.get(ref.url)}
export function mergeData(target,next){for(const [key,value] of Object.entries(next)){if(key==='comboSkillModes'){target[key]={...target[key],...value}}else if(['cuts','rankModes'].includes(key)&&value){target[key]??={};for(const [name,row] of Object.entries(value)){if(key==='rankModes'){target[key][name]={...target[key][name],...row,cuts:{...target[key][name]?.cuts,...row.cuts}};if(name==='accessory')for(const kind of ['heroes','combos'])if(row[kind])target[kind]=row[kind]}else target[key][name]=row}}else target[key]=value}return target}
export async function loadParts(key,parts,target={},progress=()=>{}){const m=await manifest(),environment=m.environments[key];if(!environment)throw Error('当前环境暂未生成');let done=0;progress({phase:'加载当前页面资料',done,total:parts.length});for(const part of parts){const ref=environment.parts[part];if(!ref)throw Error('缺少'+part+'资料包');mergeData(target,await readPackage(ref));progress({phase:'加载当前页面资料',done:++done,total:parts.length})}return target}
export async function loadDetail(key,id){const m=await manifest(),indexRef=m.environments[key]?.parts.detailIndex;if(!indexRef)throw Error('这套阵容详情暂未就绪');const index=await readPackage(indexRef),ref=index.shards[index.rows[id]];if(!ref)throw Error('这套阵容详情暂未就绪');return (await readPackage(ref))[id]}
