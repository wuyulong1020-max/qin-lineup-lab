import {tierOf,teamKey} from './front-arena.js?v=v3.4.1-20261110110654';
import {metricValue} from './rank-helpers.js?v=v3.4.1-20261110110654';
import {calibratedStyle} from './presentation.js?v=v3.4.1-20261110110654';
import {activeRosterKey} from './team-families.js?v=v3.4.1-20261110110654';
export const LINEUP_METRIC_VERSION='best-measured-configuration-within-tier-20261110-v1';
export const LINEUP_METRICS=Object.freeze(['damage','damageTaken','heal','absorbed','controlInflicted','stability']);
const strongTiers=['T0','T0.5','T1','T1.5','T2'];
const value=(row,metric)=>metric==='stability'?row.result.adaptation.stability:metricValue(row,metric,'lineups');
const inScope=(row,cuts,scope)=>{const tier=tierOf(row.result.score,cuts);return scope==='strong'?strongTiers.includes(tier):tier===scope;};
export function buildLineupMetricOverrides(data){
 const byRoster=data.lineups.map(base=>({base,forms:[base,...(base.formationVariants||[])].map((form,index)=>{const styleBasis=data.styleCalibration?calibratedStyle(form,data.styleCalibration):form.styleBasis;return{index,original:form,row:{...form,style:styleBasis?.name||form.style,styleBasis,formationVariants:[],variants:[],tier:tierOf(form.result.score,data.cuts.team)}};})})),metrics={};
 for(const metric of LINEUP_METRICS){const configs={},selectors={};for(const scope of ['strong',...strongTiers]){const selected={};for(const {base,forms} of byRoster){const eligible=forms.filter(f=>inScope(f.row,data.cuts.team,scope)).sort((a,b)=>{const diff=value(b.row,metric)-value(a.row,metric);return (Math.abs(diff)>1e-9?diff:0)||b.row.result.score-a.row.result.score||(b.row.result.n||0)-(a.row.result.n||0)||a.index-b.index;}),best=eligible[0];if(!best||best.index===0||inScope(base,data.cuts.team,scope)&&value(best.row,metric)<=value(base,metric)+1e-9)continue;let id=best.row.id||base.id+'-configuration-'+best.index;if(configs[id]&&(teamKey(configs[id].team)!==teamKey(best.row.team)||JSON.stringify(configs[id].result)!==JSON.stringify(best.row.result)))id=base.id+'-'+id+'-'+best.index;configs[id]={...best.row,measuredId:best.row.id,sourceFormationIndex:best.index,sourceRosterId:base.id};selected[base.id]=id;}selectors[scope]=selected;}metrics[metric]={configs,selectors};}
 return{version:LINEUP_METRIC_VERSION,metrics};
}
export function applyLineupMetricOverrides(data,rows,{metric='stability',tier='全部'}={}){
 const bundle=data.lineupMetricOverrides,preset=bundle?.version===LINEUP_METRIC_VERSION?bundle.metrics?.[metric]:null;
 if(!preset)throw Error('当前排序的实测配置资料尚未加载，请稍后重试。');
 const scope=tier==='全部'?'strong':tier,selector=preset.selectors[scope];if(!selector)return [];
 return rows.map(base=>{const configurationId=selector[base.id],form=configurationId?preset.configs[configurationId]:null;if(!form)return base;if(activeRosterKey(form.team)!==activeRosterKey(base.team))throw Error('实测配置与上阵九人不一致');return{...base,...form,id:base.id,configurationId,sourceRosterId:base.id,system:base.system,formationVariantCount:base.formationVariantCount??base.formationVariants?.length??0,formationVariants:[],variants:[],__detail:false};}).filter(row=>inScope(row,data.cuts.team,scope));
}
