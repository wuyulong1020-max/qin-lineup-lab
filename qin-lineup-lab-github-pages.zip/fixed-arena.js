import {DB,H,battle,rng,validateTeam} from './engine.js?v=v3.0.1-20261019063103';
import {METRICS,emptyMetrics,sampleSeed} from './statistics.js?v=v3.0.1-20261019063103';
import {recommendMechs} from './mechanists.js?v=v3.0.1-20261019063103';
export const STYLES=['爆发速攻','群攻压血','控制压制','反击制胜','持续消耗','奶盾续航'];
export function environment(star=20,mechCount=4){if(![2,10,20].includes(+star)||![2,3,4].includes(+mechCount))throw Error('请选择2/10/20星和2/3/4机师');return {star:+star,mechCount:+mechCount,key:star+'-m'+mechCount}}
export function teamKey(t){return t.active.map(x=>x.id+':'+x.star).join('.')+'|'+t.mechs.map(x=>x.id+':'+x.star).sort().join('.')}
export function teamFrom(ids,env,{name='自选阵容',pool=null,mechs=null}={}){const p=pool||DB.heroes.map(h=>({id:h.id,star:env.star})),map=new Map(p.map(x=>[x.id,x.star]));const t={name,active:ids.map(id=>({id,star:map.get(id)})),mechs:(mechs||recommendMechs(ids,p,env.mechCount)).map(id=>({id,star:map.get(id)}))};validateTeam(t,env.mechCount);return t}
export function arenaFrom(blueprints,env){return {version:'P1-3.0',environment:env,entries:blueprints.map((b,i)=>({id:b.id||'p'+i,style:b.theme,group:b.band||'reference',weight:1/blueprints.length,team:teamFrom(b.ids,env,{name:b.name,mechs:b.mechs?.[env.mechCount]})}))}}
function orderFor(arena,seed){const groups=new Map();for(let i=0;i<arena.entries.length;i++){const k=arena.entries[i].style;const xs=groups.get(k)||[];xs.push(i);groups.set(k,xs)}const r=rng(sampleSeed('opponent-order',seed,0));const shuffled=[...groups.values()].map(xs=>{xs=xs.slice();for(let i=xs.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[xs[i],xs[j]]=[xs[j],xs[i]]}return xs});const out=[];for(let i=0;out.length<arena.entries.length;i++)for(const xs of shuffled)if(xs[i]!==undefined)out.push(xs[i]);return out}
function reversedOptions(options){return {...options,...Object.fromEntries(['boost','disableFaction','disableCombo','evolutionStars','disableMechanisms'].filter(k=>options[k]).map(k=>[k,options[k].slice().reverse()]))}}
export function evaluateFixed(team,arena,{battles=2400,seed='validation',options={},details=true}={}){
 validateTeam(team,arena.environment.mechCount);if(battles<2||battles%2)throw Error('对战场数必须为正偶数');
 const order=orderFor(arena,seed),buckets=new Map(),opCount=arena.entries.length,reverse=reversedOptions(options);let caps=0;
 for(let p=0;p<battles/2;p++){
  const oi=order[p%opCount],op=arena.entries[oi],iteration=Math.floor(p/opCount),s=sampleSeed(seed,op.id,iteration);
  let row=buckets.get(oi);if(!row){row={id:op.id,style:op.style,weight:op.weight,n:0,pairs:0,sum:0,sum2:0,wins:0,draws:0,rounds:0,metrics:emptyMetrics(),byHero:details?Object.fromEntries(team.active.map(x=>[x.id,emptyMetrics()])):{}};buckets.set(oi,row)}
  let pairValue=0;
  for(let swapped=0;swapped<2;swapped++){
   const result=battle(swapped?op.team:team,swapped?team:op.team,s,swapped?reverse:options),side=swapped?1:0,value=result.winner===side?1:result.winner===-1?.5:0;
   pairValue+=value/2;row.n++;row.wins+=value===1?1:0;row.draws+=value===.5?1:0;row.rounds+=result.rounds;caps+=result.capped?1:0;
   for(const m of result.metrics[side])for(const k of METRICS){row.metrics[k]+=m[k]||0;if(details)row.byHero[m.id][k]+=m[k]||0}
  }
  row.pairs++;row.sum+=pairValue;row.sum2+=pairValue*pairValue;
 }
 const rows=[...buckets.values()],weightSum=rows.reduce((s,r)=>s+r.weight,0),avg=fn=>rows.reduce((s,r)=>s+r.weight/weightSum*fn(r),0);
 const score=100*avg(r=>r.sum/r.pairs),variance=rows.reduce((s,r)=>{const v=r.pairs>1?Math.max(0,(r.sum2-r.sum*r.sum/r.pairs)/(r.pairs-1)):.25;return s+(r.weight/weightSum)**2*v/r.pairs},0),half=1.96*Math.sqrt(variance)*100;
 const metrics=Object.fromEntries(METRICS.map(k=>[k,avg(r=>r.metrics[k]/r.n)]));
 const styles=STYLES.map(style=>{const rs=rows.filter(r=>r.style===style),w=rs.reduce((s,r)=>s+r.weight,0);return {style,score:rs.length?rs.reduce((s,r)=>s+r.weight/w*r.sum/r.pairs,0)*100:null}}).filter(r=>r.score!==null);
 const values=styles.map(s=>s.score),range=[Math.min(...values),Math.max(...values)];
 return {score,rate:score/100,n:battles,pairs:battles/2,wins:rows.reduce((s,r)=>s+r.wins,0),draws:rows.reduce((s,r)=>s+r.draws,0),rounds:avg(r=>r.rounds/r.n),metrics,byHero:details?Object.fromEntries(team.active.map(x=>[x.id,Object.fromEntries(METRICS.map(k=>[k,avg(r=>r.byHero[x.id][k]/r.n)]))])):{},halfWidth:half,scoreInterval:[Math.max(0,score-half),Math.min(100,score+half)],intervalMethod:'approximate 95% stratified swapped-pair standard error; excludes model and candidate-selection uncertainty',caps,opponentCount:rows.length,fullPool:rows.length===opCount,quality:rows.length===opCount&&battles>=2400?'verified':'screen',adaptation:{styles,range,stability:100-(range[1]-range[0])}};
}
export function classifyStyle(team,result){const m=result.metrics,d=Math.max(1,m.damage),incoming=Math.max(1,m.damageTaken+m.protected),r=Math.max(1,result.rounds);const scores=[(m.criticalDamage/d)*2+.12/r,(m.areaDamage/d)*.9,(m.controlInflicted/(9*r))*5,(m.counterDamage/d)*3,(m.dotDamage/d)*3,((m.heal+m.absorbed+m.factionAbsorbed)/incoming)*1.3];const best=scores.indexOf(Math.max(...scores));return {name:STYLES[best],scores:Object.fromEntries(STYLES.map((k,i)=>[k,scores[i]])),basis:'统一对战日志来源归类；保留次标签，非官方流派划分'};}
export function tierCuts(scores){const xs=scores.slice().sort((a,b)=>b-a);return [.05,.2,.4,.65,.85].map(q=>xs[Math.min(xs.length-1,Math.floor(xs.length*q))])}
export function tierOf(score,cuts){return 'T'+cuts.filter(c=>score<c).length}
export function aggregate(rows,weights=[.2,.4,.4]){const avg=fn=>rows.reduce((s,r,i)=>s+weights[i]*fn(r),0),keys=Object.keys(rows[0].metrics);return {score:avg(r=>r.score),n:rows.reduce((s,r)=>s+r.n,0),rounds:avg(r=>r.rounds),metrics:Object.fromEntries(keys.map(k=>[k,avg(r=>r.metrics[k])])),adaptation:{range:[avg(r=>r.adaptation.range[0]),avg(r=>r.adaptation.range[1])],stability:avg(r=>r.adaptation.stability)},halfWidth:avg(r=>r.halfWidth||0),quality:'weighted',fullPool:rows.every(r=>r.fullPool)}}
