const NAME='qin-lab-score-v340';let database;
function open(){if(typeof indexedDB==='undefined')return Promise.resolve(null);return database??=new Promise(resolve=>{const r=indexedDB.open(NAME,1);r.onupgradeneeded=()=>r.result.createObjectStore('scores',{keyPath:'key'});r.onsuccess=()=>resolve(r.result);r.onerror=()=>resolve(null)})}
export async function readScore(key){try{const db=await open();if(!db)return null;return await new Promise(resolve=>{const r=db.transaction('scores').objectStore('scores').get(key);r.onsuccess=()=>resolve(r.result?.result||null);r.onerror=()=>resolve(null)})}catch{return null}}
let writes=0;
export async function writeScore(key,result){try{const db=await open();if(!db)return;const store=db.transaction('scores','readwrite').objectStore('scores');store.put({key,result,at:Date.now()});if(++writes%32===0){const r=store.getAll();r.onsuccess=()=>{const rows=r.result.sort((a,b)=>b.at-a.at);for(const row of rows.slice(192))store.delete(row.key)}}}catch{}}
