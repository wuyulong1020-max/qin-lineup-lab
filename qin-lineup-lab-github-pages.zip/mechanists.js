import {DB,H,teamTraits} from './engine.js?v=v3.0.1-20261019063103';
const cache=new Map();let learned={};
export function setActivationGains(gains={}){learned=gains;cache.clear()}
export function moduleUtility(active,mechs){
 const ids=new Set([...active,...mechs]);let value=0;
 for(const c of DB.combos)if(c.memberIds.some(id=>active.includes(id))&&c.memberIds.every(id=>ids.has(id))){const area=/全体|三行|链状|单排/.test(c.target)?4:2;const special=/护盾|真实伤害/.test(c.text)?1.2:0;value+=Math.max(.2,learned[c.id]??c.chance*(c.coefficient*area+special)*6)}
 for(const f of DB.factions){const n=[...ids].filter(id=>H[id].faction===f.id).length;for(const t of f.tiers)if(n>=t.count)value+=Math.max(.1,learned[f.id+'@'+t.count]??(t.count>=7?2.5:t.count>=4?1.7:1))}
 return value;
}
export function mechOptions(active,pool,count,required=[],limit=4){
 const allowed=pool.filter(x=>!active.includes(x.id)),available=new Set(allowed.map(x=>x.id));
 if(required.some(id=>!available.has(id))||required.length>count||allowed.length<count)return [];
 const key=active.join('.')+'|'+allowed.map(x=>x.id).sort().join('.')+'|'+count+'|'+required.join('.');
 if(cache.has(key))return cache.get(key).slice(0,limit);
 const blocks=[];
 for(const c of DB.combos){const missing=c.memberIds.filter(id=>!active.includes(id));if(missing.length&&missing.length<=count&&c.memberIds.some(id=>active.includes(id))&&missing.every(id=>available.has(id)))blocks.push(missing)}
 for(const f of DB.factions){const n=active.filter(id=>H[id].faction===f.id).length;for(const t of f.tiers){const need=t.count-n;if(need>0&&need<=count){const xs=allowed.filter(x=>H[x.id].faction===f.id).sort((a,b)=>(H[a.id].rarity==='epic'?-1:1)-(H[b.id].rarity==='epic'?-1:1)||a.id.localeCompare(b.id));if(xs.length>=need){blocks.push(xs.slice(0,need).map(x=>x.id));if(xs.length>need)blocks.push(xs.slice(-need).map(x=>x.id))}}}}
 let beam=[required.slice()];for(let step=0;step<count;step++){
  const next=new Map();for(const b of beam){next.set(b.slice().sort().join('.'),b);for(const block of blocks){const merged=[...new Set([...b,...block])];if(merged.length<=count)next.set(merged.slice().sort().join('.'),merged)}}
  beam=[...next.values()].sort((a,b)=>moduleUtility(active,b)-moduleUtility(active,a)||b.length-a.length||a.join('.').localeCompare(b.join('.'))).slice(0,12);
 }
 const filled=beam.map(xs=>[...xs,...allowed.map(x=>x.id).filter(id=>!xs.includes(id))].slice(0,count));const seen=new Set();const out=filled.filter(xs=>{const k=xs.slice().sort().join('.');if(seen.has(k))return false;seen.add(k);return true}).sort((a,b)=>moduleUtility(active,b)-moduleUtility(active,a)||a.join('.').localeCompare(b.join('.'))).slice(0,4);
 if(cache.size>18000)cache.clear();cache.set(key,out);return out.slice(0,limit);
}
export function recommendMechs(active,pool,count,required=[]){const out=mechOptions(active,pool,count,required);if(!out.length)throw Error('已拥有弟子不足以补齐机师');return out[0]}
export function remech(team,pool=null,required=[]){const ids=team.active.map(x=>x.id),p=pool||DB.heroes.map(h=>({id:h.id,star:team.mechs[0]?.star??team.active[0].star})),stars=new Map(p.map(x=>[x.id,x.star]));return {...team,mechs:recommendMechs(ids,p,team.mechs.length,required).map(id=>({id,star:stars.get(id)}))}}
