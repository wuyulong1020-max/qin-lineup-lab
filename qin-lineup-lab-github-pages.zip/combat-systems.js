
import {emptyMetrics} from './statistics.js?v=v4.0.2-20261128013410';
import {COMBAT_EVIDENCE} from './combat-evidence.js?v=v4.0.2-20261128013410';

export const BEASTS=Object.freeze({
 xuanwu:{element:'水',name:'机关玄武'},bingmo:{element:'火',name:'兵魔神'},
 sanlang:{element:'金',name:'破土三郎'},baihu:{element:'土',name:'机关白虎'},
 qinglong:{element:'木',name:'机关青龙'}
});
export const AWAKE_RATE=[0,.03,.07,.07,.13,.20,.275,.35,.35,.425,.50];
export const AWAKE_SHIELD=[0,6000,12000,12000,22000,32000,44000,56000,56000,71000,86000].map(x=>x/12);
const threeFee=new Set('h01 h02 h03 h06 h07 h15 h17 h23 h26'.split(' '));
const outfitCache=new Map(),noBonus=Object.freeze({});
const element=id=>COMBAT_EVIDENCE.elements[id];

export function levelGrowth(level){
 if(level>100)return .4*level-19;
 const anchors=COMBAT_EVIDENCE.growth;
 const last=anchors.at(-1);
 if(level>last.level)return last.factor+(level-last.level)*COMBAT_EVIDENCE.slope;
 const n=anchors.findIndex(a=>a.level>=level);
 const upper=anchors[n];
 if(upper.level===level)return upper.factor;
 const lower=anchors[n-1];
 return lower.factor+(upper.factor-lower.factor)*(level-lower.level)/(upper.level-lower.level);
}
function selectClothing(id,role,star,awake,fast){
 const all=COMBAT_EVIDENCE.wardrobe[id]||[];
 if(awake)return all;
 const limit=star>=20?(id==='h07'?3:threeFee.has(id)?2:1):id==='h07'?1:0;
 if(!limit)return [];
 const allowed=all.filter(x=>x.kind!=='G');
 const confirmed=COMBAT_EVIDENCE.outfits[id]?.group||[];
 const priorities=role==='attack'?'SAPHDCBE':role==='defense'?'HDBSAPCE':'SHDAPBCE';
 const value=x=>{
  const manual=confirmed.indexOf(x.kind);
  const ordinary=priorities.indexOf(x.kind);
  return 20*(manual<0?0:confirmed.length-manual)+(x.kind==='S'&&!fast?0:ordinary<0?0:priorities.length-ordinary);
 };
 return allowed.slice().sort((a,b)=>value(b)-value(a)).slice(0,limit);
}
export function wardrobeBonus(id,role,star,awake,fast,selection){
 const key=id+':'+Number(star>=20)+':'+Number(awake)+':'+Number(fast)+':'+(selection?.join(',')||'');
 if(!outfitCache.has(key)){
  const bonus={};
  const clothes=selection&&!awake?(COMBAT_EVIDENCE.wardrobe[id]||[]).filter(x=>selection.includes(x.kind)):selectClothing(id,role,star,awake,fast);
  for(const cloth of clothes)for(const [k,v] of Object.entries(cloth.delta))bonus[k]=(bonus[k]||0)+v;
  outfitCache.set(key,Object.freeze(bonus));
 }
 return outfitCache.get(key);
}
const outfitLabels={atk:'攻击',def:'防御',hp:'血量',speed:'速度',pvpReduce:'PVP免伤',ignoreDef:'无视防御',inner:'内力',heal:'治疗',crit:'暴击',pierce:'技能穿透',skillReduce:'技伤减免',dodge:'闪避',block:'招架',antiCrit:'抗暴',resist:'负面抗性',trueResist:'真伤抵抗',ignoreInner:'无视内力',damage:'伤害'};
export function wardrobeAdvice(id,role,star,awake,fast){
 const selected=selectClothing(id,role,star,awake,fast);
 const preference=COMBAT_EVIDENCE.outfits[id]?.choice;
 const preferred=selected.find(x=>x.kind===preference)||selected[0];
 return preferred?Object.entries(preferred.delta).map(([k,v])=>(outfitLabels[k]||k)+'+'+(k==='speed'?v:Number((v*100).toFixed(2))+'%')).join('、'):'暂无可用';
}
export const matchingBeasts=ids=>Object.keys(BEASTS).filter(k=>ids.some(id=>element(id)===BEASTS[k].element));
export function beastFor(team,override){
 const kind=team.beast||matchingBeasts(team.active.map(x=>x.id))[0];
 if(!kind)return null;
 const stars=team.active.map(x=>x.star).sort((a,b)=>a-b);
 const star=stars[Math.floor(stars.length/2)];
 return {kind,rank:override??(star>=20?10:star>=10?8:0),guardian:team.guardian};
}
const guardianTen=Object.freeze({speed:12,inner:.30});
const guardianFifteen=Object.freeze({speed:30,inner:.48,atk:.18,def:.27,hp:.18});
export function beastBonus(rank){
 return rank>=15?guardianFifteen:rank>=9?guardianTen:noBonus;
}
export function makeBeast(units,side,config){
 const {kind,rank}=config;
 let guardian=null;
 for(const u of units){
  if(element(u.id)!==BEASTS[kind]?.element)continue;
  if(u.id===config.guardian){guardian=u;break;}
  if(!guardian||u.atk>guardian.atk)guardian=u;
 }
 if(!guardian)return null;
 const parallel=rank>=10;
 const actor={id:'beast-'+kind,side,isBeast:true,h:{faction:null},addedDamage:0,flags:{},roundFlags:{},
  buffs:{},bonus:{crit:(parallel?.25:0)+(rank>=15?.45:0),critDamage:parallel?.02:0,pierce:(parallel?.04:0)+(rank>=15?.36:0),...(rank>=15?{ignoreDef:.45,ignoreInner:.72}:{})},
  turns:0,hp:1,cultivationCrit:0,metrics:emptyMetrics()};
 const scale=rank>=10?1:rank>=8?(162620+(229450-162620)*4/6)/285555:111383/285555;
 // The observed deployed total includes the flat Brotherhood attack.
 return {kind,rank,guardian,actor,power:417206/12*scale};
}
export function castBeast(combat,side,beast){
 const {kind,rank,actor,power}=beast;
 if(kind==='xuanwu'){
  const falloff=rank>=8?.9:.8;
  for(const [i,u] of combat.low(side,rank>=14?5:4).entries()){
   combat.heal(actor,u,power*falloff**i);
   if(!i)combat.buff(u,'immune',2,1,actor);
  }
  return;
 }
 const enemies=combat.alive(1-side);
 const front=enemies.filter(u=>u.pos<4);
 const targets=kind==='bingmo'?enemies:kind==='qinglong'?(front.length?front:enemies):
  combat.sample(enemies,kind==='baihu'?(rank>=14?4:3):rank>=8?4:3);
 let causedDamage=false;
 for(const u of targets){
  let raw=power,extra=0;
  if(kind==='bingmo'){raw*=rank>=8?1+.10*(9-enemies.length):1;extra=Math.min(raw,u.max*.05);}
  if(kind==='baihu'&&rank>=8&&u.pos<4)raw*=1.3;
  const result=combat.damage(actor,u,raw+extra,{extraDamage:extra,forceCrit:kind==='baihu',
   pierceShield:kind==='bingmo'&&rank>=14,ignoreSkillReduction:kind==='qinglong',area:true});
  causedDamage ||= result.amount>0;
  if(kind==='qinglong'){
   if(rank>=8&&combat.rng()<.4)combat.buff(u,'fragile',1,1,actor);
   if(rank>=14&&combat.rng()<.6)combat.buff(u,'weak',1,1,actor);
  }
 }
 if(kind==='sanlang'&&causedDamage)
  for(const u of combat.sample(combat.alive(side),rank>=14?5:3))combat.buff(u,'detect',2,1,actor);
}

