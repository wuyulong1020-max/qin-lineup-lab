
import {configure} from './engine.js?v=v4.0.1-20261125133723';
import {runCup} from './cup-simulation.js?v=v4.0.1-20261125133723';
let load=null;
onmessage=async({data:{left,right}})=>{
 try{
  load??=fetch(new URL('./catalog.json',import.meta.url)).then(async r=>{
   if(!r.ok)throw Error('弟子资料载入失败。');
   configure(await r.json());
  }).catch(error=>{load=null;throw error;});
  await load;
  const result=runCup(left,right,(done,total,message)=>postMessage({kind:'progress',done,total,message}));
  postMessage({kind:'result',result});
 }catch(error){postMessage({kind:'error',message:error.message});}
};

