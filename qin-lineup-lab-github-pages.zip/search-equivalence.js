import {DB,H,starFactor,teamTraits} from './engine.js?v=v3.4.0-20261109212320';
// QIN-3.4 checks mo>=6 as well as the displayed faction thresholds.
const THRESHOLDS={bai:[2,5],chu:[2,4],di:[3,5],mo:[3,4,6,8],nong:[4,5,7],yin:[2,4,7]};
export function stable(value){return JSON.stringify(value,(k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b))):v)}
export function mechanistKey(team){return team.mechs.map(x=>x.id).sort().join('.')}
export function rosterKey(team){return team.active.map(x=>x.id).sort().join('.')}
export function combatEffectKey(team){
 const traits=teamTraits(team),units=new Map([...team.active,...team.mechs].map(x=>[x.id,x])),combos=DB.combos.filter(c=>traits.combos.includes(c.id));
 const levels=combos.map(c=>[c.id,Math.min(...c.memberIds.map(id=>units.get(id).star)),c.trigger==='ally_death'?c.memberIds.reduce((s,id)=>s+(team.mechs.some(x=>x.id===id)?H[id].stats.atk*starFactor(units.get(id).star):0),0):0]);
 const factions=DB.factions.map(f=>[f.id,[...new Set([...(THRESHOLDS[f.id]||[]),...f.tiers.map(t=>t.count)])].filter(n=>traits.factions[f.id]>=n).sort((a,b)=>a-b)]);
 return stable([team.awakening??0,team.active,levels,factions]);
}
// Enumerate exact feasible signatures. Relevant members remain separate until
// combo levels and special mechanist attack contributions have been included.
export function exactMechanistStates(active,pool,count,{costly=()=>false,costLimit=count}={}){
 const as=new Set(active),allowed=pool.filter(u=>!as.has(u.id)),byId=new Map(pool.map(u=>[u.id,u])),F=DB.factions;
 const possible=DB.combos.filter(c=>c.memberIds.some(id=>as.has(id))&&c.memberIds.every(id=>as.has(id)||byId.has(id))),relevant=new Set(possible.flatMap(c=>c.memberIds.filter(id=>!as.has(id))));
 const groups=new Map();for(const u of allowed){const fi=F.findIndex(f=>f.id===H[u.id].faction),key=fi+'|'+(relevant.has(u.id)?u.id:'filler');if(!groups.has(key))groups.set(key,{fi,units:[]});groups.get(key).units.push(u)}
 let states=[{ids:[],counts:F.map(()=>0),cost:0,relevant:[]}];
 for(const g of groups.values()){
  g.units.sort((a,b)=>Number(costly(a.id))-Number(costly(b.id))||a.id.localeCompare(b.id));const next=new Map();
  for(const s of states)for(let q=0;q<=Math.min(g.units.length,count-s.ids.length);q++){
   const picked=g.units.slice(0,q),cost=s.cost+picked.filter(u=>costly(u.id)).length;if(cost>costLimit)continue;
   const counts=s.counts.slice();counts[g.fi]+=q;const ids=s.ids.concat(picked.map(u=>u.id)),rel=s.relevant.concat(picked.filter(u=>relevant.has(u.id)).map(u=>u.id)),key=ids.length+'|'+counts.join(',')+'|'+rel.join('.')+'|'+cost;
   if(!next.has(key))next.set(key,{ids,counts,cost,relevant:rel});
  }states=[...next.values()];
 }
 const out=new Map();for(const s of states)if(s.ids.length===count){const team={active:active.map(id=>({...byId.get(id)})),mechs:s.ids.map(id=>({...byId.get(id)}))},key=combatEffectKey(team),old=out.get(key);if(!old||s.cost<old.cost)out.set(key,{key,mechs:s.ids,cost:s.cost})}return [...out.values()];
}
