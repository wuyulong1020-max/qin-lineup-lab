
import {H} from './engine.js?v=v4.0.0-20261124034734';
import {OBSERVED_LAYOUT} from './layout-evidence.js?v=v4.0.0-20261124034734';
const zeros=Object.freeze(Array(9).fill(0));
const expected={attack:.045,defense:.97,support:.42};
const sum=a=>a.reduce((s,v)=>s+v,0);
const front=a=>sum(a.slice(0,4));
const cache=new Map();
export function empiricalLayout(formation){
 if(formation.length!==9||new Set(formation).size!==9||formation.some(id=>!H[id]))return formation.slice();
 const ids=formation.slice().sort(),key=ids.join('.');
 if(cache.has(key))return cache.get(key).slice();
 const n=ids.filter(id=>H[id].role==='defense').length;
 const cost=ids.map(id=>{
  const role=H[id].role;
  const read=k=>OBSERVED_LAYOUT[k]||zeros;
  const roleAll=read(role),roleN=read(role+'-'+n),heroAll=read(id),heroN=read(id+'-'+n);
  const general=(front(roleAll)+expected[role]*8)/(sum(roleAll)+8);
  const roleRate=(front(roleN)+general*16)/(sum(roleN)+16);
  const heroRate=(front(heroAll)+roleRate*10)/(sum(heroAll)+10);
  const p=(front(heroN)+heroRate*7)/(sum(heroN)+7);
  return ids.map((_,i)=>{
   const l=i<4?0:4,r=i<4?4:9;
   const mass=sum(heroN.slice(l,r))+.45*sum(heroAll.slice(l,r))+1.9*(r-l);
   return 1.8*Math.log(i<4?p:1-p)+.55*Math.log((heroN[i]+.45*heroAll[i]+1.9)/mass);
  });
 });
 const dp=new Float64Array(512).fill(-Infinity),last=new Int8Array(512),layers=new Uint8Array(512);
 dp[0]=0;
 for(let mask=1;mask<512;mask++)layers[mask]=layers[mask>>1]+(mask&1);
 for(let mask=0;mask<511;mask++){
  for(let k=0;k<9;k++){
   if(mask&(1<<k))continue;
   const next=mask|(1<<k),value=dp[mask]+cost[k][layers[mask]];
   if(value>dp[next]){dp[next]=value;last[next]=k;}
  }
 }
 const picked=[];
 for(let mask=511;mask;mask^=1<<last[mask])picked.push(ids[last[mask]]);
 picked.reverse();
 if(cache.size>=4096)cache.clear();
 cache.set(key,picked);
 return picked.slice();
}

