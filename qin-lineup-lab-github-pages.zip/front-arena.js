// Display helpers intentionally have no dependency on the simulation/mechanist bundle.
export const STYLES=['爆发速攻','群攻压血','控制压制','反击制胜','持续消耗','奶盾续航'];
export function environment(star=20,mechCount=6){const awake=star==='awake8';if((!awake&&![2,10,20].includes(+star))||+mechCount!==6)throw Error('对战环境无效');return {star:awake?20:+star,awakening:awake?8:0,mechCount:+mechCount,key:star+'-m'+mechCount}}
export function teamKey(t){const base=(t.awakening===8?'awake8|':'')+t.active.map(x=>x.id+':'+x.star+(x.awakening===8?'a8':'')).join('.')+'|'+t.mechs.map(x=>x.id+':'+x.star).sort().join('.');const overrides=t.awakening===8?t.active.filter(x=>x.awakening===0).map(x=>x.id).sort():[];return base+(overrides.length?'|a0:'+overrides.join('.'):'')}
export function tierOf(score,cuts=[]){const half=cuts.length===10;return 'T'+cuts.filter(c=>half?score<c-1e-9:score<c).length*(half?.5:1)}
let tools;
export async function loadTeamTools(){return tools??=await import('./fixed-arena.js?v=v3.4.6-20261121010843')}
export function teamFrom(...args){if(!tools)throw Error('请等待机师资料加载完成');return tools.teamFrom(...args)}
