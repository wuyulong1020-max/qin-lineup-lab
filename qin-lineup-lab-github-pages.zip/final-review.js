import {mergeFixed} from './fixed-arena.js?v=v3.3.0-20261109094509';

const clone=value=>JSON.parse(JSON.stringify(value));
const defaultKey=team=>JSON.stringify([team.awakening??0,team.active,team.mechs.slice().sort((a,b)=>a.id.localeCompare(b.id))]);
const order=(rows,key)=>rows.slice().sort((a,b)=>b.result.score-a.result.score||key(a.team).localeCompare(key(b.team)));

// Extend the already computed independent review. Every extra pass has its own
// shared seed, and only those new 2400-game passes are executed and counted.
export async function reviewCloseFinalists(rows,{score,key=defaultKey,seed='independent-review',sourceKey=null,targetBattles=7200,passBattles=2400,maxCandidates=7,gap=1.5,batchSize=3,progress=()=>{},resume=null}={}){
 if(typeof score!=='function')throw Error('缺少追加复核评分器');
 const state=resume||{version:1,rows:clone(rows),pass:0,cursor:0,sampledBattles:0,finished:false,stable:false};
 if(state.version!==1)throw Error('追加复核进度版本不匹配');
 if(!state.cohort){
  const sorted=order(state.rows,key),leader=sorted[0];
  const near=leader?sorted.filter(row=>row.result.fullPool&&row.result.n>=passBattles&&leader.result.score-row.result.score<=Math.max(gap,(leader.result.halfWidth||0)+(row.result.halfWidth||0))):[],control=sourceKey&&near.find(row=>key(row.team)===sourceKey);
  // A control close enough to affect the result belongs to the same cohort.
  state.cohort=near.filter(row=>key(row.team)!==sourceKey).slice(0,maxCandidates-(control?1:0)).map(row=>key(row.team));if(control)state.cohort.push(sourceKey);
  if(state.cohort.length<2)state.finished=true;
 }
 const maxPasses=Math.max(0,Math.ceil(targetBattles/passBattles)-1);
 while(!state.finished&&state.pass<maxPasses){
  if(!state.teams)state.teams=state.cohort.map(id=>state.rows.find(row=>key(row.team)===id)).filter(row=>row.result.n<targetBattles).map(row=>clone(row.team));
  if(!state.teams.length){state.finished=true;break}
  while(state.cursor<state.teams.length){
   const teams=state.teams.slice(state.cursor,state.cursor+batchSize),results=await Promise.all(teams.map(async team=>({team,result:await score(team,passBattles,seed+'/close-review-'+state.pass,{fresh:true,phase:'verify-more'})})));
   for(const row of results){const index=state.rows.findIndex(old=>key(old.team)===key(row.team));state.rows[index]={team:row.team,result:mergeFixed(state.rows[index].result,row.result)};state.sampledBattles+=row.result.n}
   state.cursor+=teams.length;progress({state,rows:order(state.rows,key),done:state.pass*state.cohort.length+state.cursor,total:maxPasses*state.cohort.length});
  }
  state.pass++;state.cursor=0;delete state.teams;
  const sorted=order(state.rows,key),first=sorted[0],second=sorted[1];
  state.stable=!second||first.result.score-second.result.score>Math.max(gap,(first.result.halfWidth||0)+(second.result.halfWidth||0));
  if(state.stable||state.pass>=maxPasses)state.finished=true;
  progress({state,rows:sorted,done:state.pass*state.cohort.length,total:state.finished?state.pass*state.cohort.length:maxPasses*state.cohort.length});
 }
 state.rows=order(state.rows,key);return {rows:state.rows,cohortSize:state.cohort.length,passes:state.pass,sampledBattles:state.sampledBattles,stable:state.stable,checkpoint:state};
}
