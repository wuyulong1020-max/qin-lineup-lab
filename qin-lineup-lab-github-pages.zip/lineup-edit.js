// Preserve the current lineup when selecting itself; an existing member moves by swapping slots.
export function editLineupSlot(team,index,id,environment,rebuild){
 if(index<0||index>=team.active.length)throw Error('无效站位');
 if(id===team.active[index].id)return team;
 const next=structuredClone(team),other=next.active.findIndex(x=>x.id===id);
 if(other>=0)[next.active[index],next.active[other]]=[next.active[other],next.active[index]];
 else next.active[index]={id,star:environment.star};
 // Mechanists continue using the same automatic policy as other member edits.
 next.mechs=rebuild(next.active.map(x=>x.id),environment,{name:team.name}).mechs;
 return next;
}
