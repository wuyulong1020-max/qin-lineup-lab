import {DB,H,validateTeam} from './engine.js?v=v3.4.0-20261109212320';
import {normalizeSearchConstraints} from './profiles.js?v=v3.4.0-20261109212320';
const clone=value=>structuredClone(value),costlyNames=new Set(['焱妃','东皇太一','王翦','月神','伏念','星魂','盖聂','卫庄','晓梦']),costly=id=>costlyNames.has(H[id]?.name);
let selector,selectorPromise;
// Loaded only when editing a configuration, never as part of the entry bundle.
export async function loadLineupEditTools(){if(!selectorPromise)selectorPromise=import('./constrained-activation.js?v=v3.4.0-20261109212320').then(module=>{selector=(ids,pool,count,costLimit)=>module.constrainedMechSearch(DB,ids,pool,count,{costIds:pool.filter(x=>costly(x.id)).map(x=>x.id),costLimit,limit:1}).options[0]}).catch(error=>{selectorPromise=null;throw error});await selectorPromise}
function context(team,environment,source=team){
 const constraints=normalizeSearchConstraints(team.searchConstraints,DB),excluded=new Set(constraints?.excluded||[]),pool=new Map((constraints?.pool||DB.heroes.map(h=>({id:h.id,star:environment.star}))).map(x=>[x.id,clone(x)]));
 // Source units override their old pool snapshot, including 0-star/0-awakening.
 for(const unit of [...source.active,...source.mechs,...team.active,...team.mechs]){if(!pool.has(unit.id))throw Error('当前配置含原英雄池以外的弟子');pool.set(unit.id,clone(unit))}
 return {constraints,excluded,pool,costLimit:constraints?.costLimit??9};
}
function assertAllowed(team,environment,ctx){validateTeam(team,environment.mechCount);const used=[...team.active,...team.mechs];if(used.some(x=>!ctx.pool.has(x.id)||ctx.excluded.has(x.id)))throw Error('当前配置不符合原英雄池或排除名单');if(used.filter(x=>costly(x.id)).length>ctx.costLimit)throw Error('当前配置超过原搜索三费上限')}
export function lineupEditChoices(team,environment,{role='active',index=0}={}){
 const ctx=context(team,environment),active=new Set(team.active.map(x=>x.id));
 return [...ctx.pool.keys()].filter(id=>{if(ctx.excluded.has(id))return false;if(role==='mech'){if(active.has(id)||team.mechs.some((x,i)=>i!==index&&x.id===id))return false;return [...team.active,...team.mechs.filter((_,i)=>i!==index),{id}].filter(x=>costly(x.id)).length<=ctx.costLimit}if(H[id]?.rarity!=='legendary')return false;if(active.has(id))return true;const used=team.active.filter((_,i)=>i!==index).concat({id},team.manualMechs?team.mechs:[]);return used.filter(x=>costly(x.id)).length<=ctx.costLimit});
}
export function restoreAutomaticMechanists(team,environment,rebuild,{source=team}={}){
 const next=clone(team),ctx=context(next,environment,source),pool=[...ctx.pool.values()].filter(x=>!ctx.excluded.has(x.id)),ids=next.active.map(x=>x.id),activeCost=ids.filter(costly).length;
 if(ids.some(id=>ctx.excluded.has(id)))throw Error('上阵弟子与原排除名单冲突');if(activeCost>ctx.costLimit)throw Error('上阵弟子超过原搜索三费上限');
 let mechs;if(ctx.constraints){if(!selector)throw Error('请等待机师资料加载完成');mechs=selector(ids,pool,environment.mechCount,ctx.costLimit-activeCost)}else mechs=rebuild(ids,environment,{name:next.name,pool}).mechs.map(x=>x.id);
 if(!mechs||mechs.length!==environment.mechCount)throw Error('原英雄池和搜索限制下无法补齐机师');next.mechs=mechs.map(id=>clone(ctx.pool.get(id)));delete next.manualMechs;assertAllowed(next,environment,ctx);return next;
}
export function editLineupSlot(team,index,id,environment,rebuild){
 if(index<0||index>=team.active.length)throw Error('无效站位');if(id===team.active[index].id)return team;
 const next=clone(team),other=next.active.findIndex(x=>x.id===id);
 // A pure swap changes no member, mechanic, star, awakening, or constraint.
 if(other>=0){[next.active[index],next.active[other]]=[next.active[other],next.active[index]];return next}
 const ctx=context(team,environment);if(!ctx.pool.has(id)||ctx.excluded.has(id)||H[id]?.rarity!=='legendary')throw Error('这名弟子不在原可用池中或已被排除');next.active[index]=clone(ctx.pool.get(id));
 if(next.manualMechs){if(next.mechs.some(x=>x.id===id))throw Error('这名弟子已是手动机师，请先更换机师或恢复自动推荐');assertAllowed(next,environment,ctx);return next}
 return restoreAutomaticMechanists(next,environment,rebuild,{source:team});
}
export function editLineupMechanist(team,index,id,environment){
 if(index<0||index>=team.mechs.length)throw Error('无效机师位置');const ctx=context(team,environment);if(!ctx.pool.has(id)||ctx.excluded.has(id))throw Error('这名机师不在原可用池中或已被排除');const next=clone(team);next.mechs[index]=clone(ctx.pool.get(id));next.manualMechs=true;assertAllowed(next,environment,ctx);return next;
}
export function resizeLineupMechanists(team,environment){
 const next=clone(team),ctx=context(next,environment),present=new Set(next.active.map(x=>x.id)),mechs=[];let cost=next.active.filter(x=>costly(x.id)).length;
 for(const unit of [...next.mechs,...ctx.pool.values()]){if(mechs.length===environment.mechCount)break;if(present.has(unit.id)||ctx.excluded.has(unit.id))continue;const extra=costly(unit.id)?1:0;if(cost+extra>ctx.costLimit)continue;mechs.push(clone(ctx.pool.get(unit.id)));present.add(unit.id);cost+=extra}
 if(mechs.length!==environment.mechCount)throw Error('原英雄池和搜索限制下无法补齐当前数量的机师');next.mechs=mechs;assertAllowed(next,environment,ctx);return next;
}
