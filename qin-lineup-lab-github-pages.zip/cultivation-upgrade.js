// Personal cultivation is independent of the selected opponent environment.
export const UPGRADE_REVISION='unit-next-tier-20261109-v1';
export function nextCultivation(unit,teamAwakening=0){
 if(!unit||!Number.isInteger(unit.star)||unit.star<0||unit.star>20)throw Error('弟子星级应为0—20的整数');
 const fromStar=unit.star,fromAwakening=fromStar===20&&(unit.awakening??teamAwakening??0)===8?8:0;
 if(fromStar===20&&fromAwakening===8)return null;
 const toStar=fromStar<2?2:fromStar<10?10:20,toAwakening=fromStar===20?8:0;
 return {from:fromStar,to:toAwakening===8?'8觉':toStar,fromStar,toStar,fromAwakening,toAwakening,fromLabel:fromAwakening===8?'8觉':fromStar+'星',toLabel:toAwakening===8?'8觉':toStar+'星',transition:toAwakening===8?'awakening':'star'};
}
export function nextUnitUpgrade(team,id){
 const unit=team.active.find(x=>x.id===id);if(!unit)throw Error('要进化的弟子不在上阵名单中');const step=nextCultivation(unit,team.awakening);if(!step)return null;
 return {id,...step,team:{...team,active:team.active.map(x=>x.id===id?{...x,star:step.toStar,awakening:step.toAwakening}:{...x}),mechs:team.mechs.map(x=>({...x}))}};
}
