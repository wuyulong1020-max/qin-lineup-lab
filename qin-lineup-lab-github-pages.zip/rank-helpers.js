export const defaultMetric=view=>view==='进攻'?'damage':view==='防御'?'damageTaken':'delta';
export function metricValue(row,metric,kind){
 if(metric==='delta')return kind==='lineups'?row.result.score:row.delta;
 const m=kind==='lineups'?row.result.metrics:row.functional||{};
 return metric==='absorbed'?(m.absorbed||0)+(m.factionAbsorbed||0)+(m.numericAbsorbed||0):m[metric]||0;
}
export const rosterKey=team=>team.active.map(x=>x.id+':'+x.star).sort().join('|');
export function bestRosters(rows,locks=[],limit=3){
 const out=[],seen=new Set();
 for(const x of rows.slice().sort((a,b)=>b.result.score-a.result.score)){
  if(!locks.every(id=>x.team.active.some(u=>u.id===id)))continue;
  const key=rosterKey(x.team);if(seen.has(key))continue;seen.add(key);out.push(x);
  if(out.length>=Math.min(limit,locks.length===9?1:3))break;
 }return out;
}
export function functionalFamilies(rows,metric,familyRows){
 return familyRows(rows).map(f=>{
  const variants=[f,...(f.variants||[])].map(x=>({...x,variants:[]})).sort((a,b)=>metricValue(b,metric,'lineups')-metricValue(a,metric,'lineups'));
  return {...variants[0],variants:variants.slice(1)};
 });
}
