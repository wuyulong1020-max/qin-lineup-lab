export const defaultMetric=()=> 'delta';
const commonMetrics=[['damage','有效伤害'],['damageTaken','实际承伤'],['heal','有效治疗'],
 ['absorbed','护盾吸收'],['controlInflicted','控制次数']];
export function rankMetricOptions(kind,view,comboMode){
 const primary=kind==='lineups'?'阵容评分':'平均评分提升';
 const comparative=kind==='factions'||(kind==='combos'&&comboMode==='skill');
 const shared=commonMetrics.map(([metric,label])=>[metric,comparative&&metric==='damageTaken'?'承伤减少':label]);
 return [['delta',primary],...shared,...(kind!=='heroes'||view==='进攻'?[['kills','击杀人数']]:[])];
}
export function metricValue(row,metric,kind){
 if(metric==='delta')return kind==='lineups'?row.result.score:row.delta;
 const m=kind==='lineups'?row.result.metrics:row.functional||{};
 if(metric==='absorbed')return (m.absorbed||0)+(m.factionAbsorbed||0)+(m.numericAbsorbed||0);
 const value=m[metric]||0;
 return kind==='combos'&&row.activeId&&metric==='damageTaken'?-value:value;
}
export const rosterKey=team=>team.active.map(x=>x.id+':'+x.star).sort().join('|');
export function bestRosters(rows,locks=[],limit=3){
 const out=[],seen=new Set();
 for(const x of rows.slice().sort((a,b)=>b.result.score-a.result.score)){
  if(!locks.every(id=>x.team.active.some(u=>u.id===id)))continue;
  const key=rosterKey(x.team);if(seen.has(key))continue;seen.add(key);out.push(x);
  if(out.length>=Math.min(limit,locks.length===9?1:3))break;
 }return out;
}
export function functionalFamilies(rows,metric,familyRows){
 return familyRows(rows).map(f=>{
  const variants=[f,...(f.variants||[])].map(x=>({...x,variants:[]})).sort((a,b)=>metricValue(b,metric,'lineups')-metricValue(a,metric,'lineups'));
  return {...variants[0],variants:variants.slice(1)};
 });
}
