
import {H,DB} from './engine.js?v=v4.0.4-20261128133409';
import {matchingBeasts,BEASTS} from './combat-systems.js?v=v4.0.4-20261128133409';
import {COMBAT_EVIDENCE} from './combat-evidence.js?v=v4.0.4-20261128133409';
const model={
 teams:[0,1].map(()=>({active:Array.from({length:9},()=>({id:'',level:300,star:20,awakening:0})),beast:'',guardian:''})),
 worker:null,running:false,result:null,error:'',message:''
};
const safe=t=>String(t).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const label=pos=>pos<4?'前'+(pos+1):'后'+(pos-3);
const option=(key,text,chosen)=>'<option value="'+safe(key)+'"'+(key===chosen?' selected':'')+'>'+safe(text)+'</option>';
const number=(name,min,max,slot,k)=>
 '<label><span>'+name+'</span><input type="number" min="'+min+'" max="'+max+'" value="'+slot[k]+'" aria-label="'+name+'" data-cup-field="'+k+'" required></label>';
function seat(u,i,heroes){
 return '<div class="cup-seat" data-seat="'+i+'"><label class="cup-disciple"><span>'+label(i)+'</span><select aria-label="'+label(i)+'弟子" data-cup-field="id">'+
  option('','选择弟子',u.id)+heroes.map(h=>option(h.id,h.name,u.id)).join('')+'</select></label>'+
  number('等级',1,300,u,'level')+number('星级',0,30,u,'star')+number('觉醒',0,10,u,'awakening')+'</div>';
}
function guardianField(side){
 const team=model.teams[side],active=team.active.map(s=>s.id).filter(Boolean);
 const chosen=matchingBeasts(active)[0];
 const guardians=chosen?active.filter(id=>COMBAT_EVIDENCE.elements[id]===BEASTS[chosen].element):[];
 return guardians.length>1?'<label><span>守护弟子</span><select aria-label="守护弟子" data-cup-team="guardian">'+
   option('','自动选择',team.guardian)+guardians.map(id=>option(id,H[id].name,team.guardian)).join('')+'</select></label>':'';
}
function results(root){
 const target=root.querySelector('.cup-output');
 if(!target)return;
 target.replaceChildren();
 const submit=root.querySelector('.cup-submit');
 if(submit)submit.disabled=model.running;
 for(const panel of root.querySelectorAll('.cup-side'))panel.disabled=model.running;
 if(model.result){
  const score=document.createElement('div');score.className='cup-result-scores';
  for(const name of ['left','right']){
   const group=document.createElement('div'),strong=document.createElement('strong');
   strong.textContent=model.result[name].toFixed(1)+'%';
   group.append(name==='left'?'甲方模拟胜率':'乙方模拟胜率',strong);score.append(group);
  }
  const note=document.createElement('p');note.className='hint';note.textContent=model.result.note;
  target.append(score,note);
 }else if(model.error||model.message){
  const msg=document.createElement('p');msg.className=model.error?'error':'hint';msg.textContent=model.error||model.message;target.append(msg);
 }
}
function start(root){
 model.running=true;model.error='';model.result=null;model.message='正在准备战斗模拟…';
 results(root);
 try{
  model.worker??=new Worker(new URL('./cup-worker.js?v=v4.0.4-20261128133409',import.meta.url),{type:'module'});
  model.worker.onmessage=({data})=>{
   if(data.kind==='progress'){model.message=data.message;results(root);return;}
   model.running=false;model.message='';
   if(data.kind==='error')model.error=data.message;else model.result=data.result;
   results(root);
  };
  model.worker.onerror=()=>{
   model.error='模拟载入失败，请重试。';model.running=false;model.worker?.terminate();model.worker=null;results(root);
  };
  model.worker.postMessage({left:structuredClone(model.teams[0]),right:structuredClone(model.teams[1])});
 }catch(error){model.running=false;model.error=error.message;results(root);}
}
export function renderCup(root){
 const heroes=DB.heroes.filter(h=>h.rarity==='legendary').sort((a,b)=>a.name.localeCompare(b.name,'zh-CN'));
 root.innerHTML='<div class="page-head"><h1>杯赛竞猜</h1></div>'+
  '<p class="hint">照战报填写双方的弟子和站位。觉醒看不见时留0，机师自动推荐，出战优先选玄武。</p>'+
  '<form class="cup-form"><div class="cup-sides">'+model.teams.map((tm,side)=>
   '<fieldset class="panel cup-side" data-cup-side="'+side+'"><legend>'+['甲方','乙方'][side]+'</legend>'+
   tm.active.map((u,i)=>seat(u,i,heroes)).join('')+'<div class="cup-beasts">'+guardianField(side)+'</div></fieldset>').join('')+
  '</div><div class="actions"><button class="primary cup-submit" type="submit">开始模拟</button></div>'+
  '<div class="panel cup-output" aria-live="polite"></div></form>';
 root.querySelector('.cup-form').onclick=event=>{if(model.running&&event.target.closest('button'))event.preventDefault();};
 root.querySelector('.cup-form').oninput=event=>{
  const target=event.target,side=target.closest('[data-cup-side]')?.dataset.cupSide;
  if(side===undefined||model.running)return;
  const row=target.closest('[data-seat]')?.dataset.seat;
  const team=model.teams[+side];
  if(target.dataset.cupField&&row!==undefined){
   const key=target.dataset.cupField;
   team.active[+row][key]=key==='id'?target.value:target.valueAsNumber;
   if(key==='id'){
    team.guardian='';
    target.closest('.cup-side').querySelector('.cup-beasts').innerHTML=guardianField(+side);
   }
  }
  if(target.dataset.cupTeam){
   team[target.dataset.cupTeam]=target.value;
  }
  model.result=null;model.error='';results(root);
 };
 root.querySelector('.cup-form').onsubmit=event=>{event.preventDefault();if(!model.running)start(root);};
 results(root);
}

