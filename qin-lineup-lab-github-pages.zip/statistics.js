// Scores are bounded in [0,1]. One independent sample is a swapped-seat pair.
export const METRICS = ['damage','directDamage','dotDamage','executeDamage','hpReduction','friendlyFire','heal','overheal','absorbed','factionAbsorbed','protected','shieldsGiven','damageTaken','kills','aliveRounds','normalDamage','skillDamage','criticalDamage','control','controlInflicted','cleanses','redistributedGain','redistributedLoss','areaDamage','counterDamage','buffsApplied','debuffsApplied'];
export const emptyMetrics = () => Object.fromEntries(METRICS.map(k => [k, 0]));
export function pairedInterval(rate, boundScale, confidence = .95) {
  if (!Number.isFinite(rate) || rate < 0 || rate > 1 || !(boundScale > 0) || !(confidence > 0 && confidence < 1)) throw Error('无效的区间输入');
  const radius = Math.sqrt(.5 * Math.log(2 / (1 - confidence)) * boundScale);
  return [Math.max(0, rate - radius), Math.min(1, rate + radius)];
}
export function combineResults(results, weights = results.map(() => 1)) {
  if (!results.length || weights.length !== results.length || weights.some(w => !Number.isFinite(w) || w <= 0)) throw Error('合并结果需要非空样本和正权重');
  const total = weights.reduce((a,b) => a+b,0), ws=weights.map(w=>w/total);
  if(results.some(r=>!r.n || !Number.isFinite(r.rate) || !(r.boundScale>0)))throw Error('结果缺少独立配对统计，请重新模拟');
  const avg = getter => results.reduce((v,r,i)=>v+ws[i]*getter(r),0);
  const rate=Math.max(0,Math.min(1,avg(r=>r.rate))),boundScale=results.reduce((v,r,i)=>v+ws[i]**2*r.boundScale,0);
  const interval=pairedInterval(rate,boundScale);
  return {rate,score:rate*100,interval,scoreInterval:interval.map(x=>x*100),boundScale,
    intervalMethod:'95% paired bounded-score Hoeffding; fixed opponent pool; model error excluded',
    n:results.reduce((v,r)=>v+r.n,0),pairs:results.reduce((v,r)=>v+r.pairs,0),
    wins:results.reduce((v,r)=>v+r.wins,0),draws:results.reduce((v,r)=>v+r.draws,0),caps:results.reduce((v,r)=>v+r.caps,0),
    winRate:avg(r=>r.winRate),drawRate:avg(r=>r.drawRate),rounds:avg(r=>r.rounds),
    metrics:Object.fromEntries(METRICS.map(k=>[k,avg(r=>r.metrics[k]||0)])),
    byHero:Object.fromEntries([...new Set(results.flatMap(r=>Object.keys(r.byHero||{})))].map(id=>[id,Object.fromEntries(METRICS.map(k=>[k,avg(r=>r.byHero?.[id]?.[k]||0)]))]))};
}
export function styleSummary(rows) {
  const groups = new Map();
  for(const row of rows){const a=groups.get(row.style)||[];a.push(row);groups.set(row.style,a);}
  const styles=[...groups].map(([style,rs])=>({style,result:combineResults(rs.map(r=>r.result),rs.map(r=>r.weight))}));
  const values=styles.map(x=>x.result.score), range=[Math.min(...values),Math.max(...values)];
  const available=styles.length>=2;
  return {styles,range:available?range:null,stability:available?100-(range[1]-range[0]):null,
    definition:'稳定性=100−各对手风格平均分的极差；高稳定性不代表高强度',styleCount:styles.length};
}
// FNV-style avalanche, with explicit namespace separation. Same A/B seed supports paired ablations.
export function sampleSeed(namespace, opponent, pair) {
  let h=2166136261;
  for(const s of [namespace,opponent,pair]){const text=String(s);for(let i=0;i<text.length;i++)h=Math.imul(h^text.charCodeAt(i),16777619);h=Math.imul(h^255,16777619);}
  h^=h>>>16;h=Math.imul(h,0x7feb352d);h^=h>>>15;h=Math.imul(h,0x846ca68b);return (h^(h>>>16))>>>0 || 1;
}
