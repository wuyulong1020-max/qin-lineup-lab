
import {DB,H,teamTraits} from './engine.js?v=v4.0.2-20261128013410';

export const FACTION_STYLES=Object.freeze(['阴阳','纵横','农家','帝国','白墨','儒家']);
const SHORT={mo:'墨门',chu:'兵家',yin:'阴阳',di:'帝国',nong:'农家',bai:'百家'};
const NUM=['零','一','二','三','四','五','六','七','八','九'];
const recipes={
 '阴阳':{faction:'yin',combos:['c01','c02']},'纵横':{combos:['c04']},
 '农家':{faction:'nong',combos:['c19','c12']},'帝国':{faction:'di',combos:['c13']},
 '白墨':{combos:['c06']},'儒家':{combos:['c09']}
};
export function styleMechanism(style,team){
 const p=recipes[style],allowed=teamTraits(team).combos;
 return {faction:p.faction,combo:p.combos.find(id=>allowed.includes(id))};
}
export function factionProfile(team){
 const ids=new Set(team.active.map(u=>u.id)),active={};
 for(const id of ids)active[H[id].faction]=(active[H[id].faction]||0)+1;
 const traits=teamTraits(team);
 const tiers=Object.fromEntries(DB.factions.map(f=>[f.id,f.tiers.filter(t=>t.count<=traits.factions[f.id]).at(-1)?.count||0]));
 const qualifies=[
  (active.yin||0)>=4,ids.has('h06')&&ids.has('h07'),(active.nong||0)>=4,
  ids.has('h23')&&ids.has('h27')&&(active.di||0)>=3,ids.has('h11')&&ids.has('h25')&&tiers.chu>=4,['h15','h16','h18'].every(id=>ids.has(id))
 ];
 const styles=FACTION_STYLES.filter((_,i)=>qualifies[i]);
 return {styles,active,tiers,labels:Object.entries(tiers).filter(([,v])=>v).sort((a,b)=>b[1]-a[1])
  .map(([k,v])=>NUM[v]+SHORT[k]),combos:traits.combos};
}
export function primaryStyle(profile){
 const {active,styles}=profile;
 const value={'阴阳':(active.yin||0)*2,'纵横':8,'农家':(active.nong||0)*2,'帝国':(active.di||0)*2+3,'白墨':8,'儒家':10};
 return styles.slice().sort((a,b)=>value[b]-value[a])[0]||null;
}
export function factionTitle(profile,oldStyle){
 const combo=DB.combos.find(c=>profile.combos.includes(c.id)&&c.memberIds.filter(id=>H[id].rarity==='legendary').length>1);
 return [...profile.labels.slice(0,2),combo?.name,oldStyle].filter(Boolean).join(' · ');
}


export function styleGroupNames(profile,withTotals=true){
 const {active,tiers,styles}=profile;
 const labels={'阴阳':active.yin>=7?'7阴阳':'4阴阳','纵横':tiers.bai>=5?'5百家':'2百家',
  '农家':active.nong>=7?'7农家':active.nong<=5?'半农家':null,'帝国':active.di>=5?'5帝国':'3帝国',
  '白墨':'白墨兵家','儒家':tiers.bai>=5?'儒家百家':'3儒家'};
 return styles.flatMap(style=>[
  ...(withTotals&&style!=='白墨'?[[style,style+'总和']]:[]),
  ...(labels[style]?[[style,labels[style]]]:[])
 ]);
}
