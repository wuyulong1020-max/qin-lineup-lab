import {DB,H,teamTraits} from './engine.js?v=v3.4.6-20261121010843';

export const FACTION_STYLES=Object.freeze(['七阴阳阵','四阴混编','五帝国阵','五百四兵','农家混编','七农纯队']);
const SHORT={mo:'墨门',chu:'兵家',yin:'阴阳',di:'帝国',nong:'农家',bai:'百家'};
const NUM=['零','一','二','三','四','五','六','七','八','九'];
export function factionProfile(team){
 const active={};
 for(const {id} of team.active)active[H[id].faction]=(active[H[id].faction]||0)+1;
 const traits=teamTraits(team);
 const n=Object.fromEntries(DB.factions.map(f=>[f.id,f.tiers.filter(t=>t.count<=traits.factions[f.id]).at(-1)?.count||0]));
 const a=key=>active[key]||0;
 const styles=[];
 if(n.yin===7&&a('yin')>=5)styles.push(FACTION_STYLES[0]);
 if(n.yin===4&&a('yin')>=3)styles.push(FACTION_STYLES[1]);
 if(n.di===5&&a('di')>=4)styles.push(FACTION_STYLES[2]);
 if(n.bai===5&&n.chu===4&&a('bai')>=3&&a('chu')>=2)styles.push(FACTION_STYLES[3]);
 if(n.nong>=4&&n.nong<7&&a('nong')>=3)styles.push(FACTION_STYLES[4]);
 if(a('nong')>=7)styles.push(FACTION_STYLES[5]);
 return {styles,active,tiers:n,labels:Object.entries(n).filter(([,v])=>v).sort((l,r)=>r[1]-l[1]).map(([key,count])=>NUM[count]+SHORT[key]),combos:traits.combos};
}

export function primaryStyle(profile){
 const a=profile.active;
 const values=[(a.yin||0)*2+2,(a.yin||0)*2,(a.di||0)*2+1,(a.bai||0)+(a.chu||0)+1,(a.nong||0)*2,30];
 return profile.styles.slice().sort((l,r)=>values[FACTION_STYLES.indexOf(r)]-values[FACTION_STYLES.indexOf(l)])[0]||null;
}

export function factionTitle(profile,oldStyle){
 const combo=DB.combos.find(c=>profile.combos.includes(c.id)&&c.memberIds.filter(id=>H[id].rarity==='legendary').length>1);
 return [...profile.labels.slice(0,2),combo?.name,oldStyle].filter(Boolean).join(' · ');
}
