import {selectedAccount, currentFormation} from './profiles.js';
export const STAGES = ['2', '10', '20', '10+2', '20+2', '20+10', 'total'];
export const TOTAL_WEIGHTS = {2: .2, 10: .4, 20: .4};
export const EVOLUTION_STARS = [2, 10, 20];
const personalPages = new Set(['home','team','growth','path','compare']);
export function environmentKey(page, scope, accountId) {
  return `${page}|${scope === 'current' ? 'current' : 'all'}|${accountId ?? 'public'}`;
}
export function resolveEnvironment(store, catalog, {page, scope = 'all'} = {}) {
  const formation = currentFormation(store, catalog);
  if (page === 'insights' && scope === 'current' && !formation?.usable) scope = 'all';
  const account = selectedAccount(store), personal = personalPages.has(page) || page === 'insights' && scope === 'current';
  const hasPool = !!account?.pool.length;
  const canUseActual = personal && hasPool;
  const key = environmentKey(page, scope, personal ? account?.id : null);
  const saved = store.environments[key];
  const stage = saved && (STAGES.includes(saved.stage) || saved.stage === 'actual' && canUseActual) ? saved.stage : canUseActual ? 'actual' : '20';
  return {
    key, stage, mechCount: saved?.mechCount ?? (canUseActual ? account.mechCount : 4),
    mode: stage === 'actual' ? 'actual' : 'theory',
    poolSource: hasPool && personal ? 'owned' : 'all',
    scope: page === 'insights' && scope === 'current' && !formation?.usable ? 'all' : scope,
    needsStartingTeam: ['growth','path','compare'].includes(page) && !formation?.usable,
    notice: !hasPool && personal ? '全环境参考，未导入个人资源' : stage === 'actual' ? '按英雄池实际星级' : hasPool && personal ? '自有英雄池的培养规划，不改变存档' : '全环境理论比较'
  };
}
export function rememberEnvironment(store, context, value, catalog) {
  const e = resolveEnvironment(store, catalog, context);
  if ((!STAGES.includes(value.stage) && !(value.stage === 'actual' && e.poolSource === 'owned')) || ![2,3,4].includes(value.mechCount)) throw Error('环境参数无效。');
  const next = structuredClone(store); next.environments[e.key] = {stage: value.stage, mechCount: value.mechCount}; return next;
}
export function effectivePool(store, catalog, environment, cores = []) {
  const account = selectedAccount(store);
  const pool = environment.poolSource === 'owned' && account ? account.pool : catalog.heroes.map(h => ({id: h.id, star: 0}));
  if (environment.stage === 'actual') return structuredClone(pool);
  if (environment.stage === 'total') throw Error('总榜需分别计算2、10、20星后加权，不能当成单场环境。');
  const mixed = environment.stage.includes('+');
  if (mixed && (!cores.length || cores.length > 3 || new Set(cores).size !== cores.length || cores.some(id => !pool.some(x => x.id === id) || catalog.heroes.find(h => h.id === id)?.rarity !== 'legendary'))) throw Error('混合培养需要1—3名有效传说核心。');
  const [high, low] = environment.stage.split('+').map(Number), coreSet = new Set(cores);
  return pool.map(x => ({id: x.id, star: catalog.heroes.find(h => h.id === x.id).rarity === 'epic' ? x.star : mixed ? coreSet.has(x.id) ? high : low : high}));
}
