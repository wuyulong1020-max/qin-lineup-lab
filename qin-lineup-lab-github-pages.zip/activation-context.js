// Author-side B selector. No combat changes. Feature output is shared with training.
export function setupFeatures(db){
 const H=Object.fromEntries(db.heroes.map(h=>[h.id,h])),effects=[...db.combos.map(x=>x.id),...db.factions.flatMap(f=>f.tiers.map(t=>f.id+'@'+t.count))];
 const labels=['bias','star2','star10','star20','slots2','slots3','slots4','frontDefense','backAttack','support','attack','defense','hp','speed','curse','counter','heal','control','shield','crit','area','farm','bai','yin','di','mo','chu','casters','casterAttack','casterPersonal','casterSpeed','casterFront'];
 const area=t=>/敌方全体|我方全体/.test(t)?9:/单排|前排全体/.test(t)?4:/6次/.test(t)?6:/4人/.test(t)?4:/3人|相邻/.test(t)?3:1;
 function context(team){const hs=team.active.map(u=>H[u.id]),star=team.active.reduce((s,u)=>s+u.star,0)/9,text=hs.map(h=>JSON.stringify([h.skill,h.evolutions,h.tags])).join(' '),count=re=>hs.filter(h=>re.test(JSON.stringify([h.skill,h.evolutions,h.tags]))).length/9;
  const mean=k=>hs.reduce((s,h)=>s+h.stats[k],0)/9;
  return [1,star<6?1:0,star>=6&&star<15?1:0,star>=15?1:0,...[2,3,4].map(n=>team.mechs.length===n?1:0),hs.slice(0,4).filter(h=>h.role==='defense').length/4,hs.slice(4).filter(h=>h.role==='attack').length/5,hs.filter(h=>h.role==='support').length/9,mean('atk')/250,mean('def')/100,mean('hp')/1000,mean('speed')/550,count(/诅咒/),count(/反击/),count(/治疗|恢复|回复/),count(/眩晕|冰冻|禁锢|失魂|魅惑|禁疗/),count(/护盾|抵抗/),count(/暴击|暴伤/),count(/全体|单排|三行|链状/),hs.filter(h=>h.faction==='nong').length/9,...['bai','yin','di','mo','chu'].map(f=>hs.filter(h=>h.faction===f).length/9),0,0,0,0,0];
 }
 function features(team,state){const base=context(team),present=new Set([...state.combos,...state.factions]),out=new Array(effects.length*labels.length).fill(0);
  for(let i=0;i<effects.length;i++){const id=effects[i];if(!present.has(id))continue;const v=base.slice(),c=db.combos.find(c=>c.id===id);if(c){const us=team.active.filter(u=>c.memberIds.includes(u.id));v[27]=us.length/3;v[28]=us.reduce((s,u)=>s+H[u.id].stats.atk*(1+u.star*.03),0)/1000;v[29]=us.reduce((s,u)=>{const h=H[u.id];return s+h.skill.chance*(h.skill.coefficient||0)*area(h.skill.target||'')},0)/10;v[30]=us.reduce((s,u)=>s+H[u.id].stats.speed,0)/1650;v[31]=us.filter(u=>team.active.findIndex(x=>x.id===u.id)<4).length/3;}for(let j=0;j<v.length;j++)out[i*labels.length+j]=v[j];}
  return out;
 }
 function prior(team,state){const hs=team.active.map(u=>H[u.id]),all=new Set([...team.active.map(u=>u.id),...state.mechs]);let value=0;
  for(const c of db.combos)if(state.combos.includes(c.id)){const casters=hs.filter(h=>c.memberIds.includes(h.id));if(c.trigger==='passive')continue;if(c.trigger==='ally_death'){value+=casters.length?2:1;continue;}value+=casters.reduce((s,h)=>s+c.chance*((c.coefficient||0)*area(c.target||'')*h.stats.atk/250-h.skill.chance*(h.skill.coefficient||0)*area(h.skill.target||'')),0);if(/真实伤害|护盾|解除|冰冻|眩晕|魅惑|禁锢/.test(c.text))value+=c.chance*casters.length*4;}
  const vals={'bai@2':1.7,'bai@5':3,'chu@2':.5,'chu@4':2,'yin@2':.6,'yin@4':.6,'yin@7':hs.filter(h=>/诅咒/.test(JSON.stringify(h))).length*.8,'mo@3':.7,'mo@4':.5,'mo@8':2.5,'di@3':.3,'di@5':hs.filter(h=>h.faction==='di').length*.35,'nong@4':.8,'nong@5':hs.filter(h=>h.faction==='nong').length*.13,'nong@7':hs.filter(h=>h.faction==='nong').length*.3};
  for(const f of state.factions)value+=vals[f]||0;return value;
 }
 // The learned model is additive over activated effects. Compute each effect's
 // context-dependent value once instead of rebuilding a 1088-vector per state.
 function effectWeights(team,coefficients){const base=context(team),out={};
  for(let i=0;i<effects.length;i++){const id=effects[i],v=base.slice(),c=db.combos.find(c=>c.id===id);if(c){const us=team.active.filter(u=>c.memberIds.includes(u.id));v[27]=us.length/3;v[28]=us.reduce((s,u)=>s+H[u.id].stats.atk*(1+u.star*.03),0)/1000;v[29]=us.reduce((s,u)=>{const h=H[u.id];return s+h.skill.chance*(h.skill.coefficient||0)*area(h.skill.target||'')},0)/10;v[30]=us.reduce((s,u)=>s+H[u.id].stats.speed,0)/1650;v[31]=us.filter(u=>team.active.findIndex(x=>x.id===u.id)<4).length/3;}out[id]=v.reduce((s,x,j)=>s+x*coefficients[i*labels.length+j],0);}return out;
 }
 return {effects,labels,features,prior,effectWeights,featureNames:effects.flatMap(e=>labels.map(l=>e+'/'+l))};
}
