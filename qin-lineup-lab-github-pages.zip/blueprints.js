import {DB,H,rng,teamTraits} from './engine.js?v=v3.3.0-20261109094509';
import {STYLES,teamFrom,environment} from './fixed-arena.js?v=v3.3.0-20261109094509';
export const TEMPLATES=[
 ['纵横三极',['h06','h04','h14','h12','h07','h02','h05','h08','h09'],1],
 ['纵横楚汉',['h06','h22','h27','h12','h07','h02','h32','h23','h38'],5],
 ['纵横天崩',['h06','h33','h26','h22','h07','h02','h38','h32','h36'],3],
 ['阴阳诅咒',['h01','h26','h20','h10','h02','h03','h08','h09','h19'],4],
 ['农家群攻',['h33','h37','h22','h34','h38','h32','h35','h36','h23'],1],
 ['反击续航',['h26','h06','h15','h22','h07','h12','h20','h29','h10'],3],
 ['疾速控制',['h27','h14','h23','h12','h11','h25','h30','h18','h17'],2],
 ['帝国禁锢',['h27','h28','h06','h22','h13','h23','h24','h07','h02'],2],
 ['儒道协同',['h15','h16','h06','h12','h07','h17','h18','h30','h29'],5],
 ['楚国速攻',['h21','h29','h26','h12','h11','h25','h30','h31','h17'],0],
 ['墨家冰控',['h04','h14','h06','h22','h05','h07','h02','h12','h18'],2],
 ['后排点杀',['h06','h20','h22','h26','h13','h19','h18','h25','h38'],0]
].map(([name,ids,t])=>({name,ids,theme:STYLES[t]}));
export function heroStyleScores(h){const t=JSON.stringify([h.skill,h.evolutions,h.tags]),scores=[.1,.1,.1,.1,.1,.1];if(/暴击|斩杀|攻击力最高/.test(t))scores[0]+=2;if(/全体|单排|链状|相邻/.test(t))scores[1]+=2;if(/眩晕|冰冻|禁锢|失魂|魅惑/.test(t))scores[2]+=2;if(/反击/.test(t))scores[3]+=3;if(/诅咒|点燃|灼烧/.test(t))scores[4]+=3;if(/治疗|恢复|护盾|血量平均/.test(t))scores[5]+=2;return scores}
export function initialLayout(ids){const front=ids.slice().sort((a,b)=>(H[b].stats.hp+H[b].stats.def*5+(H[b].role==='defense'?450:0))-(H[a].stats.hp+H[a].stats.def*5+(H[a].role==='defense'?450:0))||a.localeCompare(b)).slice(0,4);return [...front,...ids.filter(id=>!front.includes(id)).sort((a,b)=>H[b].stats.speed-H[a].stats.speed||a.localeCompare(b))]}
export function generateBlueprints(systems=[],amount=5000,seed=20261019){
 const random=rng(seed),L=DB.heroes.filter(h=>h.rarity==='legendary'),out=[],seen=new Set();
 const add=(ids,name,theme,system=false,preserve=false)=>{ids=ids.filter(id=>H[id]?.rarity==='legendary');if(ids.length!==9||new Set(ids).size!==9)return false;const key=ids.slice().sort().join('.');if(seen.has(key))return false;seen.add(key);out.push({id:'b'+String(out.length+1).padStart(5,'0'),name,ids:preserve?ids:initialLayout(ids),theme,system});return true};
 systems.forEach((t,i)=>add([...t.front,...t.back],t.label,STYLES[[3,1,4,2,5][i]??i%6],true,true));
 TEMPLATES.forEach(t=>add(t.ids,t.name,t.theme,false,true));
 const pick=xs=>xs[Math.floor(random()*xs.length)];
 // Deliberate one-module variations give every hero and every combo an entry point.
 for(const h of L)for(let k=0;k<6;k++){const t=TEMPLATES[(k+L.indexOf(h))%TEMPLATES.length],ids=t.ids.slice();if(!ids.includes(h.id)){const pos=ids.findIndex(id=>H[id].role===h.role);ids[pos<0?k%9:pos]=h.id;}add(ids,t.name+'·'+h.name,STYLES[k])}
 for(const c of DB.combos)for(let k=0;k<12;k++){const req=c.memberIds.filter(id=>H[id].rarity==='legendary'),t=TEMPLATES[k%TEMPLATES.length],ids=[...req,...t.ids.filter(id=>!req.includes(id))].slice(0,9);while(ids.length<9){const h=pick(L.filter(h=>!ids.includes(h.id)));ids.push(h.id)}add(ids,c.name+'·候选',STYLES[k%6])}
 for(let tries=0;out.length<amount&&tries<amount*30;tries++){
  const style=tries%6;let ids=[];
  if(tries%3!==0){const c=DB.combos[tries%DB.combos.length];ids=c.memberIds.filter(id=>H[id].rarity==='legendary')}
  if(tries%4!==0){const base=TEMPLATES[(tries*7)%TEMPLATES.length];for(const id of base.ids)if(ids.length<4&&!ids.includes(id))ids.push(id)}
  for(const role of ['defense','support','attack'])if(!ids.some(id=>H[id].role===role)){const xs=L.filter(h=>!ids.includes(h.id)&&h.role===role);if(xs.length)ids.push(pick(xs).id)}
  while(ids.length<9){const xs=L.filter(h=>!ids.includes(h.id)),scores=xs.map(h=>1+heroStyleScores(h)[style]),sum=scores.reduce((a,b)=>a+b,0);let x=random()*sum,index=0;for(;index<scores.length-1&&x>scores[index];index++)x-=scores[index];ids.push(xs[index].id)}
  add(ids,'探索阵容',STYLES[style]);
 }
 if(out.length<amount)throw Error('候选蓝图不足');return out.slice(0,amount);
}
export function discoveryCandidates(blueprints,count=360){
 const selected=blueprints.filter(b=>b.system),used=new Set(selected.map(b=>b.id)),counts=Object.fromEntries(DB.heroes.filter(h=>h.rarity==='legendary').map(h=>[h.id,0]));selected.forEach(b=>b.ids.forEach(id=>counts[id]++));
 const quota=count/6;
 while(selected.length<count){let best=null,bestScore=-Infinity;for(const b of blueprints){if(used.has(b.id)||selected.filter(x=>x.theme===b.theme).length>=quota)continue;const benefit=b.ids.reduce((s,id)=>s+Math.max(0,65-counts[id])**1.5,0)+(b.system?10000:0);if(benefit>bestScore){best=b;bestScore=benefit}}
  if(!best)throw Error('母池发现候选不能满足主题配额');selected.push(best);used.add(best.id);best.ids.forEach(id=>counts[id]++);
 }return selected;
}
export function selectMother(discoveries,{size=120}={}){
 const selected=[],used=new Set(),counts=Object.fromEntries(DB.heroes.filter(h=>h.rarity==='legendary').map(h=>[h.id,0])),comboCounts=Object.fromEntries(DB.combos.map(c=>[c.id,0]));
 const info=new Map(discoveries.map(b=>{const traits=teamTraits(teamFrom(b.ids,environment(20,4)));return [b.id,traits]}));
 const groups=[];for(const theme of STYLES){const rows=discoveries.filter(b=>b.theme===theme).sort((a,b)=>b.result.score-a.result.score);for(const [band,lo,hi,quota]of [['strong',0,.3,6],['middle',.3,.8,10],['exploration',.8,1,4]]){const xs=rows.slice(Math.floor(rows.length*lo),Math.floor(rows.length*hi)).map(b=>({...b,band}));groups.push({theme,band,quota:quota*size/120,rows:xs})}}
 const add=b=>{selected.push(b);used.add(b.id);b.ids.forEach(id=>counts[id]++);info.get(b.id).combos.forEach(id=>comboCounts[id]++)};
 for(const g of groups)for(const b of g.rows.filter(b=>b.system))add(b);
 for(let turn=0;selected.length<size;turn++){
  const candidates=groups.filter(g=>selected.filter(b=>b.theme===g.theme&&b.band===g.band).length<g.quota);
  if(!candidates.length)break;let winner=null,score=-Infinity;
  for(const g of candidates)for(const b of g.rows){if(used.has(b.id))continue;const coverage=b.ids.reduce((s,id)=>s+Math.max(0,20-counts[id])**2,0),combo=info.get(b.id).combos.reduce((s,id)=>s+Math.max(0,6-comboCounts[id])*30,0),value=coverage+combo+(b.result.score||0)*.01;if(value>score){score=value;winner=b}}
  if(!winner)throw Error('母池分层选择不足');add(winner);
 }
 // Improve rare hero coverage without changing theme/strength quotas or deleting system teams.
 for(let pass=0;pass<100;pass++){
  const before=Object.values(counts).reduce((s,n)=>s+Math.max(0,20-n)**2,0);if(before===0)break;let change=null,best=0;
  for(let i=0;i<selected.length;i++){const old=selected[i];if(old.system)continue;const group=groups.find(g=>g.theme===old.theme&&g.band===old.band);for(const b of group.rows){if(used.has(b.id))continue;const after=Object.entries(counts).reduce((s,[id,n])=>s+Math.max(0,20-(n-(old.ids.includes(id)?1:0)+(b.ids.includes(id)?1:0)))**2,0);if(before-after>best){best=before-after;change={i,old,b}}}}
  if(!change)break;const {i,old,b}=change;used.delete(old.id);used.add(b.id);old.ids.forEach(id=>counts[id]--);b.ids.forEach(id=>counts[id]++);selected[i]=b;
 }
 return selected.map((b,i)=>({id:'p'+String(i+1).padStart(3,'0'),origin:b.id,name:b.name,ids:b.ids,theme:b.theme,band:b.band,system:b.system,discoveryScore:b.result.score,mechs:Object.fromEntries([2,3,4].map(n=>[n,teamFrom(b.ids,environment(20,n)).mechs.map(x=>x.id)]))}));
}
export function coverageAudit(mother){const counts=Object.fromEntries(DB.heroes.filter(h=>h.rarity==='legendary').map(h=>[h.id,0]));mother.forEach(b=>b.ids.forEach(id=>counts[id]++));return {size:mother.length,heroes:counts,minimumHeroAppearances:Math.min(...Object.values(counts)),heroDeficits:Object.entries(counts).filter(([id,n])=>n<20).map(([id,n])=>({id,name:H[id].name,count:n})),themes:Object.fromEntries(STYLES.map(s=>[s,mother.filter(b=>b.theme===s).length])),strength:Object.fromEntries(['strong','middle','exploration'].map(s=>[s,mother.filter(b=>b.band===s).length])),systemTeams:mother.filter(b=>b.system).map(b=>b.name),comboCoverage:Object.fromEntries([2,3,4].map(n=>[n,Object.fromEntries(DB.combos.map(c=>[c.id,mother.filter(b=>teamTraits(teamFrom(b.ids,environment(20,n),{mechs:b.mechs[n]})).combos.includes(c.id)).length]))]))}}
