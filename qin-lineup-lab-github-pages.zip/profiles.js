// Browser-local account data. Pure transformations never mutate a caller's save.
export const STORAGE_KEY = 'qin-lab-v2';
export const LEGACY_KEY = 'qin-lab-v1';
export const SCHEMA_VERSION = 2;
const clone = x => structuredClone(x);
const fail = message => { throw new Error(message); };
const nameOf = (s, fallback) => typeof s === 'string' && s.trim() ? s.trim().slice(0, 80) : fallback;
const uid = () => globalThis.crypto.randomUUID();
const isObject = x => x !== null && typeof x === 'object' && !Array.isArray(x);
const countOf = n => [2, 3, 4].includes(n) ? n : fail('机师人数必须为2、3或4。');
export function emptyStore() {
  return {schemaVersion: SCHEMA_VERSION, accounts: [], selectedAccountId: null, environments: {}, migration: null};
}
function heroMap(catalog) { return new Map(catalog.heroes.map(h => [h.id, h])); }
function units(input, catalog, {active = false} = {}) {
  if (!Array.isArray(input) || input.length > catalog.heroes.length) fail('弟子列表格式错误。');
  const heroes = heroMap(catalog), seen = new Set();
  return input.map(x => {
    if (!isObject(x) || !heroes.has(x.id) || seen.has(x.id)) fail('弟子不存在或重复。');
    const h = heroes.get(x.id);
    if (active && h.rarity !== 'legendary') fail('史诗弟子只能担任机师。');
    if (!Number.isInteger(x.star) || x.star < 0 || x.star > 20) fail('星级必须是0—20的整数。');
    seen.add(x.id);
    return {id: x.id, star: x.star};
  });
}
export function normalizeTeam(team, catalog, count) {
  if (!isObject(team)) fail('阵容格式错误。');
  const active = units(team.active, catalog, {active: true}), mechs = units(team.mechs, catalog);
  if (active.length !== 9 || mechs.length !== countOf(count)) fail('阵容需要9名上阵弟子和对应数量的机师。');
  if (new Set([...active, ...mechs].map(x => x.id)).size !== 9 + count) fail('上阵弟子和机师不能重复。');
  const core = team.core ?? [];
  if (!Array.isArray(core) || core.length > 3 || new Set(core).size !== core.length || core.some(id => !active.some(x => x.id === id))) fail('核心必须是最多3名不同的上阵弟子。');
  return {name: nameOf(team.name, '未命名阵容'), active, mechs, core: [...core]};
}
function lockedIds(ids, pool, catalog) {
  const heroes = heroMap(catalog);
  if (!Array.isArray(ids) || ids.length > 3 || new Set(ids).size !== ids.length || ids.some(id => !pool.some(x => x.id === id) || heroes.get(id)?.rarity !== 'legendary')) fail('请选择英雄池中的1—3名传说核心，或留空自动推荐。');
  return [...ids];
}
export function addAccount(store, {name, pool = [], mechCount = 4, locked = []}, catalog) {
  const next = clone(store), cleanPool = units(pool, catalog);
  const a = {id: uid(), name: nameOf(name, '新账号'), pool: cleanPool, mechCount: countOf(mechCount), locked: lockedIds(locked, cleanPool, catalog), formations: [], currentFormationId: null};
  next.accounts.push(a); next.selectedAccountId = a.id; return next;
}
export function selectedAccount(store) { return store.accounts.find(a => a.id === store.selectedAccountId) ?? null; }
function accountAt(store, id) { return store.accounts.find(a => a.id === id) ?? fail('账号不存在。'); }
export function selectAccount(store, id) {
  accountAt(store, id); const next = clone(store); next.selectedAccountId = id; return next;
}
export function renameAccount(store, id, name) {
  const next = clone(store); accountAt(next, id).name = nameOf(name, '未命名账号'); return next;
}
export function deleteAccount(store, id) {
  accountAt(store, id); const next = clone(store); next.accounts = next.accounts.filter(a => a.id !== id);
  if (next.selectedAccountId === id) next.selectedAccountId = next.accounts[0]?.id ?? null;
  for (const key of Object.keys(next.environments)) if (key.endsWith('|' + id)) delete next.environments[key];
  return next;
}
export function updateAccount(store, id, patch, catalog) {
  const next = clone(store), a = accountAt(next, id);
  if (patch.pool !== undefined) a.pool = units(patch.pool, catalog);
  if (patch.mechCount !== undefined) a.mechCount = countOf(patch.mechCount);
  a.locked = lockedIds(patch.locked ?? a.locked.filter(id => a.pool.some(x => x.id === id)), a.pool, catalog);
  // Saved formations are snapshots: editing a pool never silently deletes or upgrades them.
  return next;
}
export function saveFormation(store, accountId, {id, name, team, source = 'personal'}, catalog) {
  const next = clone(store), a = accountAt(next, accountId);
  if (!['personal', 'reference'].includes(source)) fail('阵容来源无效。');
  const clean = normalizeTeam(team, catalog, team.mechs?.length);
  if (source === 'personal') {
    if (clean.mechs.length !== a.mechCount) fail('机师数与账号解锁数不一致。');
    for (const x of [...clean.active, ...clean.mechs]) {
      const own = a.pool.find(p => p.id === x.id);
      if (!own || own.star !== x.star) fail('个人阵容必须使用英雄池中的实际星级；参考队请另存为规划阵容。');
    }
  }
  const existing = id ? a.formations.findIndex(f => f.id === id) : -1;
  if (id && existing < 0) fail('待更新阵容不存在。');
  const record = {id: id ?? uid(), name: nameOf(name, clean.name), source, team: clean};
  record.team.name = record.name;
  if (existing >= 0) a.formations[existing] = record; else a.formations.push(record);
  a.currentFormationId = record.id; return next;
}
export function selectFormation(store, accountId, id) {
  const next = clone(store), a = accountAt(next, accountId);
  if (!a.formations.some(f => f.id === id)) fail('阵容不存在。'); a.currentFormationId = id; return next;
}
export function renameFormation(store, accountId, id, name) {
  const next = clone(store), f = accountAt(next, accountId).formations.find(f => f.id === id);
  if (!f) fail('阵容不存在。'); f.name = nameOf(name, '未命名阵容'); f.team.name = f.name; return next;
}
export function deleteFormation(store, accountId, id) {
  const next = clone(store), a = accountAt(next, accountId);
  if (!a.formations.some(f => f.id === id)) fail('阵容不存在。');
  a.formations = a.formations.filter(f => f.id !== id);
  if (a.currentFormationId === id) a.currentFormationId = a.formations[0]?.id ?? null; return next;
}
export function currentFormation(store, catalog) {
  const a = selectedAccount(store), f = a?.formations.find(f => f.id === a.currentFormationId);
  if (!f) return null;
  const team = clone(f.team);
  if (f.source === 'reference') return {formation: clone(f), team, usable: true, reason: '规划参考阵容'};
  if (team.mechs.length !== a.mechCount) return {formation: clone(f), team, usable: false, reason: '请调整机师数'};
  const owned = new Map(a.pool.map(x => [x.id, x]));
  if ([...team.active, ...team.mechs].some(x => !owned.has(x.id))) return {formation: clone(f), team, usable: false, reason: '部分弟子已不在英雄池中'};
  // Analysis reads current owned stars, while retaining the original snapshot for export.
  team.active = team.active.map(x => ({...owned.get(x.id)})); team.mechs = team.mechs.map(x => ({...owned.get(x.id)}));
  return {formation: clone(f), team: normalizeTeam(team, catalog, a.mechCount), usable: true, reason: '按英雄池实际星级'};
}
export function validateStore(input, catalog) {
  if (!isObject(input) || input.schemaVersion !== SCHEMA_VERSION || !Array.isArray(input.accounts) || input.accounts.length > 100) fail('存档格式或版本不支持。');
  const out = emptyStore(), ids = new Set();
  for (const raw of input.accounts) {
    if (!isObject(raw) || typeof raw.id !== 'string' || !raw.id || raw.id.length > 100 || ids.has(raw.id)) fail('账号标识重复或无效。');
    ids.add(raw.id);
    const pool = units(raw.pool, catalog), mechCount = countOf(raw.mechCount);
    if (!Array.isArray(raw.formations) || raw.formations.length > 500) fail('保存阵容数量或格式无效。');
    const seen = new Set(), formations = raw.formations.map(f => {
      if (!isObject(f) || typeof f.id !== 'string' || !f.id || f.id.length > 100 || seen.has(f.id) || !['personal', 'reference'].includes(f.source)) fail('阵容标识或来源无效。');
      seen.add(f.id); const team = normalizeTeam(f.team, catalog, f.team?.mechs?.length);
      const name = nameOf(f.name, team.name); team.name = name;
      return {id: f.id, name, source: f.source, team};
    });
    if (raw.currentFormationId !== null && !seen.has(raw.currentFormationId)) fail('当前阵容标识无效。');
    out.accounts.push({id: raw.id, name: nameOf(raw.name, '未命名账号'), pool, mechCount, locked: lockedIds(raw.locked ?? [], pool, catalog), formations, currentFormationId: raw.currentFormationId});
  }
  if (input.selectedAccountId !== null && !ids.has(input.selectedAccountId)) fail('当前账号标识无效。');
  out.selectedAccountId = input.selectedAccountId;
  // Environment data is validated separately; do not spread arbitrary imported object keys.
  if (isObject(input.environments)) for (const [k, v] of Object.entries(input.environments)) {
    if (k.length < 160 && !['__proto__', 'constructor', 'prototype'].includes(k) && isObject(v) && ['actual','2','10','20','10+2','20+2','20+10','total'].includes(v.stage) && [2,3,4].includes(v.mechCount)) out.environments[k] = {stage: v.stage, mechCount: v.mechCount};
  }
  out.migration = input.migration === 'qin-lab-v1' ? input.migration : null;
  return out;
}
export function exportStore(store, catalog) { return JSON.stringify(validateStore(store, catalog)); }
export function importStore(text, catalog) {
  if (typeof text !== 'string' || text.length > 5_000_000) fail('导入文件过大或不是文本。');
  return validateStore(JSON.parse(text), catalog);
}
export function migrateLegacy(legacy, catalog) {
  if (!isObject(legacy)) fail('旧存档格式错误。');
  let next = addAccount(emptyStore(), {name: '原有账号', pool: legacy.pool ?? [], mechCount: legacy.count ?? 2}, catalog);
  const a = selectedAccount(next), warnings = [];
  const validLocks = (Array.isArray(legacy.locked) ? [...new Set(legacy.locked)] : []).filter(id => a.pool.some(x => x.id === id) && heroMap(catalog).get(id)?.rarity === 'legendary');
  a.locked = validLocks.slice(0, 3);
  if (validLocks.length > 3) warnings.push('原有锁定超过3人，已保留前3名；旧存档原件仍保留。');
  for (const team of [...(Array.isArray(legacy.saved) ? legacy.saved : []), ...(legacy.team ? [legacy.team] : [])]) {
    try {
      const clean = normalizeTeam(team, catalog, team?.mechs?.length);
      const personal = clean.mechs.length === a.mechCount && [...clean.active, ...clean.mechs].every(x => a.pool.some(p => p.id === x.id && p.star === x.star));
      next = saveFormation(next, a.id, {team: clean, source: personal ? 'personal' : 'reference'}, catalog);
    } catch (e) { warnings.push('未转换一套异常旧阵容：' + e.message); }
  }
  next.migration = LEGACY_KEY; return {store: next, warnings};
}
export function loadStore(storage, catalog) {
  // On invalid data/storage failures, return a recoverable error and never overwrite the source.
  try {
    const current = storage.getItem(STORAGE_KEY);
    if (current !== null) return {store: importStore(current, catalog), warnings: [], error: null, needsSave: false};
    const legacy = storage.getItem(LEGACY_KEY);
    if (legacy !== null) return {...migrateLegacy(JSON.parse(legacy), catalog), error: null, needsSave: true};
    return {store: emptyStore(), warnings: [], error: null, needsSave: false};
  } catch (e) { return {store: null, warnings: [], error: e.message, needsSave: false}; }
}
export function persistStore(storage, store, catalog) {
  try { storage.setItem(STORAGE_KEY, exportStore(store, catalog)); return {ok: true}; }
  catch (e) { return {ok: false, error: e.message}; }
}
