import {DB,H,teamTraits} from './engine.js?v=v3.4.1-20261110110654';

// Grouping is a display operation. Callers must filter the original library first.
export const TEAM_FAMILY_VERSION='direct-representative-tactics-20261110-v1';
export const TEAM_TIER_QUANTILES=Object.freeze([.01,.03,.07,.14,.25,.40,.57,.73,.86,.95]);
export const activeRosterKey=team=>(team?.active||[]).map(x=>x.id).sort().join('.');
const idsOf=row=>row.team.active.map(x=>x.id);
const coreOf=row=>(row.core||[]).map(x=>typeof x==='string'?x:x.id).sort();
const equal=(a,b)=>a.length===b.length&&a.every((x,i)=>x===b[i]);
const styles=['爆发速攻','群攻压血','控制压制','反击制胜','持续消耗','奶盾续航'];
function nearStyleTie(a,b){const ai=styles.indexOf(a.style),bi=styles.indexOf(b.style);if(ai<0||bi<0)return false;return [a,b].every(r=>{const ps=r.styleBasis?.percentiles;if(!ps||ps.length!==6)return false;return Math.max(...ps)-Math.min(ps[ai],ps[bi])<=.08;});}
let currentDB=null,cache=new WeakMap();
function tactics(row){
 if(currentDB!==DB){currentDB=DB;cache=new WeakMap();}if(cache.has(row))return cache.get(row);
 const traits=teamTraits(row.team),active=new Set(idsOf(row)),core=coreOf(row),keyTiers={mo:6,chu:4,yin:7,di:5,nong:7,bai:5};
 // A single non-core caster unlocked by a mechanist is a secondary route.
 // Preserve full multi-active modules and the combinations carried by a core.
 const combos=traits.combos.filter(id=>{const c=DB.combos.find(c=>c.id===id),cast=c.memberIds.filter(id=>active.has(id));return cast.length>=2||cast.some(id=>core.includes(id));}).sort();
 const t={style:row.style||row.styleBasis?.name||'',combos,
  factions:DB.factions.filter(f=>traits.factions[f.id]>=keyTiers[f.id]).map(f=>f.id+'@'+keyTiers[f.id]).sort(),core};cache.set(row,t);return t;
}
export function sameTeamFamily(a,b){
 const ai=idsOf(a),bi=new Set(idsOf(b)),overlap=ai.filter(id=>bi.has(id)).length;
 if(overlap===9)return true;
 if(overlap<7)return false;
 const x=tactics(a),y=tactics(b);
 if(!equal(x.combos,y.combos)||!equal(x.factions,y.factions))return false;
 // Seven-person overlap needs the same named drivers as well as the same
 // activated combinations and major faction tier. No transitive closure is used.
 const shared=x.core.filter(id=>y.core.includes(id)).length;
 if(overlap===7)return x.style===y.style&&equal(x.core,y.core);
 if(x.style!==y.style)return x.core.length>0&&equal(x.core,y.core)&&nearStyleTie(a,b);
 return shared>0||(!x.core.length&&!y.core.length);
}
export function teamFamilyName(row){
 const t=tactics(row),combos=t.combos.map(id=>DB.combos.find(c=>c.id===id)?.name).filter(Boolean);
 const cores=coreOf(row).map(id=>H[id]?.name).filter(Boolean).slice(0,2);
 const faction=t.factions.map(k=>{const [id,n]=k.split('@');return n+(DB.factions.find(f=>f.id===id)?.shortName||id)}).join('·');
 return [t.style||'综合搭配',combos.slice(0,2).join('＋')||cores.join('·'),faction].filter(Boolean).join(' · ');
}
export function groupTeamFamilies(rows,{metric='score'}={}){
 const value=typeof metric==='function'?metric:metric==='stability'?r=>r.result.adaptation?.stability||0:r=>r.result.score;
 const sorted=rows.slice().sort((a,b)=>value(b)-value(a)||b.result.score-a.result.score||activeRosterKey(a.team).localeCompare(activeRosterKey(b.team))||String(a.id||'').localeCompare(String(b.id||'')));
 const families=[];
 for(const row of sorted){const group=families.find(f=>sameTeamFamily(row,f));if(group)group.variants.push(row);else families.push({...row,variants:[],familyKey:activeRosterKey(row.team),familyName:teamFamilyName(row)});}
 const names=new Map();for(const f of families){f.familySize=f.variants.length+1;const xs=names.get(f.familyName)||[];xs.push(f);names.set(f.familyName,xs);}
 for(const [base,xs] of names){if(xs.length<2)continue;const frequency=new Map(),sets=new Map(xs.map(f=>[f,new Set(idsOf(f))]));for(const f of xs)for(const id of idsOf(f))frequency.set(id,(frequency.get(id)||0)+1);
  for(const f of xs){const ordered=idsOf(f).slice().sort((a,b)=>frequency.get(a)-frequency.get(b)||a.localeCompare(b));let branch=null;const choose=(n,start=0,prefix=[])=>{if(prefix.length===n)return xs.every(other=>other===f||prefix.some(id=>!sets.get(other).has(id)))?prefix:null;for(let i=start;i<=ordered.length-(n-prefix.length);i++){const found=choose(n,i+1,[...prefix,ordered[i]]);if(found)return found;}return null;};for(let n=1;n<=9&&!branch;n++)branch=choose(n);f.familyName=base+' · '+branch.map(id=>H[id]?.name||id).join('·');}
 }
 return families;
}
export function teamTierCuts(rows){
 const families=groupTeamFamilies(rows),scores=families.map(r=>r.result.score).sort((a,b)=>b-a);
 return TEAM_TIER_QUANTILES.map(q=>scores[Math.min(scores.length-1,Math.floor(scores.length*q))]??0);
}
