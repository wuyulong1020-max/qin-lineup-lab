// Independent, deterministic theoretical model. Screenshot coefficients are immutable.
import {emptyMetrics, METRICS, pairedInterval, sampleSeed} from './statistics.js?v=v3.1.1-20261106122355';
export const MODEL='QIN-3.3';
export const DEFAULT_LEVEL=250;
export const AWAKENING_SHIELD=11200;
const PRIMARY={attack:[.39,.10,.14],defense:[.10,.20,.45],support:[.25,.17,.30]};
const EARLY_PRIMARY={attack:[.16,.05,.05],defense:[.05,.05,.20],support:[.13,.06,.13]};
const SECONDARY={attack:{antiCrit:.04,critDamage:.22,skillReduce:.06,pierce:.11,resist:0},defense:{antiCrit:.12,critDamage:.14,skillReduce:.15,pierce:.03,resist:0},support:{antiCrit:.02,critDamage:.13,skillReduce:.14,pierce:.04,resist:.08}};
const LOW_OVERRIDES={attack:{pierce:.03},defense:{antiCrit:.04},support:{resist:0}};
const levelScale=.4*DEFAULT_LEVEL-19;
const NEGATIVE=new Set(['curse','weak','fragile','stun','freeze','slow','seal','confuse','charm','doom','burn','grudge','coldMark']);
const LOCKED=new Set(['grudge','armor','swordMomentum','tiger']);
export const isAwakeningEnvironment=team=>team.awakening===8;
export const PERSONAL_SKILL_MULTIPLIER=1.36;
export const INNER_RATIOS=Object.freeze({attack:.39,defense:.44,support:.41});
export const CULTIVATION_CRIT=Object.freeze({attack:.19,defense:.10,support:.11});
export const personalCoefficient=h=>h.skill.coefficient*PERSONAL_SKILL_MULTIPLIER;
export let DB, H, C;
export function configure(db){ DB=db; H=Object.fromEntries(db.heroes.map(h=>[h.id,h])); C=Object.fromEntries(db.combos.map(c=>[c.id,c])); }
export const starFactor=s=>1+.02*Math.min(s,5)+.03*Math.min(Math.max(s-5,0),5)+.04*Math.min(Math.max(s-10,0),5)+.05*Math.min(Math.max(s-15,0),5);
const teamStarRate=s=>s<=14?s*.001:s<=20?.016+(s-15)*.002:NaN;
export function rng(seed=1){let x=seed>>>0||1;return()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return (x>>>0)/4294967296;};}
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
export function validateTeam(team,mechCount=team.mechs.length){
 if(team.active.length!==9) throw Error('上阵必须为 9 名传说弟子');
 if(![2,3,4,5,6].includes(mechCount)||team.mechs.length!==mechCount) throw Error('机师必须恰好为所选的2—6人');
 const all=[...team.active,...team.mechs];if(new Set(all.map(x=>x.id)).size!==all.length)throw Error('弟子不能重复上阵或兼任机师');
 if(team.awakening!==undefined&&team.awakening!==0&&team.awakening!==8)throw Error('觉醒档无效');
 all.forEach(x=>{if(x.variant!==undefined&&(x.id!=='h31'||!['normal','live_bug'].includes(x.variant)))throw Error('英布版本无效');if(!H[x.id]||!Number.isInteger(x.star)||x.star<0||x.star>20)throw Error('英雄或星级无效');});
 if(team.active.some(x=>H[x.id].rarity!=='legendary'))throw Error('史诗弟子仅能担任机师'); return true;
}
export function teamTraits(team){const ids=new Set([...team.active,...team.mechs].map(x=>x.id));return {factions:Object.fromEntries(DB.factions.map(f=>[f.id,[...ids].filter(id=>H[id].faction===f.id).length])),combos:DB.combos.filter(c=>c.memberIds.every(id=>ids.has(id))&&c.memberIds.some(id=>team.active.some(h=>h.id===id))).map(c=>c.id)};}

// Chosen provisional defense function. This order is source-backed; exact formula is not official.
export function damageBeforeCritical({attack,defense,coefficient=1,extra=0,inner=0}){
 if(![attack,defense,coefficient,extra,inner].every(Number.isFinite)||coefficient<=0)throw Error('Invalid damage formula input');
 return Math.max(1,Math.max(0,attack-defense)*coefficient+extra-inner);
}

export class Combat{
 constructor(a,b,seed,options={}){
  this.rng=rng(seed);this.round=0;this.queue=[];this.events=0;this.capped=false;this.options=options;
  this.teams=[a,b].map((team,side)=>{const traits=teamTraits(team);if(options.disableFaction?.[side])traits.factions[options.disableFaction[side]]=0;
    const totalStars=team.active.reduce((s,x)=>s+teamStarRate(x.star),0),globalBoost=options.boost?.[side]||{};
   const active=team.active.map((r,pos)=>{
    const boost={...globalBoost,...(options.unitBoost?.[side]?.[r.id]||{})};
    const h=H[r.id],s=options.evolutionStars?.[side]?.[r.id]??r.star;
    const awake=r.star===20&&(r.awakening??team.awakening??0)===8;
    const [ap,dp,hp]=(r.star<10?EARLY_PRIMARY:PRIMARY)[h.role], aw=awake?.35:0;
    const m=starFactor(r.star)*(1+totalStars)*levelScale;
    const bonus={...SECONDARY[h.role],critReduce:.02,...(r.star<10?LOW_OVERRIDES[h.role]:{})};
    for(const [k,v] of Object.entries(boost))bonus[k]=(bonus[k]||0)+v;
    const atk=h.stats.atk*m*(1+ap+aw)*(1+(boost.atk||0));
    const baseDef=h.stats.def*m*(1+dp+aw),def=baseDef*(1+(boost.def||0));
    const max=h.stats.hp*m*(1+hp+aw)*(1+(boost.hp||0))*(traits.factions.bai>=2?1.08:1);
    return {id:r.id,h,star:s,actualStar:r.star,awake,side,pos,atk,def,max,hp:max,inner:baseDef*INNER_RATIOS[h.role]*(1+(boost.inner||0)),
     cultivationCrit:CULTIVATION_CRIT[h.role],speed:h.stats.speed+(boost.speed||0),buffs:{},flags:{},roundFlags:{},
     turns:0,casts:0,qi:0,shield:0,numericShield:awake?AWAKENING_SHIELD:0,shieldSource:null,bonus,
     yingBug:r.id==='h31'&&s>=20&&(r.variant??'live_bug')==='live_bug',metrics:{...emptyMetrics(),actions:0}};
   });
   const stars=Object.fromEntries([...team.active,...team.mechs].map(x=>[x.id,x.star]));
   const levels=Object.fromEntries(DB.combos.map(c=>[c.id,Math.min(...c.memberIds.map(id=>stars[id]??0))]));
   return {active,mechs:team.mechs,traits,comboLevels:levels,dead:0,flags:{}};
  });
  for(const t of this.teams) for(const u of t.active){
   if(t.traits.factions.chu>=4&&u.pos>=4)u.shield=1;
   if(u.id==='h02'&&u.star>=2)u.qi=1;
   if(['h06','h27'].includes(u.id)&&u.star>= (u.id==='h06'?2:10))this.buff(u,'tough',2);
   if(u.id==='h05'&&u.star>=10)this.buff(u,'strong',1);
   if(u.id==='h11'&&u.star>=10)this.buff(u,'dodge',2);
   if(u.id==='h15'&&u.star>=2)u.flags.seal=true;
   if(u.awake&&u.id==='h20')u.flags.clone=true;
   if(u.awake&&u.id==='h06')u.flags.swordMomentum=4;
  }
 }
 alive(side){return this.teams[side].active.filter(u=>u.hp>0);}
 disabled(u,key){return !!u&&!!this.options.disableMechanisms?.[u.side]?.includes(key);}
 foe(u){return this.alive(1-u.side);} friends(u){return this.alive(u.side);}
 find(side,id){return this.teams[side].active.find(u=>u.id===id&&u.hp>0);}
 n(u,k){return u.buffs[k]?.n||0;}
 buff(u,k,d=1,n=1,source=null){if(!u||u.hp<=0)return false;const negative=NEGATIVE.has(k);
  if(source&&this.disabled(source,'control')&&['stun','freeze','seal','confuse','charm'].includes(k))return;
  if(source&&this.disabled(source,'execute')&&k==='doom')return;
  if(this.disabled(source||u,'buffs')&&['strong','tough','haste','wind','fragile','weak'].includes(k))return;
  const unclean=LOCKED.has(k)||(k==='curse'&&source?.h.faction==='yin'&&this.teams[source.side].traits.factions.yin>=7);
  const unimmune=k==='curse'&&source?.h.faction==='yin'&&this.teams[source.side].traits.factions.yin>=7;
  if(negative&&!unimmune&&(this.n(u,'immune')||(u.awake&&u.id==='h37'&&!u.flags.firstAwakeSkill)||this.rng()<this.resist(u)))return false;
  const max={curse:3,weak:3,fragile:3,slow:5,strong:3,tough:3,haste:5,dodge:2,detect:4}[k]||1;
  const old=u.buffs[k];const sources=[...(old?.sources||[]),...Array(n).fill(source)].slice(-max);
  if(source){if(negative)source.metrics.debuffsApplied++;else source.metrics.buffsApplied++;if(source.side!==u.side){if(['stun','freeze','seal','confuse','charm'].includes(k)){source.metrics.hardControl++;source.metrics.controlInflicted++;}else if(['weak','fragile','slow'].includes(k)){source.metrics.softControl++;source.metrics.controlInflicted++;}}}
  u.buffs[k]={n:Math.min(max,(old?.n||0)+n),exp:u.turns+d,round:this.round+d-1,unclean:unclean||old?.unclean,source:source||old?.source,sources};return true;
 }
  cleanse(u,positive=false,source=null){let removed=0;for(const k of Object.keys(u.buffs)){const neg=NEGATIVE.has(k);if(neg!==positive&&!u.buffs[k].unclean){delete u.buffs[k];removed++;}}if(source&&!positive)source.metrics.cleanses+=removed;if(positive){u.flags.seal=false;}}
 aura(side,id){return !!this.find(side,id)?.awake;}
 resist(u){return clamp((u.bonus.resist||0)+(u.flags.seal?.5:u.awake&&u.id==='h15'?.3:0)+(u.awake&&u.id==='h17'?.16:0));}
 skillCoefficient(u){return personalCoefficient(u.h)-(this.aura(1-u.side,'h29')?.06:0);}
 comboPower(u,c){return this.comboCoefficient(u.side,c)-(this.aura(1-u.side,'h29')?.06:0);}
 shieldAbsorb(t,amount,o={}){let count=false;
  if(!o.true&&t.shield>0){t.shield--;count=true;if(!o.pierceShield){const saved=Math.min(amount,t.hp);t.metrics.protected+=saved;if(t.shieldSource)t.shieldSource.metrics.absorbed+=saved;else t.metrics.factionAbsorbed+=saved;return {remaining:0,count};}}
  if(!o.true&&t.numericShield>0){const absorbed=Math.min(t.numericShield,amount);t.numericShield-=absorbed;amount-=absorbed;t.metrics.protected+=absorbed;t.metrics.numericAbsorbed+=absorbed;}
  return {remaining:amount,count};
 }
 onAttackReceived(t,u,isSkill){if(!t.awake||isSkill||u.side===t.side||t.hp<=0)return;
  if(t.id==='h04'&&!t.roundFlags.awakeNormal){t.roundFlags.awakeNormal=true;this.buff(t,'tough',2);const ally=this.pick(this.friends(t).filter(x=>x!==t&&x.pos>=4));if(ally)this.buff(ally,'tough',2);}
  if(t.id==='h14'&&!t.roundFlags.awakeNormal){t.roundFlags.awakeNormal=true;this.buff(u,'freeze',2,1,t);}
 }
 onSkillDamage(t){if(!t.awake||t.hp<=0||t.roundFlags.awakeDamage)return;
  if(t.id==='h02'){const x=this.pick(this.foe(t));if(x){t.roundFlags.awakeDamage=true;this.buff(x,'curse',3,1,t);}}
  if(t.id==='h23'){const x=this.pick(this.foe(t).filter(x=>this.atk(x)<this.atk(t)));const y=this.pick(this.foe(t).filter(y=>y!==x&&this.defense(y)<this.defense(t)));if(x||y)t.roundFlags.awakeDamage=true;if(x)this.buff(x,'fragile',1,1,t);if(y)this.buff(y,'weak',1,1,t);}
 }
 extraAttack(u){return u.flags.jingExtra||0;}
 blackSword(u){if(u.awake&&u.id==='h33'&&!u.flags.blackSecond&&u.hp>0&&u.hp<u.max*.6){u.flags.blackSecond=true;u.flags.blackGain*=2;}}
 completeActive(u){if(!u.awake)return;
  if(u.id==='h05'&&(u.flags.jingLayers||0)<6){u.flags.jingLayers=(u.flags.jingLayers||0)+1;u.flags.jingExtra=this.extraAttack(u)+this.atk(u)*.15;}
  if(u.id==='h06')u.flags.swordMomentum=Math.max(0,(u.flags.swordMomentum||0)-1);
 }
 openingAwakening(){
  for(const t of this.teams)for(const u of t.active){if(!u.awake)continue;
   if(u.id==='h33')u.flags.blackGain=u.max*.02;
   if(u.id==='h18'&&u.pos<4){for(const x of this.front(u)){const take=x.def*.06;x.flags.awakeDefRob=(x.flags.awakeDefRob||0)+take;u.flags.awakeDefGain=(u.flags.awakeDefGain||0)+take;}}
   if(u.id==='h01'){
    const targets=this.foe(u).sort((a,b)=>this.atk(b)-this.atk(a)||a.pos-b.pos);
    let gi=0;for(const x of t.active){if(['h02','h03'].includes(x.id)){const target=targets[gi++];if(target&&this.rng()<.9)this.buff(target,'seal',1,1,u);}
     if(['h08','h09','h10','h19','h20'].includes(x.id)&&this.rng()<.9){const target=this.pick(this.foe(u));if(target)this.buff(target,'curse',1,1,u);}}
   }
   if(u.id==='h19')this.buff(u,'haste',2);
  }
 }
 atk(u){let f=1+.1*this.n(u,'strong')+.1*(u.flags.sword||0)+.1*u.qi;const t=this.teams[u.side];if(t.traits.factions.bai>=5)f+=.02*Math.min(this.round,5);if(this.find(u.side,'h23')?.star>=20)f+=.05;if(this.n(u,'curse')&&this.find(1-u.side,'h09')?.star>=10)f-=.06;f-=.15*this.n(u,'weak');const z=this.find(u.side,'h18');if(z?.awake&&z.pos>=4&&u.pos>=4&&u!==z)f+=.06;if(this.n(u,'hotBlood'))f+=.03;return Math.max(1,u.atk*f+(u.flags.stolen||0)-(u.flags.robbed||0)+(u.flags.blackGain||0));}
 defense(u){let f=1+.15*this.n(u,'tough')-.2*this.n(u,'fragile');const t=this.teams[u.side];if(t.traits.factions.bai>=5)f+=.02*Math.min(this.round,5);if(t.traits.factions.nong>=5&&u.h.faction==='nong'&&this.round===1)f+=.1;if(u.flags.seal)f+=.5;else if(u.awake&&u.id==='h15')f+=.3;if(this.n(u,'armor'))f+=.06;if(u.id==='h01'&&u.star>=10)f+=.1*this.foe(u).filter(x=>this.n(x,'curse')).length;if(this.find(u.side,'h23')?.star>=20)f+=.05;
  const opposite=this.teams[1-u.side].active[u.pos];if(this.teams[1-u.side].traits.factions.di>=5&&opposite.hp>0&&opposite.h.faction==='di')f-=.1;
  const fn=this.find(u.side,'h15');return Math.max(0,u.def*f+(fn&&fn!==u&&fn.star>=20?fn.def*.1:0)+(u.flags.blackGain||0)+(u.flags.awakeDefGain||0)-(u.flags.awakeDefRob||0));}
 inner(u){return u.inner*(1+(this.n(u,'tiger')?(u.awake?.6:.3):0)+Math.max(0,...this.friends(u).filter(x=>x!==u&&this.n(x,'tiger')).map(x=>x.awake?.2:.1))+(u.pos>=4&&this.find(u.side,'h24')?.star>=10?.2:0)+(this.find(u.side,'h23')?.star>=20?.05:0));}
 speed(u){return u.speed+25*this.n(u,'haste')-25*this.n(u,'slow')+(this.teams[u.side].traits.factions.di>=3?3:0);}
 pick(arr){return arr.length?arr[Math.floor(this.rng()*arr.length)]:null;}
 sample(arr,n){let a=arr.slice(),r=[];while(a.length&&r.length<n){const i=Math.floor(this.rng()*a.length);r.push(a.splice(i,1)[0]);}return r;}
 low(side,n=1){return this.alive(side).sort((a,b)=>a.hp/a.max-b.hp/b.max||a.pos-b.pos).slice(0,n);}
 // Slot geometry stays fixed when units die: F1..F4 = 0..3, R1..R5 = 4..8.
 front(u){return this.foe(u).filter(x=>x.pos<4);}
 back(u){return this.foe(u).filter(x=>x.pos>=4);}
 normalTarget(u){const front=this.front(u);return this.pick(front.length?front:this.foe(u));}
 adjacentPositions(pos){return pos<4?[pos+4,pos+5]:[pos-5,pos-4].filter(p=>p>=0&&p<4);}
 adjacent(t){const slots=this.adjacentPositions(t.pos);return this.alive(t.side).filter(x=>slots.includes(x.pos));}
 rangeCandidates(u,target){const e=this.foe(u);
  if(target==='三行'){const slots=[u.pos,...this.adjacentPositions(u.pos)];return e.filter(x=>slots.includes(x.pos));}
  if(target.includes('后排')){const row=this.back(u);return row.length||!target.includes('优先')?row:e;}
  if(target.includes('前排')){const row=this.front(u);return row.length||!target.includes('优先')?row:e;}
  return e;
 }
 personalHasTargets(u){if(u.h.skill.kind==='heal')return this.friends(u).length>0;
  if(u.id==='h02'&&u.star>=10)return this.foe(u).length>0;
  if(u.id==='h37'&&u.star>=10&&this.foe(u).some(x=>this.n(x,'grudge')))return true;
  return this.rangeCandidates(u,u.h.skill.target).length>0;
 }
 comboCoefficient(side,c){return c.coefficient*(1+.04*(this.teams[side].comboLevels[c.id]||0));}
 targets(u,target,count){const e=this.foe(u);
  if(target.includes('链状')||target.includes('链式')){const first=this.normalTarget(u);return first?[first,...this.sample(e.filter(x=>x!==first),(count||4)-1)]:[];}
  if(target==='单排'){const f=this.front(u),b=this.back(u);return f.length>=b.length?f:b;}
  const candidates=this.rangeCandidates(u,target);
  if(target==='三行'||target.includes('全体'))return candidates;
  if(target.includes('随机'))return this.sample(candidates,count||Number(target.match(/\d+/)?.[0])||3);
  if(target.includes('前排')||target.includes('后排'))return this.sample(candidates,1);
  const first=this.normalTarget(u);return first?[first]:[];
 }
 heal(source,t,amount){if(!t||t.hp<=0||this.disabled(source,'healing'))return;const attempted=Math.max(0,amount)*Math.max(0,1+(t.bonus.heal||0)-(this.n(t,'coldMark')?.7:0)-(this.aura(1-t.side,'h22')?(t.pos<4?.10:.06):0)),got=Math.min(t.max-t.hp,attempted);t.hp+=got;source.metrics.heal+=got;source.metrics.overheal+=attempted-got;
  const moon=this.find(1-t.side,'h03');if(got>0&&moon?.awake&&this.n(t,'curse')&&!t.roundFlags.moonSync&&this.rng()<.3){t.roundFlags.moonSync=true;this.heal(moon,moon,moon.max*.15);const k=this.pick(Object.keys(moon.buffs).filter(k=>NEGATIVE.has(k)&&!moon.buffs[k].unclean));if(k){delete moon.buffs[k];moon.metrics.cleanses++;}}
 }
 recordLoss(source,t,amount,kind='directDamage'){
  if(!Number.isFinite(amount))throw Error('Non-finite HP loss');if(!source||amount<=0)return;
  t.metrics.damageTaken+=amount;if(source.side===t.side){source.metrics.friendlyFire+=amount;return;}
   source.metrics.damage+=amount;source.metrics[kind]+=amount;if(this.round===1)source.metrics.openingDamage+=amount;
 }
 directLoss(source,t,amount,kind='hpReduction'){
  if(!t||t.hp<=0||amount<=0)return 0;const loss=Math.min(t.hp,amount);t.hp-=loss;this.recordLoss(source,t,loss,kind);this.checkRecovery(t);
  if(t.hp<=0)this.death(t,source||this.foe(t)[0]||t);return loss;
 }
 equalize(source,friends){if(this.disabled(source,'healing'))return;const ratio=friends.reduce((v,x)=>v+x.hp/x.max,0)/friends.length;for(const x of friends){const hp=ratio*x.max,delta=hp-x.hp;source.metrics[delta>=0?'redistributedGain':'redistributedLoss']+=Math.abs(delta);x.hp=hp;}}
 tickStatus(u,k){const status=u.buffs[k];if(!status||u.hp<=0||this.disabled(status.source,'dot'))return;
  const amount=k==='curse'?u.hp*.1*status.n:u.max*.05,pre=u.hp;const {remaining}=this.shieldAbsorb(u,amount);const loss=Math.min(pre,remaining);
  const sources=k==='curse'&&status.sources?.length?status.sources:[status.source];
  u.hp-=loss;for(const s of sources)this.recordLoss(s,u,loss/sources.length,'dotDamage');
  this.checkRecovery(u);if(u.hp<=0)this.death(u,status.source||this.foe(u)[0]||u);if(status.round<=this.round)delete u.buffs[k];
 }
 checkRecovery(u){this.blackSword(u);if(u.id==='h04'&&u.star>=20&&!u.flags.full&&u.hp>0&&u.hp<u.max*.4){u.flags.full=true;this.heal(u,u,u.max);this.cleanse(u,false,u);}}
 canCast(u,checkFreeze=true){if(!u||u.hp<=0)return false;if(u.id==='h16'&&u.star>=20&&u.hp<u.max*.5)return true;return !this.n(u,'stun')&&!this.n(u,'seal')&&!this.n(u,'confuse')&&!this.n(u,'charm')&&(!checkFreeze||!this.n(u,'freeze')||this.rng()>=.6);}
 canCounter(u,checkFreeze=true){if(!u||u.hp<=0)return false;if(u.id==='h16'&&u.star>=20&&u.hp<u.max*.5)return true;return !this.n(u,'stun')&&!this.n(u,'seal')&&(!checkFreeze||!this.n(u,'freeze')||this.rng()>=.6);}
 enqueue(fn){this.queue.push(fn);}
 flush(){while(this.queue.length){if(++this.events>2000){this.capped=true;this.queue=[];break;}this.queue.shift()();}}
 damage(u,t,raw,o={}){
  if(!Number.isFinite(raw)||o.coefficient!==undefined&&(!Number.isFinite(o.coefficient)||o.coefficient<=0)||o.extraDamage!==undefined&&!Number.isFinite(o.extraDamage))throw Error('Non-finite damage or invalid coefficient: '+u?.id);
  if(!t||u.hp<=0||t.hp<=0||raw<=0)return {amount:0,killed:false,crit:false};
  if(this.disabled(u,'penetration'))o={...o,ignoreDef:false,ignoreDefRate:0,ignoreInner:false,pierce:0};if(this.disabled(u,'trueDamage'))o={...o,true:false};
  const isSkill=!o.normal;let dodge=o.ignoreSkillDodge&&isSkill?0:isSkill?(this.n(t,'hidden')?.4:0)+(t.bonus.skillDodge||0)+(t.awake&&t.id==='h17'?.16:0):.3*this.n(t,'dodge')+(t.awake&&t.id==='h17'?.16:0)+(this.teams[t.side].traits.factions.yin>=2?.03:0)+(t.bonus.dodge||0);
  if(this.rng()<clamp(dodge))return {amount:0,killed:false,crit:false,miss:true};
  let critChance=u.cultivationCrit+.15*this.n(u,'detect')+(this.aura(u.side,'h09')?.05:0)+(u.bonus.crit||0)+(this.teams[u.side].traits.factions.chu>=2?.03:0)+.1*(u.flags.sword||0)+(u.flags.farmCrit?.1:0)+(this.n(u,'wind')?.05:0)+(o.crit||0);
  const anti=(t.bonus.antiCrit||0)+.05*(t.flags.swordMomentum||0)+(t.id==='h37'&&t.star>=2?.06:0)+(this.teams[t.side].traits.factions.mo>=4?.03:0);
  const crit=!this.disabled(u,'crit')&&(!!o.forceCrit||this.rng()<clamp(critChance-(o.ignoreAnti?0:anti)));
  let amount=raw;
  if(!o.true){const coefficient=o.coefficient??1,extra=(o.extraDamage||0)+this.extraAttack(u);
   amount=damageBeforeCritical({attack:o.attack??(raw-(o.extraDamage||0))/coefficient,defense:o.ignoreDef?0:this.defense(t)*(1-(o.ignoreDefRate||0)),coefficient,extra,inner:isSkill&&!o.ignoreInner?this.inner(t):0});}

  if(o.true)amount+=this.extraAttack(u);
  if(crit)amount*=Math.max(1,1.5+(this.teams[u.side].traits.factions.nong>=4?.1:0)+(u.bonus.critDamage||0)+(o.critDamage||0)-(t.bonus.critReduce||0)-(this.aura(t.side,'h12')?.06:0));
  const reduction=(t.bonus.skillReduce||0)+(this.aura(t.side,'h27')?.05:0)+(this.teams[t.side].traits.factions.mo>=3?.03:0)+(t.id==='h26'&&this.options.disableCombo?.[t.side]!==t.h.comboId?this.comboCoefficient(t.side,C[t.h.comboId]):0)+(t.id==='h37'&&t.star>=2?.06:0);
  let pierce=this.disabled(u,'penetration')?0:(o.pierce||0)+(u.bonus.pierce||0)+.05*(u.flags.swordMomentum||0)+(this.teams[u.side].traits.factions.yin>=4?.03:0)+(this.n(u,'wind')?.05:0);if(this.n(u,'curse')&&this.find(1-u.side,'h03')?.star>=10)pierce-=.25;
  amount*=o.true?1-clamp((t.bonus.trueResist||0)+(this.aura(t.side,'h36')?.05:0),0,.95):isSkill?1-clamp(reduction-pierce,0,.95):1;
  amount*=1+(u.bonus.damage||0);amount=Math.max(1,Math.round(amount));
  const absorbed=this.shieldAbsorb(t,amount,o);amount=absorbed.remaining;
  this.onAttackReceived(t,u,isSkill);
  if(amount<=0)return {amount:0,killed:false,crit,shield:absorbed.count,numericAbsorbed:!absorbed.count};
  const pre=t.hp;t.hp=Math.max(0,t.hp-amount);this.recordLoss(u,t,Math.min(pre,amount));if(u.side!==t.side){u.metrics[isSkill?'skillDamage':'normalDamage']+=Math.min(pre,amount);if(crit)u.metrics.criticalDamage+=Math.min(pre,amount);if(o.area)u.metrics.areaDamage+=Math.min(pre,amount);if(o.counter)u.metrics.counterDamage+=Math.min(pre,amount);}
  this.checkRecovery(t);
  if(isSkill&&u.side!==t.side)this.onSkillDamage(t);
  if(t.id==='h16'&&t.star>=10&&amount>pre*.1)this.buff(t,this.rng()<.5?'tough':'strong',2);
  if(t.id==='h37')this.buff(u,'grudge',3,1,t);
  if(t.id==='h34'&&t.star>=10&&!t.roundFlags.charm&&t.hp>0){t.roundFlags.charm=true;const x=this.pick(this.foe(t));if(x)this.buff(x,'charm',2,1,t);}
  if(isSkill&&t.id==='h03'&&t.star>=2&&t.hp>0&&this.rng()<.8){const x=this.pick(this.foe(t));if(x)this.buff(x,'curse',2,1,t);}
  if(t.hp<=0)this.death(t,u);
  else if(!o.noCounter)this.react(t,u,isSkill);
  return {amount:Math.min(pre,amount),killed:t.hp<=0,crit};
 }
 react(t,u,isSkill){if(t.hp<=0)return;const id=t.id,s=t.star;const can=(['h26','h13'].includes(id)||this.canCounter(t,false));
  if(!can||this.disabled(t,'counter'))return;
  if(id==='h26'&&(t.roundFlags.chart||0)<(s>=20?7:s>=10?6:s>=2?5:4)){t.roundFlags.chart=(t.roundFlags.chart||0)+1;const first=t.roundFlags.chart===1;this.enqueue(()=>{if(t.hp<=0)return;const r=this.damage(t,u,this.atk(t)*this.skillCoefficient(t)+(this.options.disableCombo?.[t.side]!==t.h.comboId?this.inner(t):0),{noCounter:true,counter:true,coefficient:this.skillCoefficient(t),extraDamage:this.options.disableCombo?.[t.side]!==t.h.comboId?this.inner(t):0});if(r.amount){if(s>=2&&first)this.buff(u,'fragile',2,1,t);if(s>=10)this.heal(t,t,r.amount*.35);if(s>=20&&this.rng()<.2)this.buff(u,'stun',1,1,t);}});}
  if(id==='h13'&&s>=2&&isSkill&&!t.flags.firstHit){t.flags.firstHit=true;this.enqueue(()=>{if(t.hp<=0)return;const x=this.normalTarget(t);if(!x)return;const r=this.damage(t,x,this.atk(t),{noCounter:true,counter:true});if(!r.miss)this.buff(x,'fragile',1,1,t);if(t.awake)this.buff(t,'detect',3);});}
  if(id==='h15'&&s>=10&&t.flags.seal&&!t.roundFlags.sealQueued&&this.rng()<.5){t.roundFlags.sealQueued=true;this.enqueue(()=>{this.skill(t,true,u);t.roundFlags.sealQueued=false;});}
  if(id==='h06'&&s>=20&&!t.roundFlags.counter&&!t.roundFlags.counterQueued){t.roundFlags.counterQueued=true;this.enqueue(()=>{t.roundFlags.counterQueued=false;if(!this.canCounter(t))return;t.roundFlags.counter=true;for(const x of this.foe(t).sort((a,b)=>b.hp/b.max-a.hp/a.max).slice(0,3)){this.damage(t,x,this.atk(t)*this.skillCoefficient(t)+(t.max-t.hp)*.15,{noCounter:true,counter:true,coefficient:this.skillCoefficient(t),extraDamage:(t.max-t.hp)*.15});this.buff(x,'fragile',1,1,t);}});}
  if(id==='h22'&&s>=10&&!t.roundFlags.counter&&!t.roundFlags.counterQueued){t.roundFlags.counterQueued=true;this.enqueue(()=>{t.roundFlags.counterQueued=false;if(!this.canCounter(t))return;t.roundFlags.counter=true;this.damage(t,u,t.max*.25,{noCounter:true,counter:true});this.buff(u,'burn',1,1,t);});}
  if(['h16','h20','h27','h28','h29'].includes(id)&&!t.roundFlags.counter&&!t.roundFlags.counterQueued){let p=t.h.skill.chance;if(id==='h16'&&s>=20&&t.hp<t.max*.5)p=1;if(id==='h20'&&s>=10&&t.flags.clone)p=1;if(this.rng()<p){t.roundFlags.counterQueued=true;this.enqueue(()=>{t.roundFlags.counterQueued=false;if(this.skill(t,true,u))t.roundFlags.counter=true;});}}
 }
 death(t,killer){const own=this.teams[t.side],enemy=this.teams[1-t.side];own.dead++;if(killer&&killer.side!==t.side)killer.metrics.kills++;const cursed=this.n(t,'curse');
  for(const a of this.alive(1-t.side)){
   if(a.id==='h08'&&a.star>=20&&cursed&&!a.flags.extra){a.flags.extra=true;this.enqueue(()=>this.skill(a));}
   if(a.id==='h13'&&a.star>=10&&!a.flags.enemyDeath){a.flags.enemyDeath=true;this.enqueue(()=>{const x=this.low(t.side)[0];if(this.damage(a,x,this.atk(a),{noCounter:true}).killed)this.buff(a,'strong',1);if(a.awake&&x)this.buff(a,'detect',3);});}
   if(a.id==='h23'&&a.star>=10&&!a.roundFlags.kill){a.roundFlags.kill=true;this.friends(a).forEach(x=>this.buff(x,'strong',2));}
   if(a.id==='h29'&&a.star>=2&&!a.roundFlags.kill){a.roundFlags.kill=true;const x=this.pick(this.friends(a));if(x){this.buff(x,'tough',3);this.cleanse(x,false,a);}}
   if(a.id==='h30'&&a.star>=2&&!a.flags.kill){a.flags.kill=true;this.friends(a).forEach(x=>this.buff(x,'wind',2));}
  }
  for(const a of this.alive(t.side)){
   if(a.id==='h10'&&a.star>=20&&!a.roundFlags.rescue){a.roundFlags.rescue=true;this.enqueue(()=>this.skill(a));}
   if(a.id==='h13'&&a.star>=20&&!a.flags.allyDeath){a.flags.allyDeath=true;this.enqueue(()=>{this.damage(a,killer,this.atk(a),{noCounter:true});this.buff(killer,'seal',2,1,a);if(a.awake)this.buff(a,'detect',3);});}
   if(a.id==='h31'&&a.star>=2&&!a.flags.allyDeath){a.flags.allyDeath=true;this.friends(a).forEach(x=>this.heal(a,x,.09*x.max));}
  }
  const farm=DB.combos.find(c=>c.trigger==='ally_death');if(this.comboAvailable(t.side,farm,false)){const owner=this.find(t.side,'h36')||this.find(t.side,'h37');if(owner){const atk=farm.memberIds.reduce((sum,id)=>{const a=this.find(t.side,id);const m=own.mechs.find(x=>x.id===id);return sum+(a?this.atk(a):m?H[id].stats.atk*starFactor(m.star):0);},0);this.alive(t.side).forEach(x=>this.heal(owner,x,(x.max-x.hp)*.05+atk*this.comboPower(owner,farm)));}}
 }
 comboAvailable(side,c,requireActive=true){if(!c||this.options.disableCombo?.[side]===c.id)return false;const ids=new Set([...this.alive(side).map(x=>x.id),...this.teams[side].mechs.map(x=>x.id)]);return c.memberIds.every(id=>ids.has(id))&&c.memberIds.some(id=>this.find(side,id));}
 skill(u,counter=false,attacker=null){if(u.hp<=0||counter&&!this.canCounter(u)||!this.personalHasTargets(u))return false;let id=u.id,s=u.star,a=this.atk(u),coef=this.skillCoefficient(u),targets=[],opts={noCounter:counter},chain=u.h.skill.target.includes('链状'),dice=0;u.casts++;if(u.awake&&id==='h37')u.flags.firstAwakeSkill=true;
  if(u.h.skill.kind==='heal'){
   let friends=this.friends(u);
   if(id==='h22'){this.equalize(u,friends);u.flags.firstHeal=true;}
   if(id==='h10')friends=this.low(u.side,u.awake?5:4);
   friends.forEach((x,i)=>{let amount=a*coef;if(id==='h12'&&s>=2&&x.hp<x.max*.5)amount*=1.4;if(id==='h22'&&s>=2)amount*=1+.1*Math.floor(this.teams[u.side].dead/2);this.heal(u,x,amount);if(id==='h12'&&x.hp>=x.max)this.buff(x,'dodge',1);if(id==='h10'){if(this.rng()<1-.2*i)this.cleanse(x,false,u);if(s>=10)this.buff(x,'immune',2);}});return true;
  }
  if(id==='h26')return true;
  if(id==='h02'){a=this.atk(u);if(s>=10)targets=this.foe(u);}
  if(id==='h16')targets=attacker&&attacker.hp>0?[attacker]:this.targets(u,'单体');
  if(id==='h20'){targets=this.sample(this.foe(u),u.flags.clone?2:1);this.cleanse(u,false,u);u.flags.clone=false;}
  if(id==='h28')targets=this.low(1-u.side,1);
  if(id==='h29')targets=this.foe(u).sort((a,b)=>a.hp/a.max-b.hp/b.max).slice(0,1);
  if(id==='h32'){const roll=this.rng();dice=u.awake?(roll<1/3?6:1+Math.floor((roll-1/3)*7.5)):1+Math.floor(roll*6);if(u.awake&&dice!==6)this.buff(u,'detect',2);if(s>=10&&dice===6){targets=this.foe(u);u.flags.nextDice=this.round+1;}if(dice%2||dice===6&&s>=10)opts.crit=.2;if(dice%2===0)opts.pierce=.15;}
  if(!targets.length)targets=this.targets(u,u.h.skill.target,id==='h11'?4+(s>=10?1:0)+(s>=20?1:0):id==='h17'?4+(s>=20?1:0):id==='h38'?3+(s>=10?1:0):undefined);
  if(id==='h37'&&s>=10)targets=[...new Set([...targets,...this.foe(u).filter(x=>this.n(x,'grudge'))])];
  if(this.disabled(u,'area'))targets=targets.slice(0,1);
  let gaineLoss=0;
  const initialTargets=targets.slice(), highTarget=targets.slice().sort((a,b)=>b.hp/b.max-a.hp/a.max||a.pos-b.pos)[0];
  for(let i=0;i<(id==='h30'?(this.disabled(u,'area')?1:3):targets.length);i++){
   const t=id==='h30'?this.pick(this.foe(u)):targets[i];if(!t)break;if(t.hp<=0)continue;let raw=a*coef,op={...opts,counter,area:targets.length>1},factor=1,sourceAttack=a;
   if(chain){const decay=Math.pow(id==='h11'?1:id==='h05'&&s>=2?.95:.9,i);raw*=decay;factor*=decay;}
   if(id==='h01')op.ignoreAnti=true;
   if(id==='h02'){if(s>=10&&t.pos>=4){raw*=.7;factor*=.7;}if(s>=20){raw+=this.inner(u)*.5;op.critDamage=.3;}}
   if(id==='h03'&&s>=20&&this.n(t,'curse')){op.ignoreDef=true;op.ignoreInner=true;}
   if(id==='h04'&&s>=2&&u.hp<u.max*.7)raw+=this.defense(u);
   if(id==='h05'){if(s>=2&&t.pos>=4){raw*=1.25;factor*=1.25;}if(s>=10)op.crit=.1;}
   if(id==='h06')raw+=(u.max-u.hp)*.15;
   if(id==='h07'){raw+=this.inner(u);if(s>=10){op.pierce=.15;if(t.hp<t.max*.5)op.critDamage=.3;}}
   if(id==='h08'&&s>=10){op.noCounter=true;if(targets.length<4){raw*=1.3;factor*=1.3;}if(targets.length===1)op.forceCrit=true;}
   if(id==='h09'&&s>=20)op.ignoreDef=true;
   if(id==='h11'&&s>=2&&this.n(t,'stun'))op.forceCrit=true;
   if(id==='h13')raw+=Math.min(raw,this.atk(t)*.5);
   if(u.awake&&id==='h11')raw+=Math.min(raw,t.hp*.15);
   if(u.awake&&id==='h25'&&i===0)op.forceCrit=true;
   if(u.awake&&id==='h38'&&t.pos<4){raw*=1.4;factor*=1.4;}
   if(u.awake&&id==='h31')op.ignoreDefRate=.50;
   if(u.awake&&id==='h30'&&this.rng()<.4)op.true=true;
   if(u.awake&&id==='h07'&&i===0)op.pierceShield=true;
   if(u.awake&&id==='h16'){op.pierce=(op.pierce||0)+.2;op.ignoreSkillDodge=true;if(t.hp>t.max*.5){op.pierce+=.2;op.pierceShield=true;}}
   if(id==='h14'&&s>=2)op.noCounter=true;
   if(id==='h15'){sourceAttack=a+this.defense(u)*.3;raw=sourceAttack*coef;}
   if(id==='h16'&&s>=20)raw+=this.defense(u);
   if(id==='h17'&&s>=10&&this.foe(u).length<=5)op.forceCrit=true;
   if(id==='h18'&&s>=2){const m=1+.2*(5-this.foe(u).filter(x=>x.pos>=4).length);raw*=m;factor*=m;}
   if(id==='h19'&&t===highTarget)op.forceCrit=true;
   if(id==='h21'){raw+=(u.max-u.hp)*.15;if(s>=2)op.noCounter=true;}
   if(id==='h24'&&s>=20)op.crit=.2;
   if(id==='h25'){if(t.pos>=4){raw*=1.3;factor*=1.3;}if(s>=2)op.critDamage=.5;}
   if(id==='h30'){op.pierce=.15;if(s>=20&&i===0)op.forceCrit=true;}
   if(id==='h31'&&s>=10){factor=Math.pow(.9,i);sourceAttack=a+.5*this.defense(u);raw=sourceAttack*coef*factor;}
   if(id==='h32'&&s>=10&&dice===6&&t.pos>=4){raw*=.7;factor*=.7;}
   if(id==='h33'&&s>=2&&u.hp<u.max*.65)op.crit=.3;
   if(id==='h35'&&this.inner(t)<this.inner(u))op.forceCrit=true;
   if(id==='h36')raw+=.05*this.friends(u).filter(x=>x!==u).reduce((v,x)=>v+this.atk(x),0);
   if(id==='h37'){if(s>=10&&this.n(t,'grudge'))op.forceCrit=true;if(s>=20)op.true=true;}
   if(id==='h38'){op.ignoreInner=true;if(s>=2&&t.hp<t.max*.5)op.forceCrit=true;if(s>=10)op.noCounter=true;}
   op.coefficient=coef*factor;op.attack=sourceAttack;op.extraDamage=raw-sourceAttack*op.coefficient;
   const r=this.damage(u,t,raw,op);
   if(!r.miss){
    if(u.awake&&id==='h24'&&this.rng()<.6)this.buff(t,'fragile',1,1,u);
    if(u.awake&&id==='h07'&&i===0)this.buff(t,'fragile',1,1,u);
    if(u.awake&&id==='h28'&&i===0&&!r.killed)this.heal(u,u,(u.max-u.hp)*.25);
    if(u.awake&&id==='h34'&&this.rng()<.6)this.buff(t,'coldMark',2,1,u);
    if(id==='h01'&&s>=2&&r.crit)this.buff(t,'curse',1,1,u);
    if(id==='h03'&&this.rng()<.55)this.buff(t,'curse',2,1,u);
    if(id==='h04'&&this.rng()<.35)this.buff(t,'stun',1,1,u);
    if(id==='h05'&&this.rng()<(s>=20?.7:.4))this.buff(t,'fragile',2,1,u);
    if(id==='h08'&&this.rng()<.55)this.buff(t,'curse',1,1,u);
    if(id==='h09')this.buff(t,'curse',2,1,u);
    if(id==='h11'&&s>=2&&this.rng()<.2)this.buff(t,'stun',1,1,u);
    if(id==='h14'&&this.rng()<(s>=2?.4:.3))this.buff(t,'freeze',1,1,u);
    if(id==='h16'){this.buff(t,'slow',2,1,u);if(s>=2){this.heal(u,u,r.amount*.3);this.heal(u,this.low(u.side,9).find(x=>x!==u),r.amount*.3);}}
    if(id==='h17'){if(t.hp<t.max*.1)this.buff(t,'doom',1,1,u);if(s>=2&&this.foe(u).length>5&&this.rng()<.4)this.buff(t,'stun',1,1,u);}
    if(id==='h18'&&this.rng()<.4)this.buff(t,'fragile',1,1,u);
    if(id==='h20'&&s>=20&&this.rng()<.8)this.buff(t,'confuse',1,1,u);
    if(id==='h21'&&s>=10){const stunned=this.rng()<.45&&this.buff(t,'stun',1,1,u);if(!stunned)this.buff(t,'weak',1,1,u);}
    if(id==='h24'&&s>=20)this.cleanse(t,true);
    if(id==='h27'){const sealed=this.rng()<.3&&this.buff(t,'seal',1,1,u);if(!sealed&&s>=2)this.buff(t,'slow',2,1,u);}
    if(id==='h28')this.buff(t,'weak',2,1,u);
    if(id==='h30'&&s>=20){if(i===1)this.buff(t,'seal',1,1,u);if(i===2)this.heal(u,u,r.amount*.5);}
    if(id==='h31'){if(this.defense(t)<this.defense(u)&&this.rng()<.6)this.buff(t,'weak',1,1,u);if(this.speed(t)<this.speed(u)&&this.rng()<.6)this.buff(t,'fragile',1,1,u);}
    if(id==='h34'&&s>=2&&this.rng()<.5)this.buff(t,'weak',1,1,u);
   }
   if(id==='h07'){
    gaineLoss+=r.amount;if(s>=10)for(const x of this.adjacent(t))gaineLoss+=this.damage(u,x,raw*.7,{...op,pierceShield:false,coefficient:op.coefficient*.7,extraDamage:op.extraDamage*.7}).amount;
    if(s>=2&&r.killed)this.buff(u,'haste',2);
   }
   if(id==='h09'&&s>=2){if(r.killed)this.damage(u,this.pick(this.foe(u)),raw*.7,{...op,coefficient:op.coefficient*.7,extraDamage:op.extraDamage*.7});else this.buff(u,'strong',1);}
   if(id==='h28'&&s>=2&&r.killed)for(const x of this.foe(u).filter(x=>(x.pos<4)===(t.pos<4)))this.damage(u,x,raw*(t.pos<4?.8:.6),{...op,coefficient:op.coefficient*(t.pos<4?.8:.6),extraDamage:op.extraDamage*(t.pos<4?.8:.6)});
   if(id==='h29'&&s>=20){if(r.killed)this.heal(u,this.low(u.side)[0],r.amount*.6);else {const x=this.pick(this.foe(u).filter(x=>x!==t));if(x)this.directLoss(u,x,Math.max(0,x.hp-t.hp/t.max*x.max));}}
   if(id==='h35'&&s>=20)for(const x of this.foe(u).filter(x=>x!==t&&(x.pos<4)===(t.pos<4)))this.damage(u,x,this.inner(u)*1.30,{true:true,noCounter:counter});
  }
  if(u.awake){
   if(id==='h07')this.heal(u,u,gaineLoss*.2);
   if(id==='h08')for(const x of this.foe(u).filter(x=>!initialTargets.includes(x)))this.buff(x,'weak',1,1,u);
   if(id==='h19'){const n=5-this.back(u).length;for(let i=0;i<n;i++){const x=this.pick(this.front(u));if(!x)break;this.damage(u,x,a*coef*1.4,{coefficient:coef*1.4,noCounter:counter,counter});}}
   if(id==='h20')this.heal(u,u,(u.max-u.hp)*.1);
  }
  if(id==='h25'&&s>=20&&this.n(u,'hidden')&&this.rng()<.1){const hidden=u.buffs.hidden;u.buffs.hidden={...hidden,exp:hidden.exp+1};}
  if(id==='h02')u.qi=0;
  if(id==='h06'&&s>=2)this.buff(u,'tough',2);
  if(id==='h07'){if(s>=2)u.flags.sword=Math.min(4,(u.flags.sword||0)+1);if(s>=20)this.buff(u,'dodge',1);}
  if(id==='h15')u.flags.seal=false;
  if(id==='h19'&&s>=10){const x=initialTargets.filter(x=>x.hp>0).sort((a,b)=>this.atk(b)-this.atk(a))[0];if(x)this.buff(x,'confuse',1,1,u);}
  if(id==='h21'&&s>=2)this.buff(u,'tough',2);
  if(id==='h23')this.sample(this.friends(u),3).forEach(x=>this.buff(x,'haste',1));
  if(id==='h24'){this.friends(u).filter(x=>x.pos<4).forEach(x=>this.heal(u,x,a*coef*.3));if(s>=2)u.flags.coolUntil=this.round+1;u.flags.fusuStack=0;}
  if(id==='h31'&&s>=20&&!u.yingBug)u.flags.coolUntil=this.round+1;
  if(id==='h32'&&s>=2){if(dice<=3||dice===6&&s>=10)this.heal(u,this.pick(this.friends(u)),a*coef*.5);if(dice>=4){const x=this.pick(this.friends(u));if(x)this.cleanse(x,false,u);}}
  if(id==='h33'){this.buff(u,'tough',2);if(s>=10)this.foe(u).sort((a,b)=>b.hp/b.max-a.hp/a.max).slice(0,3).forEach(x=>this.damage(u,x,this.atk(u),{noCounter:counter}));}
  if(id==='h34')this.heal(u,u,u.max*.15);
  if(id==='h36'){
   if(s>=2){const all=this.friends(u),x=this.pick(all),max=Math.max(...all.map(x=>x.hp/x.max));if(x){this.heal(u,x,max*x.max-x.hp);this.buff(x,'strong',1);}}
   if(s>=10){const all=this.foe(u),x=this.pick(all),min=Math.min(...all.map(x=>x.hp/x.max));if(x){this.directLoss(u,x,Math.max(0,x.hp-min*x.max));this.buff(x,'weak',1,1,u);}}
  }
  return true;
 }
 combo(u,c){const coef=this.comboPower(u,c);let a=this.atk(u),name=c.name;let targets=this.targets(u,c.target),opts={};if(['暗度陈仓','天下大同'].includes(name))opts.true=true;if(name==='纵横寰宇')opts.ignoreInner=true;if(name==='天人合一')opts.pierce=.15;
  if(name==='帝子降兮'){const t=this.foe(u).sort((a,b)=>b.hp/b.max-a.hp/a.max)[0];targets=t?[t,...this.adjacent(t)]:[];}
  if(name==='亢龙有悔'){const counts={},limit=this.disabled(u,'area')?1:6;for(let i=0;i<limit;i++){const t=this.pick(this.foe(u).filter(x=>(counts[x.id]||0)<2));if(!t)break;counts[t.id]=(counts[t.id]||0)+1;const r=this.damage(u,t,a*coef,{coefficient:coef,extraDamage:0,area:limit>1});if(!r.miss)this.buff(t,'seal',1,1,u);}return;}
  if(this.disabled(u,'area'))targets=targets.slice(0,1);
  const highestTarget=targets.slice().sort((a,b)=>b.hp/b.max-a.hp/a.max||a.pos-b.pos)[0];
  const hit=(t,i,m=1)=>{const wasHighest=t===highestTarget;let factor=m,raw=a*coef*m,op={...opts,area:targets.length>1};if(name==='混沌洪荒'&&this.n(t,'curse')){raw*=1.3;factor*=1.3;}if(name==='三极殒灭'&&this.n(t,'curse'))op.forceCrit=true;if(name==='纵横寰宇'){const mult=1+.05*(9-this.foe(u).length);raw*=mult;factor*=mult;}
   if(name==='帝子降兮'&&i===0)op.forceCrit=true;if(name==='横扫千军'&&t.pos>=4)op.forceCrit=true;if(name==='八方俱灭'&&t.pos<4)op.ignoreDef=true;if(name==='霸道无双'&&wasHighest)op.forceCrit=true;if(name==='天崩地裂')raw+=t.max*.1;if(c.target.includes('链状')){const decay=Math.pow(.9,i);raw*=decay;factor*=decay;}
   op.coefficient=coef*factor;op.extraDamage=raw-a*op.coefficient;const wasCursed=this.n(t,'curse');const r=this.damage(u,t,raw,op);if(r.miss)return r;
   if(name==='混沌洪荒'&&!wasCursed)this.buff(t,'curse',2,1,u);
   if(['翻云覆雨','白羽墨影'].includes(name)&&t.hp<t.max*.3)this.buff(t,'doom',1,1,u);
   if(name==='天人合一'&&this.rng()<.1)this.buff(t,'stun',1,1,u);
   if(name==='阳春白雪'&&t.hp<t.max*.5)this.buff(t,'freeze',1,1,u);
   if(name==='帝子降兮'&&i>0)this.buff(t,'confuse',1,1,u);
   if(name==='横扫千军'&&this.rng()<.7)this.buff(t,'seal',1,1,u);
   if(name==='亢龙有悔')this.buff(t,'seal',1,1,u);
   if(name==='八方俱灭'&&t.pos>=4)this.buff(t,'weak',2,1,u);
   if(name==='霸道无双'&&!wasHighest)this.buff(t,'charm',1,1,u);return r;
  };
  for(let i=0;i<targets.length;i++){const t=targets[i];const r=hit(t,i);if(name==='屠龙之刃'&&r.killed){let m=.7;for(let n=0;n<8;n++){const x=this.pick(this.foe(u));if(!x||!hit(x,0,m).killed)break;m*=.7;}}}
  if(name==='暗度陈仓'&&!this.disabled(u,'shield'))this.friends(u).forEach(x=>{x.shield=1;x.shieldSource=u;u.metrics.shieldsGiven++;});
  if(name==='翻云覆雨')this.low(u.side,2).forEach(x=>{this.heal(u,x,a*coef*.4);this.cleanse(x,false,u);});
  if(name==='天人合一')this.low(u.side,9-this.foe(u).length).forEach(x=>this.heal(u,x,a*coef*.6));
  if(name==='寂剑离风'){const t=this.foe(u).sort((a,b)=>this.atk(b)-this.atk(a))[0];if(t)this.buff(t,'stun',1,1,u);this.friends(u).forEach(x=>this.cleanse(x,false,u));}
  if(name==='天崩地裂'){let scope=9;while(scope>0&&this.foe(u).length>0&&this.foe(u).length<scope){scope-=3;if(scope<=0)break;this.sample(this.foe(u),scope).forEach((t,i)=>hit(t,i));}}
 }
 normal(u,forced=null){const target=forced||this.normalTarget(u);if(!target)return;this.damage(u,target,this.atk(u),{normal:true});const s=u.star,id=u.id;
  if(id==='h02')u.qi=Math.min(2,u.qi+1);
  if(id==='h04'&&s>=10){this.buff(u,'tough',1);this.buff(u,'strong',1);}
  if(id==='h06'&&s>=10)this.heal(u,u,u.max*.1);
  if(id==='h08'&&s>=2){for(const x of this.sample(this.foe(u),2))this.buff(x,'curse',1,1,u);}
  if(id==='h10'&&s>=2){const x=this.pick(this.friends(u));if(x)this.buff(x,'strong',2);}
  if(id==='h12'&&s>=10){const x=this.low(u.side)[0];if(x)this.heal(u,x,x.max*.15);}
  if(id==='h14'&&s>=10)this.buff(target,'freeze',1,1,u);
  if(id==='h15'&&s>=2)u.flags.seal=true;
  if(id==='h18'&&s>=10){this.buff(target,'fragile',1,1,u);this.buff(target,'weak',1,1,u);}
  if(id==='h20'&&s>=2){u.flags.clone=true;if(s>=10)this.buff(u,'dodge',1);}
  if(id==='h25'&&s>=10)this.buff(u,'hidden',1);
  if(id==='h27'&&s>=10)this.buff(u,'tough',2);
  if(id==='h35'&&s>=2)this.buff(u,'tiger',u.awake?3:2);
  if(u.awake&&id==='h24')this.buff(target,'fragile',1,1,u);
  if(u.awake&&id==='h26'&&this.rng()<.1*this.friends(u).length){const x=this.friends(u).filter(x=>x.pos>=4).sort((a,b)=>a.hp-b.hp||a.pos-b.pos)[0];if(x&&!this.disabled(u,'shield')){x.shield=1;x.shieldSource=u;u.metrics.shieldsGiven++;}}
 
  if(this.teams[u.side].traits.factions.nong>=7&&u.h.faction==='nong')u.flags.farmCrit=true;
 }
 probability(u){const s=u.star,id=u.id;let p=u.h.skill.chance;
  if(['h16','h20','h26'].includes(id))return 0;
  if(id==='h27')return s>=20&&this.n(u,'tough')>=3?1:0;
  if(id==='h28')return s>=20?.5:0;
  if(id==='h29')return s>=10?.4:0;
  if(id==='h02')p+=.35*u.qi;
  if(id==='h06'&&s>=10)p*=2;
  if(['h01','h07'].includes(id)&&s>=20)p=1;
  if(['h03','h17','h38'].includes(id)&&s>=20)p*=2;
  if(id==='h05'&&s>=20&&this.round===1)p=1;
  if(id==='h08'&&s>=20)p+=.1;
  if(id==='h10'&&u.awake)p+=.1;
  if(id==='h09'&&s>=20)p+=.3;
  if(id==='h11'&&s>=20)p+=.04*this.foe(u).filter(x=>this.speed(x)<this.speed(u)).length;
  if(id==='h12'&&s>=20)p+=.1*this.friends(u).filter(x=>x.hp<x.max*.7).length;
  if(id==='h14'&&s>=20&&u.hp<u.max*.5&&!u.flags.lowGuarantee){p=1;}
  if(id==='h18'&&s>=20&&this.round===1)p=1;
  if(id==='h19'&&s>=20)p+=.03*Math.floor(100*u.hp/u.max/4);
  if(id==='h21'&&s>=20&&u.hp<u.max*.6)p=1;
  if(id==='h22'&&s>=20&&!u.flags.firstHeal)p=1;
  if(id==='h23'&&this.round===1)p=1;
  if(id==='h24'&&s>=2)p+=.4*(u.flags.fusuStack||0);
  if(id==='h25'&&s>=20&&this.n(u,'hidden'))p=1;
  if(id==='h30'&&s>=10&&u.casts<3)p*=2;
  if(id==='h31'&&s>=20)p=1;
  if(id==='h32'&&(s>=20&&this.round===1||u.flags.nextDice===this.round))p=1;
  if(id==='h33'&&s>=20)p+=.07*(9-this.foe(u).length+this.foe(u).filter(x=>x.max<u.max).length);
  if(id==='h34'&&s>=20)p+=.1*Math.floor((1-u.hp/u.max)*10);
  if(id==='h35'&&s>=10&&this.n(u,'tiger'))p=1;
  if(id==='h36'&&s>=20)p+=.05*this.friends(u).length;
  if(id==='h37')p+=.1*this.foe(u).filter(x=>this.n(x,'grudge')).length;
  if(u.flags.coolUntil>=this.round)p=0;return clamp(p);
 }
 action(u){const old={...u.buffs};u.turns++;u.metrics.actions++;const finish=()=>{for(const [k,b] of Object.entries(old)){if(u.buffs[k]===b&&!['curse','burn','armor'].includes(k)&&b.exp<=u.turns)delete u.buffs[k];}};
  if(this.n(u,'doom')){this.directLoss(u.buffs.doom.source,u,u.hp,'executeDamage');finish();return;}
  const general=this.find(u.side,'h23');if(general?.star>=2&&u.hp/u.max<general.hp/general.max)this.buff(u,'tough',2);
  if(u.id==='h19'&&u.star>=2)this.buff(u,'haste',2);
  if(this.n(u,'stun')||this.n(u,'freeze')&&this.rng()<.6){u.metrics.control++;const source=(u.buffs.stun||u.buffs.freeze)?.source;finish();return;}
  if(this.n(u,'confuse')||this.n(u,'charm')){const candidates=this.n(u,'confuse')?this.adjacent(u):this.friends(u).filter(x=>x!==u);const t=this.pick(candidates);if(t)this.damage(u,t,this.atk(u),{normal:true,noCounter:true});u.metrics.control++;const source=(u.buffs.confuse||u.buffs.charm)?.source;finish();return;}
  const c=C[u.h.comboId];let acted=false;
  if(!this.n(u,'seal')){
   if(c&&(c.trigger||'action')==='action'&&this.comboAvailable(u.side,c)&&this.rangeCandidates(u,c.target).length&&this.rng()<c.chance){this.combo(u,c);acted=true;}
   if(!acted&&this.personalHasTargets(u)&&this.rng()<this.probability(u)){if(u.id==='h14'&&u.star>=20&&u.hp<u.max*.5)u.flags.lowGuarantee=true;acted=this.skill(u);}
  }
  if(!acted)this.normal(u);this.completeActive(u);finish();
 }
 run(){
  for(const team of this.teams){const hu=team.active.find(x=>x.id==='h28'&&x.star>=10);if(hu){for(const t of this.foe(hu).filter(x=>x.pos>=4)){const amount=Math.min(t.atk*.05,hu.def*.4);t.flags.robbed=(t.flags.robbed||0)+amount;hu.flags.stolen=(hu.flags.stolen||0)+amount;}}}
  this.openingAwakening();
  for(this.round=1;this.round<=30;this.round++){
   for(const t of this.teams){const dragon=t.active.find(x=>x.id==='h21'&&x.awake);if(!dragon)continue;for(const x of this.alive(dragon.side)){if(this.round===1)this.buff(x,'armor',1);if(this.round===2){delete x.buffs.armor;this.buff(x,'hotBlood',30);}}}
    for(const t of this.teams)for(const u of t.active){u.roundFlags={};if(u.hp>0)u.metrics.aliveRounds++;if(u.id==='h24')u.flags.fusuStack=(u.flags.fusuStack||0)+1;if(u.hp>0&&t.traits.factions.mo>=8)this.heal(u,u,u.max*.05);}
   const acted=new Set();for(let i=0;i<18;i++){
    if(!this.alive(0).length||!this.alive(1).length)break;
    const list=[...this.alive(0),...this.alive(1)].filter(x=>!acted.has(x)).sort((a,b)=>this.speed(b)-this.speed(a)||a.pos-b.pos||a.side-b.side);
    if(!list.length)break;const u=list[0];acted.add(u);this.action(u);this.flush();
   }
   for(const u of [...this.alive(0),...this.alive(1)])for(const k of ['curse','burn'])this.tickStatus(u,k);
   this.flush();if(!this.alive(0).length||!this.alive(1).length||this.capped)break;
  }
  const alive=this.teams.map(t=>t.active.filter(u=>u.hp>0).length);const winner=alive[0]&&!alive[1]?0:alive[1]&&!alive[0]?1:-1;
  return {winner,rounds:Math.min(this.round,30),capped:this.capped,remaining:this.teams.map(t=>t.active.reduce((v,u)=>v+u.hp/u.max,0)/9),metrics:this.teams.map(t=>t.active.map(u=>({id:u.id,...u.metrics})))};
 }
}
export function battle(a,b,seed=1,options={}){return new Combat(a,b,seed,options).run();}
export function evaluate(team,opponents,repetitions=8,seed=2718,options={}){
 if(!opponents.length||!Number.isInteger(repetitions)||repetitions<2||repetitions%2)throw Error('对手池不能为空，每队场数须为正偶数以交换先后手');
 validateTeam(team);for(const opponent of opponents)validateTeam(opponent,team.mechs.length);
 let wins=0,draws=0,n=0,rounds=0,caps=0;const metrics=emptyMetrics(),byHero=Object.fromEntries(team.active.map(x=>[x.id,emptyMetrics()]));
 for(let j=0;j<opponents.length;j++)for(let k=0;k<repetitions;k++){
  const swapped=k%2===1;const o=swapped?{...options,boost:options.boost?.slice().reverse(),disableFaction:options.disableFaction?.slice().reverse(),disableCombo:options.disableCombo?.slice().reverse(),evolutionStars:options.evolutionStars?.slice().reverse(),disableMechanisms:options.disableMechanisms?.slice().reverse(),unitBoost:options.unitBoost?.slice().reverse()}:options;
  const result=battle(swapped?opponents[j]:team,swapped?team:opponents[j],sampleSeed(seed,j,Math.floor(k/2)),o);const side=swapped?1:0;
  if(result.winner===side)wins++;if(result.winner===-1)draws++;rounds+=result.rounds;caps+=result.capped?1:0;n++;
  for(const m of result.metrics[side])for(const key of METRICS){metrics[key]+=m[key]||0;byHero[m.id][key]+=m[key]||0;}
 }
 const rate=(wins+.5*draws)/n,pairs=n/2,boundScale=1/pairs,interval=pairedInterval(rate,boundScale);
 for(const key in metrics)metrics[key]/=n;
 for(const row of Object.values(byHero))for(const key in row)row[key]/=n;
 return {rate,score:rate*100,winRate:wins/n,drawRate:draws/n,n,pairs,boundScale,wins,draws,interval,scoreInterval:interval.map(x=>100*x),intervalMethod:'95% paired bounded-score Hoeffding; model error excluded',rounds:rounds/n,caps,metrics,byHero};
}
