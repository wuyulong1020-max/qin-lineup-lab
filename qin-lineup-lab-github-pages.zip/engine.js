// Independent, deterministic theoretical model. Screenshot coefficients are immutable.
import {emptyMetrics, METRICS, pairedInterval, sampleSeed} from './statistics.js?v=v3.0.7-20261027160600';
export const MODEL='QIN-3.1';
export let DB, H, C;
export function configure(db){ DB=db; H=Object.fromEntries(db.heroes.map(h=>[h.id,h])); C=Object.fromEntries(db.combos.map(c=>[c.id,c])); }
export const starFactor=s=>1+.02*Math.min(s,5)+.03*Math.min(Math.max(s-5,0),5)+.04*Math.max(s-10,0);
export function rng(seed=1){let x=seed>>>0||1;return()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return (x>>>0)/4294967296;};}
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
export function validateTeam(team,mechCount=team.mechs.length){
 if(team.active.length!==9) throw Error('上阵必须为 9 名传说弟子');
 if(![2,3,4,5,6].includes(mechCount)||team.mechs.length!==mechCount) throw Error('机师必须恰好为所选的2—6人');
 const all=[...team.active,...team.mechs];if(new Set(all.map(x=>x.id)).size!==all.length)throw Error('弟子不能重复上阵或兼任机师');
 all.forEach(x=>{if(!H[x.id]||!Number.isInteger(x.star)||x.star<0||x.star>20)throw Error('英雄或星级无效');});
 if(team.active.some(x=>H[x.id].rarity!=='legendary'))throw Error('史诗弟子仅能担任机师'); return true;
}
export function teamTraits(team){const ids=new Set([...team.active,...team.mechs].map(x=>x.id));return {factions:Object.fromEntries(DB.factions.map(f=>[f.id,[...ids].filter(id=>H[id].faction===f.id).length])),combos:DB.combos.filter(c=>c.memberIds.every(id=>ids.has(id))&&c.memberIds.some(id=>team.active.some(h=>h.id===id))).map(c=>c.id)};}

// Chosen provisional defense function. This order is source-backed; exact formula is not official.
export function damageBeforeCritical({attack,defense,coefficient=1,extra=0,inner=0}){
 if(![attack,defense,coefficient,extra,inner].every(Number.isFinite)||coefficient<=0)throw Error('Invalid damage formula input');
 return Math.max(1,Math.max(0,attack-defense)*coefficient+extra-inner);
}

export class Combat{
 constructor(a,b,seed,options={}){
  this.rng=rng(seed);this.round=0;this.queue=[];this.events=0;this.capped=false;this.options=options;
  this.teams=[a,b].map((team,side)=>{const traits=teamTraits(team);if(options.disableFaction?.[side])traits.factions[options.disableFaction[side]]=0;
    const totalStars=team.active.reduce((s,x)=>s+x.star,0),boost=options.boost?.[side]||{};
   const active=team.active.map((r,pos)=>{const h=H[r.id],s=options.evolutionStars?.[side]?.[r.id]??r.star,m=starFactor(r.star)*(1+.001*totalStars);return {id:r.id,h,star:s,side,pos,atk:h.stats.atk*m,def:h.stats.def*m,max:h.stats.hp*m*(traits.factions.bai>=2?1.08:1),inner:h.stats.atk*m*.18,speed:h.stats.speed,buffs:{},flags:{},roundFlags:{},turns:0,casts:0,qi:0,shield:0,bonus:boost,metrics:{...emptyMetrics(),actions:0}};});
    active.forEach(u=>{u.inner*=1+(boost.inner||0);u.atk*=1+(boost.atk||0);u.def*=1+(boost.def||0);u.max*=1+(boost.hp||0);u.speed+=boost.speed||0;u.hp=u.max;u.shieldSource=null;});
   return {active,mechs:team.mechs,traits,dead:0,flags:{}};
  });
  for(const t of this.teams) for(const u of t.active){
   if(t.traits.factions.chu>=4&&u.pos>=4)u.shield=1;
   if(u.id==='h02'&&u.star>=2)u.qi=1;
   if(['h06','h27'].includes(u.id)&&u.star>= (u.id==='h06'?2:10))this.buff(u,'tough',2);
   if(u.id==='h05'&&u.star>=10)this.buff(u,'strong',1);
   if(u.id==='h11'&&u.star>=10)this.buff(u,'dodge',2);
   if(u.id==='h15'&&u.star>=2)u.flags.seal=true;
  }
 }
 alive(side){return this.teams[side].active.filter(u=>u.hp>0);}
 disabled(u,key){return !!u&&!!this.options.disableMechanisms?.[u.side]?.includes(key);}
 foe(u){return this.alive(1-u.side);} friends(u){return this.alive(u.side);}
 find(side,id){return this.teams[side].active.find(u=>u.id===id&&u.hp>0);}
 n(u,k){return u.buffs[k]?.n||0;}
 buff(u,k,d=1,n=1,source=null){if(u.hp<=0)return false;const negative=['curse','weak','fragile','stun','freeze','slow','seal','confuse','charm','doom','burn','grudge'].includes(k);
  if(source&&this.disabled(source,'control')&&['stun','freeze','seal','confuse','charm'].includes(k))return;
  if(source&&this.disabled(source,'execute')&&k==='doom')return;
  if(this.disabled(source||u,'buffs')&&['strong','tough','haste','wind','fragile','weak'].includes(k))return;
  const unclean=k==='grudge'||(k==='curse'&&source?.h.faction==='yin'&&this.teams[source.side].traits.factions.yin>=7);
  const unimmune=k==='curse'&&source?.h.faction==='yin'&&this.teams[source.side].traits.factions.yin>=7;
  if(negative&&!unimmune&&(this.n(u,'immune')||this.rng()<this.resist(u)))return false;
  const max={curse:3,weak:3,fragile:3,slow:5,strong:3,tough:3,haste:5,dodge:2}[k]||1;
  const old=u.buffs[k];const sources=[...(old?.sources||[]),...Array(n).fill(source)].slice(-max);
  if(source){if(negative)source.metrics.debuffsApplied++;else source.metrics.buffsApplied++;if(source.side!==u.side){if(['stun','freeze','seal','confuse','charm'].includes(k)){source.metrics.hardControl++;source.metrics.controlInflicted++;}else if(['weak','fragile','slow'].includes(k)){source.metrics.softControl++;source.metrics.controlInflicted++;}}}
  u.buffs[k]={n:Math.min(max,(old?.n||0)+n),exp:u.turns+d,round:this.round+d-1,unclean:unclean||old?.unclean,source:source||old?.source,sources};return true;
 }
  cleanse(u,positive=false,source=null){let removed=0;for(const k of Object.keys(u.buffs)){const neg=['curse','weak','fragile','stun','freeze','slow','seal','confuse','charm','doom','burn','grudge'].includes(k);if(neg!==positive&&!u.buffs[k].unclean){delete u.buffs[k];removed++;}}if(source&&!positive)source.metrics.cleanses+=removed;if(positive){u.flags.seal=false;}}
 resist(u){return clamp((u.bonus.resist||0)+(u.flags.seal?.5:0));}
 atk(u){let f=1+.1*this.n(u,'strong')+.1*(u.flags.sword||0);const t=this.teams[u.side];if(t.traits.factions.bai>=5)f+=.02*Math.min(this.round,5);if(this.find(u.side,'h23')?.star>=20)f+=.05;if(this.n(u,'curse')&&this.find(1-u.side,'h09')?.star>=10)f-=.06;f-=.15*this.n(u,'weak');return Math.max(1,u.atk*f+10*u.qi+(u.flags.stolen||0)-(u.flags.robbed||0));}
 defense(u){let f=1+.15*this.n(u,'tough')-.2*this.n(u,'fragile');const t=this.teams[u.side];if(t.traits.factions.bai>=5)f+=.02*Math.min(this.round,5);if(t.traits.factions.nong>=5&&u.h.faction==='nong'&&this.round===1)f+=.1;if(u.flags.seal)f+=.5;if(u.id==='h01'&&u.star>=10)f+=.1*this.foe(u).filter(x=>this.n(x,'curse')).length;if(this.find(u.side,'h23')?.star>=20)f+=.05;
  const opposite=this.teams[1-u.side].active[u.pos];if(this.teams[1-u.side].traits.factions.di>=5&&opposite.hp>0&&opposite.h.faction==='di')f-=.1;
  const fn=this.find(u.side,'h15');return Math.max(0,u.def*f+(fn&&fn!==u&&fn.star>=20?fn.def*.1:0));}
 inner(u){return u.inner*(1+(this.n(u,'tiger')?.3:0)+(this.friends(u).some(x=>x!==u&&this.n(x,'tiger'))?.1:0)+(u.pos>=4&&this.find(u.side,'h24')?.star>=10?.2:0)+(this.find(u.side,'h23')?.star>=20?.05:0));}
 speed(u){return u.speed+25*this.n(u,'haste')-25*this.n(u,'slow')+(this.teams[u.side].traits.factions.di>=3?3:0);}
 pick(arr){return arr.length?arr[Math.floor(this.rng()*arr.length)]:null;}
 sample(arr,n){let a=arr.slice(),r=[];while(a.length&&r.length<n){const i=Math.floor(this.rng()*a.length);r.push(a.splice(i,1)[0]);}return r;}
 low(side,n=1){return this.alive(side).sort((a,b)=>a.hp/a.max-b.hp/b.max||a.pos-b.pos).slice(0,n);}
 front(u){let e=this.foe(u);return e.filter(x=>x.pos<4).length?e.filter(x=>x.pos<4):e;}
 back(u){let e=this.foe(u);return e.filter(x=>x.pos>=4).length?e.filter(x=>x.pos>=4):e;}
 adjacent(t){return this.alive(t.side).filter(x=>x!==t&&(x.pos<4)===(t.pos<4)&&Math.abs(x.pos-t.pos)===1);}
 targets(u,target,count){let e=this.foe(u);if(target.includes('全体')&&target.includes('敌'))return e;if(target.includes('后排全体'))return this.back(u);if(target.includes('前排全体'))return this.front(u);if(target==='单排'){let f=e.filter(x=>x.pos<4),b=e.filter(x=>x.pos>=4);return f.length>=b.length?f:b;}
  if(target.includes('链状')){const first=this.pick(this.front(u));return first?[first,...this.sample(e.filter(x=>x!==first),(count||4)-1)]:[];}
  if(target.includes('随机'))return this.sample(e,count||3);
  if(target==='三行'){let first=this.pick(this.front(u));if(!first)return [];let x=first.pos<4?first.pos+.5:first.pos-4;return e.filter(t=>Math.abs((t.pos<4?t.pos+.5:t.pos-4)-x)<=1.1);}
  return this.sample(target.includes('后排')?this.back(u):this.front(u),1);
 }
 heal(source,t,amount){if(!t||t.hp<=0||this.disabled(source,'healing'))return;const attempted=Math.max(0,amount)*(1+(t.bonus.heal||0)),got=Math.min(t.max-t.hp,attempted);t.hp+=got;source.metrics.heal+=got;source.metrics.overheal+=attempted-got;}
 recordLoss(source,t,amount,kind='directDamage'){
  if(!Number.isFinite(amount))throw Error('Non-finite HP loss');if(!source||amount<=0)return;
  t.metrics.damageTaken+=amount;if(source.side===t.side){source.metrics.friendlyFire+=amount;return;}
   source.metrics.damage+=amount;source.metrics[kind]+=amount;
 }
 directLoss(source,t,amount,kind='hpReduction'){
  if(!t||t.hp<=0||amount<=0)return 0;const loss=Math.min(t.hp,amount);t.hp-=loss;this.recordLoss(source,t,loss,kind);this.checkRecovery(t);
  if(t.hp<=0)this.death(t,source||this.foe(t)[0]||t);return loss;
 }
 equalize(source,friends){if(this.disabled(source,'healing'))return;const ratio=friends.reduce((v,x)=>v+x.hp/x.max,0)/friends.length;for(const x of friends){const hp=ratio*x.max,delta=hp-x.hp;source.metrics[delta>=0?'redistributedGain':'redistributedLoss']+=Math.abs(delta);x.hp=hp;}}
 tickStatus(u,k){const status=u.buffs[k];if(!status||u.hp<=0||this.disabled(status.source,'dot'))return;
  const amount=k==='curse'?u.hp*.1*status.n:u.max*.05,pre=u.hp,loss=Math.min(pre,amount);
  const sources=k==='curse'&&status.sources?.length?status.sources:[status.source];
  u.hp-=loss;for(const s of sources)this.recordLoss(s,u,loss/sources.length,'dotDamage');
  this.checkRecovery(u);if(u.hp<=0)this.death(u,status.source||this.foe(u)[0]||u);if(status.round<=this.round)delete u.buffs[k];
 }
 checkRecovery(u){if(u.id==='h04'&&u.star>=20&&!u.flags.full&&u.hp>0&&u.hp<u.max*.4){u.flags.full=true;this.heal(u,u,u.max);this.cleanse(u,false,u);}}
 canCast(u,checkFreeze=true){if(!u||u.hp<=0)return false;if(u.id==='h16'&&u.star>=20&&u.hp<u.max*.5)return true;return !this.n(u,'stun')&&!this.n(u,'seal')&&!this.n(u,'confuse')&&!this.n(u,'charm')&&(!checkFreeze||!this.n(u,'freeze')||this.rng()>=.6);}
 enqueue(fn){this.queue.push(fn);}
 flush(){while(this.queue.length){if(++this.events>2000){this.capped=true;this.queue=[];break;}this.queue.shift()();}}
 damage(u,t,raw,o={}){
  if(!Number.isFinite(raw)||o.coefficient!==undefined&&(!Number.isFinite(o.coefficient)||o.coefficient<=0)||o.extraDamage!==undefined&&!Number.isFinite(o.extraDamage))throw Error('Non-finite damage or invalid coefficient: '+u?.id);
  if(!t||u.hp<=0||t.hp<=0||raw<=0)return {amount:0,killed:false,crit:false};
  if(this.disabled(u,'penetration'))o={...o,ignoreDef:false,ignoreInner:false,pierce:0};if(this.disabled(u,'trueDamage'))o={...o,true:false};
  const isSkill=!o.normal;let dodge=isSkill?(this.n(t,'hidden')?.4:0)+(t.bonus.skillDodge||0):.3*this.n(t,'dodge')+(this.teams[t.side].traits.factions.yin>=2?.03:0)+(t.bonus.dodge||0);
  if(this.rng()<clamp(dodge))return {amount:0,killed:false,crit:false,miss:true};
  let critChance=(u.bonus.crit||0)+(this.teams[u.side].traits.factions.chu>=2?.03:0)+.1*(u.flags.sword||0)+(u.flags.farmCrit?.1:0)+(this.n(u,'wind')?.05:0)+(o.crit||0);
  const anti=(t.bonus.antiCrit||0)+(t.id==='h37'&&t.star>=2?.06:0)+(this.teams[t.side].traits.factions.mo>=4?.03:0);
  const crit=!this.disabled(u,'crit')&&(!!o.forceCrit||this.rng()<clamp(critChance-(o.ignoreAnti?0:anti)));
  let amount=raw;
  if(!o.true){const coefficient=o.coefficient??1,extra=o.extraDamage||0;
   amount=damageBeforeCritical({attack:o.attack??(raw-extra)/coefficient,defense:o.ignoreDef?0:this.defense(t),coefficient,extra,inner:isSkill&&!o.ignoreInner?this.inner(t):0});}

  if(crit)amount*=Math.max(1,1.5+(this.teams[u.side].traits.factions.nong>=4?.1:0)+(u.bonus.critDamage||0)+(o.critDamage||0)-(t.bonus.critReduce||0));
  const reduction=(t.bonus.skillReduce||0)+(this.teams[t.side].traits.factions.mo>=3?.03:0)+(t.id==='h26'&&this.options.disableCombo?.[t.side]!==t.h.comboId?(C[t.h.comboId]?.coefficient||0):0)+(t.id==='h37'&&t.star>=2?.06:0);
  let pierce=this.disabled(u,'penetration')?0:(o.pierce||0)+(u.bonus.pierce||0)+(this.teams[u.side].traits.factions.yin>=4?.03:0)+(this.n(u,'wind')?.05:0);if(this.n(u,'curse')&&this.find(1-u.side,'h03')?.star>=10)pierce-=.25;
  amount*=o.true?1-clamp(t.bonus.trueResist||0,0,.95):isSkill?1-clamp(reduction-pierce,0,.95):1;
  amount*=1+(u.bonus.damage||0);amount=Math.max(1,Math.round(amount));
  if(t.shield>0&&!o.true){t.shield--;const saved=Math.min(amount,t.hp);t.metrics.protected+=saved;if(t.shieldSource)t.shieldSource.metrics.absorbed+=saved;else t.metrics.factionAbsorbed+=saved;return {amount:0,killed:false,crit,shield:true};}
  const pre=t.hp;t.hp=Math.max(0,t.hp-amount);this.recordLoss(u,t,Math.min(pre,amount));if(u.side!==t.side){u.metrics[isSkill?'skillDamage':'normalDamage']+=Math.min(pre,amount);if(crit)u.metrics.criticalDamage+=Math.min(pre,amount);if(o.area)u.metrics.areaDamage+=Math.min(pre,amount);if(o.counter)u.metrics.counterDamage+=Math.min(pre,amount);}
  this.checkRecovery(t);
  if(t.id==='h16'&&t.star>=10&&amount>pre*.1)this.buff(t,this.rng()<.5?'tough':'strong',2);
  if(t.id==='h37')this.buff(u,'grudge',3,1,t);
  if(t.id==='h34'&&t.star>=10&&!t.roundFlags.charm&&t.hp>0){t.roundFlags.charm=true;const x=this.pick(this.foe(t));if(x)this.buff(x,'charm',2,1,t);}
  if(isSkill&&t.id==='h03'&&t.star>=2&&t.hp>0&&this.rng()<.8){const x=this.pick(this.foe(t));if(x)this.buff(x,'curse',2,1,t);}
  if(t.hp<=0)this.death(t,u);
  else if(!o.noCounter)this.react(t,u,isSkill);
  return {amount:Math.min(pre,amount),killed:t.hp<=0,crit};
 }
 react(t,u,isSkill){if(t.hp<=0)return;const id=t.id,s=t.star;const can=this.canCast(t,false);
  if(!can||this.disabled(t,'counter'))return;
  if(id==='h26'&&(t.roundFlags.chart||0)<(s>=20?7:s>=10?6:s>=2?5:4)){t.roundFlags.chart=(t.roundFlags.chart||0)+1;const first=t.roundFlags.chart===1;this.enqueue(()=>{if(!this.canCast(t))return;const r=this.damage(t,u,this.atk(t)*1.1+(this.options.disableCombo?.[t.side]!==t.h.comboId?this.inner(t):0),{noCounter:true,counter:true,coefficient:1.1,extraDamage:this.options.disableCombo?.[t.side]!==t.h.comboId?this.inner(t):0});if(r.amount){if(s>=2&&first)this.buff(u,'fragile',2,1,t);if(s>=10)this.heal(t,t,r.amount*.35);if(s>=20&&this.rng()<.2)this.buff(u,'stun',1,1,t);}});}
  if(id==='h13'&&s>=2&&isSkill&&!t.flags.firstHit){t.flags.firstHit=true;this.enqueue(()=>{if(!this.canCast(t))return;const x=this.pick(this.front(t));const r=this.damage(t,x,this.atk(t),{noCounter:true,counter:true});if(r.amount)this.buff(x,'fragile',1,1,t);});}
  if(id==='h15'&&s>=10&&t.flags.seal&&!t.roundFlags.sealQueued&&this.rng()<.5){t.roundFlags.sealQueued=true;this.enqueue(()=>{this.skill(t,true,u);t.roundFlags.sealQueued=false;});}
  if(id==='h06'&&s>=20&&!t.roundFlags.counter){t.roundFlags.counter=true;this.enqueue(()=>{if(!this.canCast(t))return;for(const x of this.foe(t).sort((a,b)=>b.hp/b.max-a.hp/a.max).slice(0,3)){this.damage(t,x,this.atk(t)*1.4+(t.max-t.hp)*.15,{noCounter:true,counter:true,coefficient:1.4,extraDamage:(t.max-t.hp)*.15});this.buff(x,'fragile',1,1,t);}});}
  if(id==='h22'&&s>=10&&!t.roundFlags.counter){t.roundFlags.counter=true;this.enqueue(()=>{if(!this.canCast(t))return;this.damage(t,u,t.max*.25,{noCounter:true,counter:true});this.buff(u,'burn',1,1,t);});}
  if(['h16','h20','h27','h28','h29'].includes(id)&&!t.roundFlags.counter){let p=t.h.skill.chance;if(id==='h16'&&s>=20&&t.hp<t.max*.5)p=1;if(id==='h20'&&s>=10&&t.flags.clone)p=1;if(this.rng()<p){t.roundFlags.counter=true;this.enqueue(()=>this.skill(t,true,u));}}
 }
 death(t,killer){const own=this.teams[t.side],enemy=this.teams[1-t.side];own.dead++;if(killer&&killer.side!==t.side)killer.metrics.kills++;const cursed=this.n(t,'curse');
  for(const a of this.alive(1-t.side)){
   if(a.id==='h08'&&a.star>=20&&cursed&&!a.flags.extra){a.flags.extra=true;this.enqueue(()=>this.skill(a));}
   if(a.id==='h13'&&a.star>=10&&!a.flags.enemyDeath){a.flags.enemyDeath=true;this.enqueue(()=>{const x=this.low(t.side)[0];if(this.damage(a,x,this.atk(a),{noCounter:true}).killed)this.buff(a,'strong',1);});}
   if(a.id==='h23'&&a.star>=10&&!a.roundFlags.kill){a.roundFlags.kill=true;this.friends(a).forEach(x=>this.buff(x,'strong',2));}
   if(a.id==='h29'&&a.star>=2&&!a.roundFlags.kill){a.roundFlags.kill=true;const x=this.pick(this.friends(a));if(x){this.buff(x,'tough',3);this.cleanse(x,false,a);}}
   if(a.id==='h30'&&a.star>=2&&!a.flags.kill){a.flags.kill=true;this.friends(a).forEach(x=>this.buff(x,'wind',2));}
  }
  for(const a of this.alive(t.side)){
   if(a.id==='h10'&&a.star>=20&&!a.roundFlags.rescue){a.roundFlags.rescue=true;this.enqueue(()=>this.skill(a));}
   if(a.id==='h13'&&a.star>=20&&!a.flags.allyDeath){a.flags.allyDeath=true;this.enqueue(()=>{this.damage(a,killer,this.atk(a),{noCounter:true});this.buff(killer,'seal',2,1,a);});}
   if(a.id==='h31'&&a.star>=2&&!a.flags.allyDeath){a.flags.allyDeath=true;this.friends(a).forEach(x=>this.heal(a,x,.09*x.max));}
  }
  const farm=DB.combos.find(c=>c.trigger==='ally_death');if(this.comboAvailable(t.side,farm,false)){const owner=this.find(t.side,'h36')||this.find(t.side,'h37');if(owner){const atk=farm.memberIds.reduce((sum,id)=>{const a=this.find(t.side,id);const m=own.mechs.find(x=>x.id===id);return sum+(a?this.atk(a):m?H[id].stats.atk*starFactor(m.star):0);},0);this.alive(t.side).forEach(x=>this.heal(owner,x,(x.max-x.hp)*.05+atk*farm.coefficient));}}
 }
 comboAvailable(side,c,requireActive=true){if(!c||this.options.disableCombo?.[side]===c.id)return false;const ids=new Set([...this.alive(side).map(x=>x.id),...this.teams[side].mechs.map(x=>x.id)]);return c.memberIds.every(id=>ids.has(id))&&c.memberIds.some(id=>this.find(side,id));}
 skill(u,counter=false,attacker=null){if(u.hp<=0||counter&&!this.canCast(u))return;let id=u.id,s=u.star,a=this.atk(u),coef=u.h.skill.coefficient,targets=[],opts={noCounter:counter},chain=u.h.skill.target.includes('链状'),dice=0;u.casts++;
  if(u.h.skill.kind==='heal'){
   let friends=this.friends(u);
   if(id==='h22'){this.equalize(u,friends);u.flags.firstHeal=true;}
   if(id==='h10')friends=this.low(u.side,4);
   friends.forEach((x,i)=>{let amount=a*coef;if(id==='h12'&&s>=2&&x.hp<x.max*.5)amount*=1.4;if(id==='h22'&&s>=2)amount*=1+.1*Math.floor(this.teams[u.side].dead/2);this.heal(u,x,amount);if(id==='h12'&&x.hp>=x.max)this.buff(x,'dodge',1);if(id==='h10'){if(this.rng()<1-.2*i)this.cleanse(x,false,u);if(s>=10)this.buff(x,'immune',2);}});return;
  }
  if(id==='h26')return;
  if(id==='h02'){a=this.atk(u);if(s>=10)targets=this.foe(u);}
  if(id==='h16')targets=attacker&&attacker.hp>0?[attacker]:this.targets(u,'单体');
  if(id==='h20'){targets=this.sample(this.foe(u),u.flags.clone?2:1);this.cleanse(u,false,u);u.flags.clone=false;}
  if(id==='h28')targets=this.low(1-u.side,1);
  if(id==='h29')targets=this.foe(u).sort((a,b)=>a.hp/a.max-b.hp/b.max).slice(0,1);
  if(id==='h32'){dice=1+Math.floor(this.rng()*6);if(s>=10&&dice===6){targets=this.foe(u);u.flags.nextDice=this.round+1;}if(dice%2||dice===6&&s>=10)opts.crit=.2;if(dice%2===0)opts.pierce=.15;}
  if(!targets.length)targets=this.targets(u,u.h.skill.target,id==='h11'?4+(s>=10?1:0)+(s>=20?1:0):id==='h17'?4+(s>=20?1:0):id==='h38'?3+(s>=10?1:0):undefined);
  if(id==='h37'&&s>=10)targets=[...new Set([...targets,...this.foe(u).filter(x=>this.n(x,'grudge'))])];
  if(this.disabled(u,'area'))targets=targets.slice(0,1);
  const initialTargets=targets.slice(), highTarget=targets.slice().sort((a,b)=>b.hp/b.max-a.hp/a.max||a.pos-b.pos)[0];
  for(let i=0;i<targets.length;i++){
   const t=targets[i];if(t.hp<=0)continue;let raw=a*coef,op={...opts,counter,area:targets.length>1},factor=1,sourceAttack=a;
   if(chain){const decay=Math.pow(id==='h11'?1:id==='h05'&&s>=2?.95:.9,i);raw*=decay;factor*=decay;}
   if(id==='h01')op.ignoreAnti=true;
   if(id==='h02'){if(s>=10&&t.pos>=4){raw*=.7;factor*=.7;}if(s>=20){raw+=this.inner(u)*.5;op.critDamage=.3;}}
   if(id==='h03'&&s>=20&&this.n(t,'curse')){op.ignoreDef=true;op.ignoreInner=true;}
   if(id==='h04'&&s>=2&&u.hp<u.max*.7)raw+=this.defense(u);
   if(id==='h05'){if(s>=2&&t.pos>=4){raw*=1.25;factor*=1.25;}if(s>=10)op.crit=.1;}
   if(id==='h06')raw+=(u.max-u.hp)*.15;
   if(id==='h07'){raw+=this.inner(u);if(s>=10){op.pierce=.15;if(t.hp<t.max*.5)op.critDamage=.3;}}
   if(id==='h08'&&s>=10){op.noCounter=true;if(targets.length<4){raw*=1.3;factor*=1.3;}if(targets.length===1)op.forceCrit=true;}
   if(id==='h09'&&s>=20)op.ignoreDef=true;
   if(id==='h11'&&s>=2&&this.n(t,'stun'))op.forceCrit=true;
   if(id==='h13')raw+=Math.min(raw,this.atk(t)*.5);
   if(id==='h14'&&s>=2)op.noCounter=true;
   if(id==='h15'){sourceAttack=a+this.defense(u)*.3;raw=sourceAttack*coef;}
   if(id==='h16'&&s>=20)raw+=this.defense(u);
   if(id==='h17'&&s>=10&&this.foe(u).length<=5)op.forceCrit=true;
   if(id==='h18'&&s>=2){const m=1+.2*(5-this.foe(u).filter(x=>x.pos>=4).length);raw*=m;factor*=m;}
   if(id==='h19'&&t===highTarget)op.forceCrit=true;
   if(id==='h21'){raw+=(u.max-u.hp)*.15;if(s>=2)op.noCounter=true;}
   if(id==='h24'&&s>=20)op.crit=.2;
   if(id==='h25'){if(t.pos>=4){raw*=1.3;factor*=1.3;}if(s>=2)op.critDamage=.5;}
   if(id==='h30'){op.pierce=.15;if(s>=20&&i===0)op.forceCrit=true;}
   if(id==='h31'&&s>=10){factor=Math.pow(.9,i);sourceAttack=a+.5*this.defense(u);raw=sourceAttack*coef*factor;}
   if(id==='h32'&&s>=10&&dice===6&&t.pos>=4){raw*=.7;factor*=.7;}
   if(id==='h33'&&s>=2&&u.hp<u.max*.65)op.crit=.3;
   if(id==='h35'&&this.inner(t)<this.inner(u))op.forceCrit=true;
   if(id==='h36')raw+=.05*this.friends(u).filter(x=>x!==u).reduce((v,x)=>v+this.atk(x),0);
   if(id==='h37'){if(s>=10&&this.n(t,'grudge'))op.forceCrit=true;if(s>=20)op.true=true;}
   if(id==='h38'){op.ignoreInner=true;if(s>=2&&t.hp<t.max*.5)op.forceCrit=true;if(s>=10)op.noCounter=true;}
   op.coefficient=coef*factor;op.attack=sourceAttack;op.extraDamage=raw-sourceAttack*op.coefficient;
   const r=this.damage(u,t,raw,op);
   if(!r.miss&&!r.shield){
    if(id==='h01'&&s>=2&&r.crit)this.buff(t,'curse',1,1,u);
    if(id==='h03'&&this.rng()<.55)this.buff(t,'curse',2,1,u);
    if(id==='h04'&&this.rng()<.35)this.buff(t,'stun',1,1,u);
    if(id==='h05'&&this.rng()<(s>=20?.7:.4))this.buff(t,'fragile',2,1,u);
    if(id==='h08'&&this.rng()<.55)this.buff(t,'curse',1,1,u);
    if(id==='h09')this.buff(t,'curse',2,1,u);
    if(id==='h11'&&s>=2&&this.rng()<.2)this.buff(t,'stun',1,1,u);
    if(id==='h14'&&this.rng()<(s>=2?.4:.3))this.buff(t,'freeze',1,1,u);
    if(id==='h16'){this.buff(t,'slow',2,1,u);if(s>=2){this.heal(u,u,r.amount*.3);this.heal(u,this.low(u.side,9).find(x=>x!==u),r.amount*.3);}}
    if(id==='h17'){if(t.hp<t.max*.1)this.buff(t,'doom',1,1,u);if(s>=2&&this.foe(u).length>5&&this.rng()<.4)this.buff(t,'stun',1,1,u);}
    if(id==='h18'&&this.rng()<.4)this.buff(t,'fragile',1,1,u);
    if(id==='h20'&&s>=20&&this.rng()<.8)this.buff(t,'confuse',1,1,u);
    if(id==='h21'&&s>=10){const stunned=this.rng()<.45&&this.buff(t,'stun',1,1,u);if(!stunned)this.buff(t,'weak',1,1,u);}
    if(id==='h24'&&s>=20)this.cleanse(t,true);
    if(id==='h27'){const sealed=this.rng()<.3&&this.buff(t,'seal',1,1,u);if(!sealed&&s>=2)this.buff(t,'slow',2,1,u);}
    if(id==='h28')this.buff(t,'weak',2,1,u);
    if(id==='h30'&&s>=20){if(i===1)this.buff(t,'seal',1,1,u);if(i===2)this.heal(u,u,r.amount*.5);}
    if(id==='h31'){if(this.defense(t)<this.defense(u)&&this.rng()<.6)this.buff(t,'weak',1,1,u);if(this.speed(t)<this.speed(u)&&this.rng()<.6)this.buff(t,'fragile',1,1,u);}
    if(id==='h34'&&s>=2&&this.rng()<.5)this.buff(t,'weak',1,1,u);
   }
   if(id==='h07'){
    if(s>=10)for(const x of this.adjacent(t))this.damage(u,x,raw*.7,{...op,coefficient:op.coefficient*.7,extraDamage:op.extraDamage*.7});
    if(s>=2&&r.killed)this.buff(u,'haste',2);
   }
   if(id==='h09'&&s>=2){if(r.killed)this.damage(u,this.pick(this.foe(u)),raw*.7,{...op,coefficient:op.coefficient*.7,extraDamage:op.extraDamage*.7});else this.buff(u,'strong',1);}
   if(id==='h28'&&s>=2&&r.killed)for(const x of this.foe(u).filter(x=>(x.pos<4)===(t.pos<4)))this.damage(u,x,raw*(t.pos<4?.8:.6),{...op,coefficient:op.coefficient*(t.pos<4?.8:.6),extraDamage:op.extraDamage*(t.pos<4?.8:.6)});
   if(id==='h29'&&s>=20){if(r.killed)this.heal(u,this.low(u.side)[0],r.amount*.6);else {const x=this.pick(this.foe(u).filter(x=>x!==t));if(x)this.directLoss(u,x,Math.max(0,x.hp-t.hp/t.max*x.max));}}
   if(id==='h35'&&s>=20)for(const x of this.foe(u).filter(x=>x!==t&&(x.pos<4)===(t.pos<4)))this.damage(u,x,this.inner(u)*1.03,{true:true,noCounter:counter});
  }
  if(id==='h25'&&s>=20&&this.n(u,'hidden')&&this.rng()<.1){const hidden=u.buffs.hidden;u.buffs.hidden={...hidden,exp:hidden.exp+1};}
  if(id==='h02')u.qi=0;
  if(id==='h06'&&s>=2)this.buff(u,'tough',2);
  if(id==='h07'){if(s>=2)u.flags.sword=Math.min(4,(u.flags.sword||0)+1);if(s>=20)this.buff(u,'dodge',1);}
  if(id==='h15')u.flags.seal=false;
  if(id==='h19'&&s>=10){const x=initialTargets.filter(x=>x.hp>0).sort((a,b)=>this.atk(b)-this.atk(a))[0];if(x)this.buff(x,'confuse',1,1,u);}
  if(id==='h21'&&s>=2)this.buff(u,'tough',2);
  if(id==='h23')this.sample(this.friends(u),3).forEach(x=>this.buff(x,'haste',1));
  if(id==='h24'){this.friends(u).filter(x=>x.pos<4).forEach(x=>this.heal(u,x,a*coef*.3));if(s>=2)u.flags.coolUntil=this.round+1;u.flags.fusuStack=0;}
  if(id==='h31'&&s>=20)u.flags.coolUntil=this.round+1;
  if(id==='h32'&&s>=2){if(dice<=3||dice===6&&s>=10)this.heal(u,this.pick(this.friends(u)),a*coef*.5);if(dice>=4){const x=this.pick(this.friends(u));if(x)this.cleanse(x,false,u);}}
  if(id==='h33'){this.buff(u,'tough',2);if(s>=10)this.foe(u).sort((a,b)=>b.hp/b.max-a.hp/a.max).slice(0,3).forEach(x=>this.damage(u,x,this.atk(u),{noCounter:counter}));}
  if(id==='h34')this.heal(u,u,u.max*.15);
  if(id==='h36'){
   if(s>=2){const all=this.friends(u),x=this.pick(all),max=Math.max(...all.map(x=>x.hp/x.max));if(x){this.heal(u,x,max*x.max-x.hp);this.buff(x,'strong',1);}}
   if(s>=10){const all=this.foe(u),x=this.pick(all),min=Math.min(...all.map(x=>x.hp/x.max));if(x){this.directLoss(u,x,Math.max(0,x.hp-min*x.max));this.buff(x,'weak',1,1,u);}}
  }
 }
 combo(u,c){let a=this.atk(u),name=c.name;let targets=this.targets(u,c.target),opts={};if(['暗度陈仓','天下大同'].includes(name))opts.true=true;if(name==='纵横寰宇')opts.ignoreInner=true;if(name==='天人合一')opts.pierce=.15;
  if(name==='帝子降兮'){const t=this.foe(u).sort((a,b)=>b.hp/b.max-a.hp/a.max)[0];targets=t?[t,...this.adjacent(t)]:[];}
  if(name==='亢龙有悔'){const counts={},limit=this.disabled(u,'area')?1:6;for(let i=0;i<limit;i++){const t=this.pick(this.foe(u).filter(x=>(counts[x.id]||0)<2));if(!t)break;counts[t.id]=(counts[t.id]||0)+1;const r=this.damage(u,t,a*c.coefficient,{coefficient:c.coefficient,extraDamage:0,area:limit>1});if(!r.miss&&!r.shield)this.buff(t,'seal',1,1,u);}return;}
  if(this.disabled(u,'area'))targets=targets.slice(0,1);
  const highestTarget=targets.slice().sort((a,b)=>b.hp/b.max-a.hp/a.max||a.pos-b.pos)[0];
  const hit=(t,i,m=1)=>{const wasHighest=t===highestTarget;let factor=m,raw=a*c.coefficient*m,op={...opts,area:targets.length>1};if(name==='混沌洪荒'&&this.n(t,'curse')){raw*=1.3;factor*=1.3;}if(name==='三极殒灭'&&this.n(t,'curse'))op.forceCrit=true;if(name==='纵横寰宇'){const mult=1+.05*(9-this.foe(u).length);raw*=mult;factor*=mult;}
   if(name==='帝子降兮'&&i===0)op.forceCrit=true;if(name==='横扫千军'&&t.pos>=4)op.forceCrit=true;if(name==='八方俱灭'&&t.pos<4)op.ignoreDef=true;if(name==='霸道无双'&&wasHighest)op.forceCrit=true;if(name==='天崩地裂')raw+=t.max*.1;if(c.target.includes('链状')){const decay=Math.pow(.9,i);raw*=decay;factor*=decay;}
   op.coefficient=c.coefficient*factor;op.extraDamage=raw-a*op.coefficient;const wasCursed=this.n(t,'curse');const r=this.damage(u,t,raw,op);if(r.miss||r.shield)return r;
   if(name==='混沌洪荒'&&!wasCursed)this.buff(t,'curse',2,1,u);
   if(['翻云覆雨','白羽墨影'].includes(name)&&t.hp<t.max*.3)this.buff(t,'doom',1,1,u);
   if(name==='天人合一'&&this.rng()<.1)this.buff(t,'stun',1,1,u);
   if(name==='阳春白雪'&&t.hp<t.max*.5)this.buff(t,'freeze',1,1,u);
   if(name==='帝子降兮'&&i>0)this.buff(t,'confuse',1,1,u);
   if(name==='横扫千军'&&this.rng()<.7)this.buff(t,'seal',1,1,u);
   if(name==='亢龙有悔')this.buff(t,'seal',1,1,u);
   if(name==='八方俱灭'&&t.pos>=4)this.buff(t,'weak',2,1,u);
   if(name==='霸道无双'&&!wasHighest)this.buff(t,'charm',1,1,u);return r;
  };
  for(let i=0;i<targets.length;i++){const t=targets[i];const r=hit(t,i);if(name==='屠龙之刃'&&r.killed){let m=.7;for(let n=0;n<8;n++){const x=this.pick(this.foe(u));if(!x||!hit(x,0,m).killed)break;m*=.7;}}}
  if(name==='暗度陈仓'&&!this.disabled(u,'shield'))this.friends(u).forEach(x=>{x.shield=1;x.shieldSource=u;u.metrics.shieldsGiven++;});
  if(name==='翻云覆雨')this.low(u.side,2).forEach(x=>{this.heal(u,x,a*c.coefficient*.4);this.cleanse(x,false,u);});
  if(name==='天人合一')this.low(u.side,9-this.foe(u).length).forEach(x=>this.heal(u,x,a*c.coefficient*.6));
  if(name==='寂剑离风'){const t=this.foe(u).sort((a,b)=>this.atk(b)-this.atk(a))[0];if(t)this.buff(t,'stun',1,1,u);this.friends(u).forEach(x=>this.cleanse(x,false,u));}
  if(name==='天崩地裂'){let scope=9;while(scope>0&&this.foe(u).length>0&&this.foe(u).length<scope){scope-=3;if(scope<=0)break;this.sample(this.foe(u),scope).forEach((t,i)=>hit(t,i));}}
 }
 normal(u,forced=null){const target=forced||this.pick(this.front(u));if(!target)return;this.damage(u,target,this.atk(u),{normal:true});const s=u.star,id=u.id;
  if(id==='h02')u.qi=Math.min(2,u.qi+1);
  if(id==='h04'&&s>=10){this.buff(u,'tough',1);this.buff(u,'strong',1);}
  if(id==='h06'&&s>=10)this.heal(u,u,u.max*.1);
  if(id==='h08'&&s>=2){for(const x of this.sample(this.foe(u),2))this.buff(x,'curse',1,1,u);}
  if(id==='h10'&&s>=2){const x=this.pick(this.friends(u));if(x)this.buff(x,'strong',2);}
  if(id==='h12'&&s>=10){const x=this.low(u.side)[0];if(x)this.heal(u,x,x.max*.15);}
  if(id==='h14'&&s>=10)this.buff(target,'freeze',1,1,u);
  if(id==='h15'&&s>=2)u.flags.seal=true;
  if(id==='h18'&&s>=10){this.buff(target,'fragile',1,1,u);this.buff(target,'weak',1,1,u);}
  if(id==='h20'&&s>=2){u.flags.clone=true;if(s>=10)this.buff(u,'dodge',1);}
  if(id==='h25'&&s>=10)this.buff(u,'hidden',1);
  if(id==='h27'&&s>=10)this.buff(u,'tough',2);
  if(id==='h35'&&s>=2)this.buff(u,'tiger',2);
  if(this.teams[u.side].traits.factions.nong>=7&&u.h.faction==='nong')u.flags.farmCrit=true;
 }
 probability(u){const s=u.star,id=u.id;let p=u.h.skill.chance;
  if(['h16','h20','h26'].includes(id))return 0;
  if(id==='h27')return s>=20&&this.n(u,'tough')>=3?1:0;
  if(id==='h28')return s>=20?.5:0;
  if(id==='h29')return s>=10?.4:0;
  if(id==='h02')p+=.35*u.qi;
  if(id==='h06'&&s>=10)p*=2;
  if(['h01','h07'].includes(id)&&s>=20)p=1;
  if(['h03','h17','h38'].includes(id)&&s>=20)p*=2;
  if(id==='h05'&&s>=20&&this.round===1)p=1;
  if(id==='h08'&&s>=20)p+=.1;
  if(id==='h09'&&s>=20)p+=.3;
  if(id==='h11'&&s>=20)p+=.04*this.foe(u).filter(x=>this.speed(x)<this.speed(u)).length;
  if(id==='h12'&&s>=20)p+=.1*this.friends(u).filter(x=>x.hp<x.max*.7).length;
  if(id==='h14'&&s>=20&&u.hp<u.max*.5&&!u.flags.lowGuarantee){p=1;}
  if(id==='h18'&&s>=20&&this.round===1)p=1;
  if(id==='h19'&&s>=20)p+=.03*Math.floor(100*u.hp/u.max/4);
  if(id==='h21'&&s>=20&&u.hp<u.max*.6)p=1;
  if(id==='h22'&&s>=20&&!u.flags.firstHeal)p=1;
  if(id==='h23'&&this.round===1)p=1;
  if(id==='h24'&&s>=2)p+=.4*(u.flags.fusuStack||0);
  if(id==='h25'&&s>=20&&this.n(u,'hidden'))p=1;
  if(id==='h30'&&s>=10&&u.casts<3)p*=2;
  if(id==='h31'&&s>=20)p=1;
  if(id==='h32'&&(s>=20&&this.round===1||u.flags.nextDice===this.round))p=1;
  if(id==='h33'&&s>=20)p+=.07*(9-this.foe(u).length+this.foe(u).filter(x=>x.max<u.max).length);
  if(id==='h34'&&s>=20)p+=.1*Math.floor((1-u.hp/u.max)*10);
  if(id==='h35'&&s>=10&&this.n(u,'tiger'))p=1;
  if(id==='h36'&&s>=20)p+=.05*this.friends(u).length;
  if(id==='h37')p+=.1*this.foe(u).filter(x=>this.n(x,'grudge')).length;
  if(u.flags.coolUntil>=this.round)p=0;return clamp(p);
 }
 action(u){const old={...u.buffs};u.turns++;u.metrics.actions++;const finish=()=>{for(const [k,b] of Object.entries(old)){if(u.buffs[k]===b&&!['curse','burn'].includes(k)&&b.exp<=u.turns)delete u.buffs[k];}};
  if(this.n(u,'doom')){this.directLoss(u.buffs.doom.source,u,u.hp,'executeDamage');finish();return;}
  const general=this.find(u.side,'h23');if(general?.star>=2&&u.hp/u.max<general.hp/general.max)this.buff(u,'tough',2);
  if(u.id==='h19'&&u.star>=2)this.buff(u,'haste',2);
  if(this.n(u,'stun')||this.n(u,'freeze')&&this.rng()<.6){u.metrics.control++;const source=(u.buffs.stun||u.buffs.freeze)?.source;finish();return;}
  if(this.n(u,'confuse')||this.n(u,'charm')){const candidates=this.n(u,'confuse')?this.adjacent(u):this.friends(u).filter(x=>x!==u);const t=this.pick(candidates);if(t)this.damage(u,t,this.atk(u),{normal:true,noCounter:true});u.metrics.control++;const source=(u.buffs.confuse||u.buffs.charm)?.source;finish();return;}
  const c=C[u.h.comboId];let acted=false;
  if(!this.n(u,'seal')){
   if(c&&(c.trigger||'action')==='action'&&this.comboAvailable(u.side,c)&&this.rng()<c.chance){this.combo(u,c);acted=true;}
   if(!acted&&this.rng()<this.probability(u)){if(u.id==='h14'&&u.star>=20&&u.hp<u.max*.5)u.flags.lowGuarantee=true;this.skill(u);acted=true;}
  }
  if(!acted)this.normal(u);finish();
 }
 run(){
  for(const team of this.teams){const hu=team.active.find(x=>x.id==='h28'&&x.star>=10);if(hu){for(const t of this.foe(hu).filter(x=>x.pos>=4)){const amount=Math.min(t.atk*.05,hu.def*.4);t.flags.robbed=(t.flags.robbed||0)+amount;hu.flags.stolen=(hu.flags.stolen||0)+amount;}}}
  for(this.round=1;this.round<=30;this.round++){
    for(const t of this.teams)for(const u of t.active){u.roundFlags={};if(u.hp>0)u.metrics.aliveRounds++;if(u.id==='h24')u.flags.fusuStack=(u.flags.fusuStack||0)+1;if(u.hp>0&&t.traits.factions.mo>=8)this.heal(u,u,u.max*.05);}
   const acted=new Set();for(let i=0;i<18;i++){
    if(!this.alive(0).length||!this.alive(1).length)break;
    const list=[...this.alive(0),...this.alive(1)].filter(x=>!acted.has(x)).sort((a,b)=>this.speed(b)-this.speed(a)||a.pos-b.pos||a.side-b.side);
    if(!list.length)break;const u=list[0];acted.add(u);this.action(u);this.flush();
   }
   for(const u of [...this.alive(0),...this.alive(1)])for(const k of ['curse','burn'])this.tickStatus(u,k);
   this.flush();if(!this.alive(0).length||!this.alive(1).length||this.capped)break;
  }
  const alive=this.teams.map(t=>t.active.filter(u=>u.hp>0).length);const winner=alive[0]&&!alive[1]?0:alive[1]&&!alive[0]?1:-1;
  return {winner,rounds:Math.min(this.round,30),capped:this.capped,remaining:this.teams.map(t=>t.active.reduce((v,u)=>v+u.hp/u.max,0)/9),metrics:this.teams.map(t=>t.active.map(u=>({id:u.id,...u.metrics})))};
 }
}
export function battle(a,b,seed=1,options={}){return new Combat(a,b,seed,options).run();}
export function evaluate(team,opponents,repetitions=8,seed=2718,options={}){
 if(!opponents.length||!Number.isInteger(repetitions)||repetitions<2||repetitions%2)throw Error('对手池不能为空，每队场数须为正偶数以交换先后手');
 validateTeam(team);for(const opponent of opponents)validateTeam(opponent,team.mechs.length);
 let wins=0,draws=0,n=0,rounds=0,caps=0;const metrics=emptyMetrics(),byHero=Object.fromEntries(team.active.map(x=>[x.id,emptyMetrics()]));
 for(let j=0;j<opponents.length;j++)for(let k=0;k<repetitions;k++){
  const swapped=k%2===1;const o=swapped?{...options,boost:options.boost?.slice().reverse(),disableFaction:options.disableFaction?.slice().reverse(),disableCombo:options.disableCombo?.slice().reverse(),evolutionStars:options.evolutionStars?.slice().reverse(),disableMechanisms:options.disableMechanisms?.slice().reverse()}:options;
  const result=battle(swapped?opponents[j]:team,swapped?team:opponents[j],sampleSeed(seed,j,Math.floor(k/2)),o);const side=swapped?1:0;
  if(result.winner===side)wins++;if(result.winner===-1)draws++;rounds+=result.rounds;caps+=result.capped?1:0;n++;
  for(const m of result.metrics[side])for(const key of METRICS){metrics[key]+=m[key]||0;byHero[m.id][key]+=m[key]||0;}
 }
 const rate=(wins+.5*draws)/n,pairs=n/2,boundScale=1/pairs,interval=pairedInterval(rate,boundScale);
 for(const key in metrics)metrics[key]/=n;
 for(const row of Object.values(byHero))for(const key in row)row[key]/=n;
 return {rate,score:rate*100,winRate:wins/n,drawRate:draws/n,n,pairs,boundScale,wins,draws,interval,scoreInterval:interval.map(x=>100*x),intervalMethod:'95% paired bounded-score Hoeffding; model error excluded',rounds:rounds/n,caps,metrics,byHero};
}
