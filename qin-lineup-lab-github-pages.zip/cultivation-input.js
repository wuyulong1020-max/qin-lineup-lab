export const stageOf=(unit,inherited=0)=>(unit.awakening??inherited)===8?21:unit.star;
export const stageLabel=value=>+value===21?'8觉醒':value+'星';
export const setStage=(unit,value)=>({...unit,star:+value===21?20:+value,awakening:+value===21?8:0});
export function uniformTeam(team){const stages=[...team.active,...team.mechs].map(u=>stageOf(u,team.awakening??0));return stages.length>0&&stages.every(s=>s===stages[0]);}
export function projectTeam(team,env){const next=structuredClone(team);if(!uniformTeam(next))return next;const stage=env.awakening===8?21:env.star;next.active=next.active.map(u=>setStage(u,stage));next.mechs=next.mechs.map(u=>setStage(u,stage));next.awakening=env.awakening??0;if(next.searchConstraints)next.searchConstraints.pool=next.searchConstraints.pool.map(u=>setStage(u,stage));return next;}
