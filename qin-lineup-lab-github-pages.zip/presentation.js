import {DB,H,teamTraits,personalCoefficient} from './engine.js?v=v4.0.4-20261128133409';
import {groupTeamFamilies,sameTeamFamily,teamFamilyName} from './team-families.js?v=v4.0.4-20261128133409';
export const STYLE_NAMES=['爆发速攻','群攻压血','控制压制','反击制胜','持续消耗','奶盾续航'];
export function featureVector(row){const m=row.result.metrics,d=Math.max(1,m.damage),r=Math.max(1,row.result.rounds);return [Math.max(0,d-(m.dotDamage||0)-(m.counterDamage||0))*(row.result.openingShare??(Number.isFinite(m.openingDamage)?Math.min(1,m.openingDamage/d):1/r)),(m.areaDamage||0)/d,((m.hardControl||0)+(m.softControl||0))/(9*r),(m.counterDamage||0)/d,((m.dotDamage||0)+(m.hpReduction||0))/d,((m.heal||0)+(m.absorbed||0)+(m.factionAbsorbed||0)+(m.numericAbsorbed||0))/Math.max(1,(m.damageTaken||0)+(m.protected||0))]}
export function styleCalibration(rows){return STYLE_NAMES.map((_,i)=>rows.map(r=>featureVector(r)[i]).sort((a,b)=>a-b))}
export function calibratedStyle(row,calibration){const raw=featureVector(row),values=raw.map((v,i)=>{const a=calibration[i];if(v<=0||!a.length)return 0;let j=a.findIndex(x=>x>=v);if(j<0)return 1+(v-a.at(-1))/Math.max(1e-9,a.at(-1)-a[Math.floor(a.length/2)]);if(j===0)return v/Math.max(1e-9,a[0])/a.length;return (j+(v-a[j-1])/Math.max(1e-9,a[j]-a[j-1]))/a.length}),maximum=Math.max(...values),ties=values.map((v,i)=>({v,i})).filter(x=>Math.abs(x.v-maximum)<1e-12);const best=ties.sort((a,b)=>STYLE_NAMES[a.i].localeCompare(STYLE_NAMES[b.i],'zh-CN'))[0].i;return{name:STYLE_NAMES[best],raw,percentiles:values,basis:'开场输出、群攻、硬软控制、反击、持续伤害、治疗与两类护盾；按当前环境连续分位比较'}}

export const sameFamily=sameTeamFamily;
export function familyRows(rows,options){return groupTeamFamilies(rows,options)}
export function effectSignature(row){const t=teamTraits(row.team);return [...t.combos,...DB.factions.flatMap(f=>f.tiers.filter(v=>t.factions[f.id]>=v.count).map(v=>f.id+'@'+v.count))]}
export function diverseCold(rows,reps,limit=8){const out=[];for(const r of rows){const ids=r.team.active.map(x=>x.id),eff=effectSignature(r);if(reps.some(p=>ids.filter(id=>p.team.active.some(x=>x.id===id)).length>4))continue;if(out.some(p=>sameFamily(p,r)))continue;if(reps.some(p=>{const ps=effectSignature(p),union=new Set([...ps,...eff]);return union.size&&eff.filter(x=>ps.includes(x)).length/union.size>.7}))continue;out.push(r);if(out.length===limit)break}return out}
export function coldLineups(rows,reps,cuts,tierOf){
 const selected=[];
 const representatives=reps.map(row=>({ids:new Set(row.team.active.map(x=>x.id)),effects:new Set(effectSignature(row))}));
 const eligible=rows.map(row=>{
  const tier=Number(tierOf(row.result.score,cuts).slice(1));
  if(tier>2.5)return null;
  const ids=row.team.active.map(x=>x.id),effects=effectSignature(row);
  let different=9;
  for(const rep of representatives){
   different=Math.min(different,9-ids.filter(id=>rep.ids.has(id)).length);
   const shared=effects.filter(key=>rep.effects.has(key)).length;
   if(shared/(effects.length+rep.effects.size-shared||1)>.7)return null;
  }
  return {row,tier,different};
 }).filter(Boolean).sort((a,b)=>b.row.result.score-a.row.result.score||a.row.id.localeCompare(b.row.id));
 for(const [different,maxTier] of [[5,2],[4,2],[3,2],[3,2.5]]){
  for(const candidate of eligible){
   if(selected.length===5)break;
   if(candidate.tier>maxTier||candidate.different<different)continue;
   if(selected.some(({row})=>row.id===candidate.row.id||sameFamily(row,candidate.row)))continue;
   selected.push(candidate);
  }
  if(selected.length>=3)break;
 }
 return selected;
}
const percent=v=>Number((v*100).toFixed(1))+'%';
export function heroSkillSummary(h,star){if(!h?.skill)return '仅作为机师参与组合与羁绊';if(star==='total')return `${h.skill.name} · 技能10级 · 基础发动${percent(h.skill.chance)} · ${h.skill.kind==='heal'?'治疗':'伤害'}${percent(personalCoefficient(h))}攻击 · ${h.skill.target}；${h.skill.text||''}；${[2,10,20].map(n=>n+'星：'+(h.evolutions?.[n]||'无新增技能效果')).join('；')}`;const s=h.skill,e=Object.entries(h.evolutions||{}).filter(([k])=>+k===+star).map(([k,text])=>({star:+k,text}));let p=s.chance;if(h.id==='h06'&&star>=10)p*=2;if(['h03','h17','h38'].includes(h.id)&&star>=20)p*=2;if(h.id==='h08'&&star>=20)p+=.1;if(h.id==='h09'&&star>=20)p+=.3;let chance=percent(p);if(['h01','h07'].includes(h.id)&&star>=20)chance='必发';if(h.id==='h02')chance='基础30%，每层聚气＋35个百分点';if(h.id==='h23')chance='首回合必发，之后30%';if(h.id==='h37')chance='基础30%，每名记仇敌人＋10个百分点';if(h.id==='h16')chance=star>=20?'受击反击30%，血量低于50%必发':'受击反击30%';if(h.id==='h20')chance=star>=10?'受击反击30%，分身后必发':'受击反击30%';if(h.id==='h26')chance='每回合触发星图';if(h.id==='h27')chance=star>=20?'受击反击30%，3层坚韧时主动必发':'受击反击30%';if(h.id==='h28')chance=star>=20?'主动50%／受击反击30%':'受击反击30%';if(h.id==='h29')chance=star>=10?'主动40%／受击反击30%':'受击反击30%';if(h.id==='h30'&&star>=10)chance='前3次释放60%，之后30%';if(h.id==='h31'&&star>=20)chance='必发，释放后冷却1回合';if(['h05','h18','h32'].includes(h.id)&&star>=20)chance='首回合必发，之后'+percent(p);if(h.id==='h22'&&star>=20)chance='首次必发，之后15%';if(['h11','h12','h14','h19','h21','h25','h33','h34','h36'].includes(h.id)&&star>=20)chance='基础'+percent(p)+'，随状态提升';if(h.id==='h24')chance='基础30%，随回合提升40个百分点（有冷却）';if(h.id==='h35'&&star>=10)chance='基础40%，虎魄状态必发';let range=s.target;if(h.id==='h02'&&star>=10)range='敌方全体，后排70%威力';if(h.id==='h11')range=star>=20?'6名目标':star>=10?'5名目标':s.target;if(h.id==='h17'&&star>=20)range=s.target+'＋1人';if(h.id==='h38'&&star>=10)range=s.target+'＋1人';return `${s.name} · 技能10级 · ${chance} · ${s.kind==='heal'?'治疗':'伤害'}${percent(personalCoefficient(h))}攻击 · ${range}；${[s.text,...e.map(x=>x.text)].filter(Boolean).join('；')}${h.id==='h35'&&star>=20?'；本模型技能10级：上述真伤比例为130%内力':''}`}
export function subjectSummary(row,kind,star){if(kind==='heroes')return heroSkillSummary(H[row.baseId||row.id],star);if(kind==='combos'){const c=DB.combos.find(c=>c.id===(row.comboId||row.id));const level=star==='total'?null:+star,coefficient=level===null?null:c?.coefficient*(1+.04*level),value=level===null?[2,10,20].map(l=>l+'星'+percent(c.coefficient*(1+.04*l))).join(' / '):percent(coefficient);if(c?.trigger==='passive')return `被动 · 自身技伤减免＋${value}；${c.text}`;return c?`${c.trigger==='ally_death'?'友军阵亡触发':percent(c.chance)} · ${c.kind==='heal'?'治疗':'伤害'}${value}攻击 · ${c.target}；${c.text}`:row.text||''}const f=DB.factions.find(f=>f.id===row.factionId);return row.text||f?.tiers.find(t=>t.count===row.count)?.text||''}
export function roleCuts(rows,role){const values=rows.filter(r=>!r.unavailable&&H[r.id]?.role===role).map(r=>r.delta).sort((a,b)=>b-a);return [.05,.2,.4,.65,.85].map(q=>values[Math.min(values.length-1,Math.floor(values.length*q))])}

export function lineupDisplayName(row, style=row.style, core=row.core){
  if(row.familyName)return row.familyName;
  const name=row.name||row.team?.name||'';
  if(name&&!/探索阵容|自选阵容|综合搭配|爆发速攻|群攻压血|控制压制|反击制胜|持续消耗|奶盾续航/.test(name))return name;
  if(row.team?.active?.length===9)return teamFamilyName({...row,style,core});
  const ids=(core?.length?core:row.team?.active?.slice(0,2)||[]).map(x=>typeof x==='string'?x:x.id);
  const names=[...new Set(ids)].map(id=>H[id]?.name).filter(Boolean).slice(0,2);
  return [style||'综合搭配',names.join('·')].filter(Boolean).join(' · ');
}
