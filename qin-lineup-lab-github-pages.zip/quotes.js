const escape = text => String(text ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function quoteMarkup(quote, compact = false) {
  if (!quote) return '';
  const text = `<span class="hero-quote">${escape(quote.text)}</span>`;
  return compact ? text : `<section class="quote-detail">${text}</section>`;
}
