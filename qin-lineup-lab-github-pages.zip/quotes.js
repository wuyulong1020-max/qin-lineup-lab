const escape = text => String(text ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function quoteMarkup(quote, compact = false) {
  if (!quote) return '';
  const text = `<span class="hero-quote">${escape(quote.text)}</span>`;
  if (compact) return text + `<span class="quote-label">${escape(quote.label)}</span>`;
  const url = quote.source?.url;
  const link = typeof url === 'string' && /^https?:\/\//i.test(url) ? `<a href="${escape(url)}" target="_blank" rel="noopener noreferrer">${escape(quote.source.title || '查看来源')}</a>` : '';
  return `<section class="quote-detail">${text}<details><summary>${escape(quote.label)} · 文案出处</summary><p>${escape(quote.note)}</p>${link}</details></section>`;
}
